#include "Tool.h"
int all_num = 0;
double max_curvature = 0;

vector<Scalar> color_bar::setColorMode(int type, int num_gradient)
{
	if (type == 0)   //0 hot
	{
		//double diff = 1 / num_gradient;
		double each_gra_gray = 255 * 3 / num_gradient;
		for (int i = 0; i <= num_gradient; i++)
		{
			int all_gray = 765 - i*each_gra_gray;
			if (all_gray > 510) colorbar.push_back(Scalar(all_gray - 510, 255, 255));
			else if (all_gray <= 510 && all_gray > 255) colorbar.push_back(Scalar(0, all_gray - 255, 255));
			else if (all_gray <= 255 && all_gray > 0) colorbar.push_back(Scalar(0, 0, all_gray));
		}
		cout << "colorbar: " << colorbar.size() << endl;
	}
	else if (type == 1) //1 jet
	{
	}
	return colorbar;
}

void color_bar::DrawColorBar(Mat& image, Point leftTop, Point rightBottom, double v_min, double v_max, int num_value) //num �꼸������, value ��ɫ������ֵ
{
	double height = leftTop.y - rightBottom.y;
	double width = rightBottom.x - leftTop.x;
	cout << "height: " << height << endl;
	int num_gra = colorbar.size();
	//int each_x = width / num_gra;
	double each_y = height / num_gra;
	double num_height = height / (num_value - 1);
	double each_v = (v_max - v_min) / (num_value - 1);
	//cout << height << "  " << each_y << num_height << endl;
	for (int i = 0; i < num_gra; i++)
	{
		Point newleftT = leftTop + Point(0, -i*each_y);
		Point newrightB = newleftT + Point(width, -each_y);
		rectangle(image, newleftT, newrightB, colorbar[i], -1);
		//cout << colorbar[num_gra] << endl;
	}
	rectangle(image, leftTop, rightBottom, Scalar(0, 0, 0), 1);
	Point line_start = leftTop + Point(width + 10, 0);
	Point line_end = line_start + Point(0, -height);
	line(image, line_start, line_end, Scalar(0, 0, 0), 1);
	for (int j = 0; j < num_value; j++)
	{
		Point newline = line_start + Point(0, -j*num_height);
		Point newline2 = newline + Point(10, 0);
		line(image, newline, newline2, Scalar(0, 0, 0), 1);
		double x_value = v_min + j*each_v;
		stringstream ss;
		ss << setiosflags(ios::fixed) << setprecision(2) << x_value << endl;
		string x_value_s;
		ss >> x_value_s;
		putText(image, x_value_s, newline2 + Point(10, 0), CV_FONT_HERSHEY_SCRIPT_COMPLEX, 2.5, CV_RGB(0, 0, 0), 3);
	}

}

KM::Kuhn_Munkres(vector<vector<double>> error_map, bool max_sum)
{
	n = error_map.size();
	m = error_map[0].size();
	cout << n << "  " << m << endl;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (max_sum) w[i + 1][j + 1] = error_map[i][j];
			else w[i + 1][j + 1] = -error_map[i][j];
			cout << error_map[i][j] << "  ";// << w[i + 1][j + 1] << endl;
		}
		cout << endl;
	}
}

int KM::can(int t)
{
	visx[t] = 1;
	for (int i = 1; i <= m; i++)
	{
		//cout << "lx[t]: " << lx[t] << " " << ly[i] << "  " << w[t][i] << endl;
		if (!visy[i] && abs(w[t][i] - lx[t] - ly[i]) < 0.0001 )//����"lx[t]+ly[i]==w[t][i]"�����������������ͼ��������·��ǰ��, �ǳ���Ҫ, ��Ϊ��double, ����abs
		{
			visy[i] = 1;
			if (link[i] == -1 || can(link[i]))
			{
				link[i] = t;
				return 1;
			}
		}
	}
	return 0;
}

double KM::km()
{
	double sum = 0;
	memset(ly, 0, sizeof(ly));
	for (int i = 1; i <= n; i++){//�Ѹ���lx��ֵ����Ϊ��ǰw[i][j]�����ֵ
		lx[i] = -inf;
		for (int j = 1; j <= n; j++){
			if (lx[i] < w[i][j])
				lx[i] = w[i][j];
		}
	}
	memset(link, -1, sizeof(link));
	for (int i = 1; i <= n; i++)
	{
		//cout << "i: " << i << endl;
		while (1)
		{
			memset(visx, 0, sizeof(visx));
			memset(visy, 0, sizeof(visy));
			if (can(i))//������ܹ��γ�һ������·������ô��break
				break;
			double d = inf;//���򣬺���Ӧ�ü����µı�,����Ӧ���ȼ���dֵ
			for (int j = 1; j <= n; j++)//������������·���ϵ�XY�㣬���·���ϵ�X���㼯ΪS��Y���㼯ΪT����������S�еĵ�xi������T�еĵ�yj
				if (visx[j])
					for (int k = 1; k <= m; k++)
						if (!visy[k])
							d = min(d, lx[j] + ly[k] - w[j][k]);
			if (d == inf)
				return -1;//�Ҳ������Լ���ıߣ�����ʧ�ܣ����Ҳ�������ƥ�䣩
			for (int j = 1; j <= n; j++)
				if (visx[j])
					lx[j] -= d;
			for (int j = 1; j <= m; j++)
				if (visy[j])
					ly[j] += d;
		}
	}
	for (int i = 1; i <= m; i++)
		if (link[i] > -1)
		{
			sum += w[link[i]][i];
			//cout << endl << endl << w[link[i]][i] << "  " << sum<< endl;
		}
	return sum;
}

void draw_poly(Mat &drawing_, vector<Point2f> contour_s, Point2f shift, Scalar color, double zoom_scale) //����Ҫ�������ײ,��Ҫ���׸�
{
	int n = contour_s.size();
	//cout << "n: " << n << endl;
	Point rook_points[1][2000];
	for (int t = 0; t < n; t++)
	{
		rook_points[0][t] = zoom_scale * contour_s[t] + shift;
	}
	const Point* ppt[1] = { rook_points[0] };
	int npt[] = { n };
	fillPoly(drawing_,
		ppt,
		npt,
		1,
		color //��ɫ
		//Scalar(255, 255, 255) //��ɫ
		);

}

void draw_poly_contour(Mat &drawing_, vector<Point2f> contour_s, Point2f shift, Scalar color)
{
	int n = contour_s.size();
	//cout << "n: " << n << endl;
	Point rook_points[1][2000];
	for (int t = 0; t < n; t++)
	{
		rook_points[0][t] = contour_s[t] + shift;
	}
	for (int i = 0; i < n; i++)
	{
		circle(drawing_, rook_points[0][i], 1, Scalar(0, 255, 0), -1);
	}
	
}

double length_two_point2f(Point2f &u, Point2f &v)
{
	return sqrt((u.x - v.x)*(u.x - v.x) + (u.y - v.y)*(u.y - v.y));
}

double length_v(Point2f &u)
{
	return sqrt(u.x * u.x + u.y * u.y);
}

double com_derivative(Point2f prev, Point2f back)
{
	if (back.x == prev.x) return 10000;
	double figure = (back.y - prev.y) / (back.x - prev.x);
	if (figure > 10000) return 10000;
	else return figure;
}

double com_Sec_derivative(Point2f prev, Point2f one, Point2f back)
{
	if (back.x == prev.x) return 10000;
	double figure = (com_derivative(back, one) - com_derivative(one, prev)) / (0.5 * (back.x - prev.x));
	if (figure > 10000) return 10000;
	else return figure;
}

double com_curvature(Point2f prev, Point2f one, Point2f back)
{
	double deriva_one = com_derivative(prev, back);
	double sec_deri = com_Sec_derivative(prev, one, back);
	if (deriva_one == sec_deri == 10000) return 0; //ֱ��
	else return abs(sec_deri) / pow((1 + pow(deriva_one, 2)), 1.5);
}

double diff_color(Scalar color1, Scalar color2)
{
	//����ʹ�õ��ļ���RGBֵ����ʽΪ��(x.B-y.B)+(x.G-y.G)+(x.R-y.R)
	double total_ = 0;
	for (int i = 0; i < 3; i++)
	{
		total_ += abs(color1.val[i] - color2.val[i]) / (3 * 255);  //��һ��
	}
	return total_;
}

double diff_deriv_curva(vector<double> one_deriv_curva, vector<double> sec_deriv_curva)
{
	double diff = 0;
	//��ʱ��û�й�һ��
	//diff += abs(abs(one_deriv_curva[0]) - abs(sec_deriv_curva[0])) / 10000;
	diff += abs(one_deriv_curva[1] - sec_deriv_curva[1]) / max_curvature;
	return diff;
}


vector<Point2f> b_box(vector<Point2f> contour)
{
	vector<Point2f> four_cor;
	double bbx_max_x = -100000;
	double bbx_max_y = -100000;
	double bbx_min_x = 100000;
	double bbx_min_y = 100000;
	for (int i = 0; i < contour.size(); i++)
	{
		if (contour[i].x < bbx_min_x) bbx_min_x = contour[i].x;
		if (contour[i].x > bbx_max_x) bbx_max_x = contour[i].x;
		if (contour[i].y < bbx_min_y) bbx_min_y = contour[i].y;
		if (contour[i].y > bbx_max_y) bbx_max_y = contour[i].y;
	}
	four_cor.push_back(Point2f(bbx_min_x, bbx_max_y));
	four_cor.push_back(Point2f(bbx_min_x, bbx_min_y));
	four_cor.push_back(Point2f(bbx_max_x, bbx_min_y));
	four_cor.push_back(Point2f(bbx_max_x, bbx_max_y));
	return four_cor;
}

//cross point
bool point_on_line(Point2f onep, Line_Seg line)
{
	double px0 = onep.x, py0 = onep.y;
	double px1 = line.start.x, py1 = line.start.y;
	double px2 = line.end.x, py2 = line.end.y;
	bool flag = false;
	double d1 = (px1 - px0) * (py2 - py0) - (px2 - px0) * (py1 - py0);
	if ((abs(d1) < 0.00001) && ((px0 - px1) * (px0 - px2) <= 0) && ((py0 - py1) * (py0 - py2) <= 0))
	{
		flag = true;
	}
	return flag;
}

bool point_in_polygon(Point2f onep, vector<Point2f> &poly)
{
	bool isInside = false;
	int count = 0;
	double x = onep.x;
	double y = onep.y;
	//
	double minX = DBL_MAX;
	for (int i = 0; i < poly.size(); i++)
	{
		double p_x = poly[i].x;
		minX = min(minX, p_x);
	}

	Point2f pt(x, y);
	Point2f linePoint1(x, y);
	Point2f linePoint2(minX - 10, y);
	//����ÿһ����
	for (int i = 0; i < poly.size(); i++)
	{
		double cx1 = poly[i].x;
		double cy1 = poly[i].y;
		double cx2 = poly[(i + 1) % poly.size()].x;
		double cy2 = poly[(i + 1) % poly.size()].y;
		Line_Seg line1(Point2f(cx1, cy1), Point2f(cx2, cy2));
		Line_Seg line2(linePoint1, linePoint2);
		Point2f crop;
		//cout << pt << " " << line1.start << " " << line1.end << endl;
		if (point_on_line(pt, line1))
		{
			//cout << "online" << endl;
			return true;
		}

		if (fabs(cy2 - cy1) < 0.00001)   //ƽ�����ཻ
		{
			continue;
		}

		if (point_on_line(Point2f(cx1, cy1), line2))
		{
			if (cy1 > cy2)          //ֻ��֤�϶˵�+1
			{
				count++;
			}
		}
		else if (point_on_line(Point2f(cx2, cy2), line2))
		{
			if (cy2 > cy1)          //ֻ��֤�϶˵�+1
			{
				count++;
			}
		}
		else if (line_intersection(line1, line2, crop))   //�Ѿ��ų�ƽ�е����
		{
			count++;
		}
	}

	if (count % 2 == 1)
	{
		isInside = true;
	}

	return isInside;
}

int line_intersection(Line_Seg line1, Line_Seg line2, Point2f &cross_p)
{
	//return 0:û�н���; 1:���� 2:���ߣ�������end����ĵ�
	Point2f start1 = line1.start;
	Point2f end1 = line1.end;
	Point2f start2 = line2.start;
	Point2f end2 = line2.end;
	Point2f s10 = end1 - start1;
	Point2f s32 = end2 - start2;
	Point2f s02 = start1 - start2;
	float s_numer, t_numer, denom, t;
	denom = s10.x * s32.y - s32.x * s10.y;
	s_numer = s10.x * s02.y - s10.y * s02.x;
	t_numer = s32.x * s02.y - s32.y * s02.x;

	if (denom == 0)//ƽ�л���
	{
		if (s_numer == 0)//Collinear,������end1����ĵ�
		{
			double dis1 = sqrt((start2.x - end1.x)*(start2.x - end1.x) + (start2.y - end1.y)*(start2.y - end1.y));
			double dis2 = sqrt((end2.x - end1.x)*(end2.x - end1.x) + (end2.y - end1.y)*(end2.y - end1.y));
			if (dis1 > dis2)
			{
				cross_p = end2;
			}
			else{
				cross_p = start2;
			}
			return 2;
		}
		else return 0; // parallel
		cout << "denom == 0" << endl;
	}
	bool denomPositive = denom > 0;
	if ((s_numer < 0) == denomPositive)//�����Ǵ��ڵ���0��С�ڵ���1�ģ����ӷ�ĸ����ͬ���ҷ���С�ڵ��ڷ�ĸ
		return 0; // No collision


	if ((t_numer < 0) == denomPositive)
		return 0; // No collision

	if (fabs(s_numer) > fabs(denom) || fabs(t_numer) > fabs(denom))
		return 0; // No collision
	// Collision detected
	t = t_numer / denom;
	//cout << "t:" << t << endl;
	cross_p.x = start1.x + t * s10.x;
	cross_p.y = start1.y + t * s10.y;
	return 1;
}

bool line_polygon(Line_Seg line1, vector<Point2f> contour, vector<Point2f>& in_sec)
{
	vector<Point2f> all_inter;
	int contsize = contour.size();
	for (int i = 0; i < contsize; i++)
	{
		Point2f cen;
		Line_Seg line2(contour[i], contour[(i + 1) % contsize]);
		int f = line_intersection(line1, line2, cen);
		if (f == 1)
		{
			if (all_inter.empty() || length_two_point2f(all_inter.back(), cen)>0.01)
				all_inter.push_back(cen);
		}
		else if (f == 2) all_inter.push_back(0.5 * (line2.start + line2.end));
	}
	in_sec = all_inter;
	//cout << "intersize :  "<<all_inter.size() << all_inter [0]<<" "<<all_inter[1]<< endl;
	if (all_inter.size() != 0)	return true;
	else return false;
}

bool poly_poly(vector<Point2f> contour, vector<Point2f> contour_, vector<Point2f>& all_in_sec)
{
	vector<Point2f> all_inter;
	int contsize = contour.size();
	int consize2 = contour_.size();
	for (int i = 0; i < contsize; i++)
	{
		Point2f cen;
		Line_Seg line(contour[i], contour[(i + 1) % contsize]);
		vector<Point2f> interp;
		if (line_polygon(line, contour_, interp))
		{
			for (int j = 0; j < interp.size(); j++)
			{
				int f = 0;
				for (int t = 0; t < all_inter.size(); t++)
				{
					if (length_two_point2f(all_inter[t], interp[j]) < 0.01)
						f = 1;
				}
				if (f == 0)
				{
					all_inter.push_back(interp[j]);
				}
			}
		}
	}
	all_in_sec = all_inter;
	if (all_inter.size() != 0) return true;
	else return false;

}

bool poly_group(vector<vector<Point2f>> Contours)
{
	int sizeC = Contours.size();
	//cout << "sizeC"<<sizeC << endl;
	if (sizeC < 2) return false; //ֻ��һ��ͼ���϶������ص�
	for (int i = 0; i < sizeC; i++)
	{
		for (int j = i + 1; j < sizeC; j++)
		{
			vector<Point2f> interp;
			if (poly_poly(Contours[i], Contours[j], interp)) return true;
		}
	}
	return false;
}

bool self_intersect(vector<Point2f> &contour_, int &first, int &second)
{
	int sizec = contour_.size();
	for (int i = 0; i < sizec - 2; i++)
	{
		Line_Seg line1(contour_[i], contour_[i + 1]);
		if (i == 0)
		{
			for (int j = 2; j < sizec - 1; j++)
			{
				Point2f crossp;
				Line_Seg line2(contour_[j], contour_[j + 1]);
				if (line_intersection(line1, line2, crossp) == 1)
				{
					first = i;
					second = j;
					return true;
				}
			}
		}
		else{
			for (int j = i + 2; j < sizec; j++)
			{
				Point2f crossp;
				Line_Seg line2(contour_[j], contour_[(j + 1) % sizec]);
				if (line_intersection(line1, line2, crossp) == 1)
				{
					first = i;
					second = j;
					return true;
				}
			}
		}
	}
	first = -1;
	second = -1;
	return false;
}

bool isGoodTri(Vec3i &v, vector<Vec3i> & tri)
{
	int a = v[0], b = v[1], c = v[2];
	v[0] = min(a, min(b, c));//v[0]�ҵ��������Ⱥ�˳��0....N-1��NΪ��ĸ���������Сֵ
	v[2] = max(a, max(b, c));//v[2]�洢���ֵ.
	v[1] = a + b + c - v[0] - v[2];//v[1]Ϊ�м�ֵ
	if (v[0] == -1) return false;

	vector<Vec3i>::iterator iter = tri.begin();//�_ʼʱΪ��
	for (; iter != tri.end(); iter++)
	{
		Vec3i &check = *iter;//���赱ǰ��ѹ��ĺʹ洢�ķ����ˡ���ֹͣ����false��

		if (check[0] == v[0] &&
			check[1] == v[1] &&
			check[2] == v[2])
		{
			break;
		}
	}
	if (iter == tri.end())
	{
		tri.push_back(v);
		return true;
	}
	return false;
}

void TriSubDiv(vector<Point2f> &pts, Rect rc, vector<Vec3i> &tri)
{
	bool draw_ = false;
	CvSubdiv2D* subdiv;
	CvMemStorage* storage = cvCreateMemStorage(0); //�����洢��

	subdiv = cvCreateSubdiv2D(CV_SEQ_KIND_SUBDIV2D, sizeof(*subdiv),
		sizeof(CvSubdiv2DPoint),
		sizeof(CvQuadEdge2D),
		storage);//Ϊ�ʷ����ݷ���ռ�
	cvInitSubdivDelaunay2D(subdiv, rc);
	for (size_t i = 0; i < pts.size(); i++)
	{
		CvSubdiv2DPoint *pt = cvSubdivDelaunay2DInsert(subdiv, pts[i]);//���ò��뷨�����ʷ�
		pt->id = i;//Ϊÿ���������һ��id

	}

	CvSeqReader reader;//����CvSeqReader����
	int total = subdiv->edges->total;//�ߵ�����
	int elem_size = subdiv->edges->elem_size;//�ߵĴ�С

	cvStartReadSeq((CvSeq*)(subdiv->edges), &reader, 0);
	Point buf[3];
	const Point *pBuf = buf;
	Vec3i verticesIdx;
	Mat imgShow(rc.width, rc.height, CV_8UC3);

	srand((unsigned)time(NULL));
	for (int i = 0; i < total; i++)
	{
		CvQuadEdge2D* edge = (CvQuadEdge2D*)(reader.ptr);

		if (CV_IS_SET_ELEM(edge))
		{
			CvSubdiv2DEdge t = (CvSubdiv2DEdge)edge;
			int iPointNum = 3;
			Scalar color = CV_RGB(rand() & 255, rand() & 255, rand() & 255);
			//Scalar color=CV_RGB(255,0,0);
			//bool isNeg = false;
			int j;
			for (j = 0; j < iPointNum; j++)
			{
				CvSubdiv2DPoint* pt = cvSubdiv2DEdgeOrg(t);//��ȡt�ߵ�Դ��
				if (!pt) break;
				buf[j] = pt->pt;//����洢����
				//if (pt->id == -1) isNeg = true;
				verticesIdx[j] = pt->id;//��ȡ�����Id�ţ����������id�洢��verticesIdx��
				t = cvSubdiv2DGetEdge(t, CV_NEXT_AROUND_LEFT);//��ȡ��һ����
			}
			if (j != iPointNum) continue;
			if (isGoodTri(verticesIdx, tri) && draw_)
			{
				//tri.push_back(verticesIdx);
				polylines(imgShow, &pBuf, &iPointNum,
					1, true, color,
					1, CV_AA, 0);//����������
				//printf("(%d, %d)-(%d, %d)-(%d, %d)\n", buf[0].x, buf[0].y, buf[1].x, buf[1].y, buf[2].x, buf[2].y);
				//printf("%d\t%d\t%d\n", verticesIdx[0], verticesIdx[1], verticesIdx[2]);
				//imshow("Delaunay", imgShow);
				//waitKey();
			}

			t = (CvSubdiv2DEdge)edge + 2;//�෴��Ե reversed e

			for (j = 0; j < iPointNum; j++)
			{
				CvSubdiv2DPoint* pt = cvSubdiv2DEdgeOrg(t);
				if (!pt) break;
				buf[j] = pt->pt;
				verticesIdx[j] = pt->id;
				t = cvSubdiv2DGetEdge(t, CV_NEXT_AROUND_LEFT);
			}
			if (j != iPointNum) continue;
			if (isGoodTri(verticesIdx, tri) && draw_)
			{
				//tri.push_back(verticesIdx);
				polylines(imgShow, &pBuf, &iPointNum,
					1, true, color,
					1, CV_AA, 0);
				//printf("(%d, %d)-(%d, %d)-(%d, %d)\n", buf[0].x, buf[0].y, buf[1].x, buf[1].y, buf[2].x, buf[2].y);
				//printf("%d\t%d\t%d\n", verticesIdx[0], verticesIdx[1], verticesIdx[2]);
				//imshow("Delaunay", imgShow);
				//waitKey();
			}

		}
		CV_NEXT_SEQ_ELEM(elem_size, reader);
	}

	vector<Vec3i> tri_;
	Mat show5 = Mat(imgShow.size(), CV_8UC3, Scalar(255, 255, 255));
	for (int m = 0; m < tri.size(); m++)
	{
		Point2f cen = 1.0 / 3 * (pts[tri[m][0]] + pts[tri[m][1]] + pts[tri[m][2]]);
		//cout << "cen:"<<cen << endl;
		if (point_in_polygon(cen, pts))
		{
			tri_.push_back(tri[m]);
			if (draw_)
			{
				line(show5, pts[tri[m][0]], pts[tri[m][1]], Scalar(255, 0, 0));
				line(show5, pts[tri[m][0]], pts[tri[m][2]], Scalar(255, 255, 0));
				line(show5, pts[tri[m][2]], pts[tri[m][1]], Scalar(255, 0, 255));
			}
		}
	}
	tri = tri_;
	//RemoveDuplicate(tri);
	if (draw_)
	{
		char title[100];
		sprintf_s(title, 100, "Delaunay: %d Triangles", tri.size());//tri�洢��Ϊ3������Ϊһ��vec3i����tri.size()��ʾ�����εĸ�����

		imshow(title, imgShow);
		imshow("points in polygon", show5);
	}

}

Point2f unit_vec(Point2f vec)
{
	double fenmu = sqrt(vec.x*vec.x + vec.y*vec.y);
	Point2f unit = Point2f(vec.x / fenmu, vec.y / fenmu);
	return unit;
}

Point2f vertical_vec(Point2f vec)
{
	Point2f vvec = Point2f(-vec.y, vec.x);
	return unit_vec(vvec);
}

double cos_two_vector(Point2f &v0, Point2f &v1)
{
	Point2f v0u = unit_vec(v0);
	Point2f v1u = unit_vec(v1);
	return v0u.x*v1u.x + v0u.y*v1u.y;
}

double sin_two_vector(Point2f &v0, Point2f &v1)
{
	Point2f v0u = unit_vec(v0);
	Point2f v1u = unit_vec(v1);
	return v0u.x*v1u.y - v0u.y*v1u.x;
}

void append(vector<Point2f>& v1, vector<Point2f>& v2)
{
	for (int i = 0; i < v2.size(); i++)
	{
		v1.push_back(v2[i]);
	}
}

bool equal_vec(vector<double> vec1, vector<double> vec2)
{
	if (vec1.size() != vec2.size()) return false;
	for (int i = 0; i < vec1.size(); i++)
	{
		if (vec1[i] != vec2[i]) return false;
	}
	return true;
}


//Ŀǰ���ǻ�Բ, start, end ����������ʼ�㣬centԲ�ģ��������κ�λ�ã�tileΪ���ĵ�����ȷ��������
vector<Point2f> arc_gen(Point2f start, Point2f end, Point2f cent, Point2f tile_c)
{
	//���ͬһ���ϵ����㣬��ʱ����tile���ĵ���ȷ��������	
	int arc_line_num = 50;
	vector<Point2f> arc_line;
	Point2f Vs_c = start - cent;
	Point2f Ve_c = end - cent;
	Point2f unit_vs = unit_vec(Vs_c);
	double length_s = length_two_point2f(start, cent);
	double length_e = length_two_point2f(end, cent);
	if (length_s < 0.001&&length_e < 0.001) //���������˵㶼�ڶ�������
	{
		arc_line.push_back(cent);
		return arc_line;
	}
	if (length_s < 0.001 || length_e < 0.001) //����ĳ���˵㶼�ڶ�������
	{
		Point2f offset = tile_c - cent;
		Point2f new_cent;
		if (length_s < 0.001) new_cent = cent - 0.01 * offset; //��Բ����Զ�����ĵķ���ƫ��һ��
		else new_cent = cent - 0.01 * offset;
		arc_line = arc_gen(start, end, new_cent, tile_c);
		return arc_line;
	}
	//cout << "Vs_c  " << Vs_c << "Ve_c" << Ve_c << endl;
	double cos_2v = cos_two_vector(Vs_c, Ve_c);
	double sin_2v = sin_two_vector(Vs_c, Ve_c);
	//cout << "sin_2v  " << sin_2v << endl;
	cos_2v = floor(cos_2v * 10000.000f + 0.5) / 10000.000f;
	sin_2v = floor(sin_2v * 10000.000f + 0.5) / 10000.000f;

	if (abs(sin_2v) < 0.00001) //˵��180��,��������0��
	{
		double new_angle = PI / 2;
		double new_leng = (length_two_point2f(start, cent) + length_two_point2f(end, cent)) / 2;

		double new_x = unit_vs.x*cos(new_angle) - unit_vs.y*sin(new_angle);
		double new_y = unit_vs.x*sin(new_angle) + unit_vs.y*cos(new_angle);
		Point2f new_c = Point2f(new_leng*new_x, new_leng*new_y) + cent;
		if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_c - end) < 0) //��ͬ��˵���ڲ�ͬ��
		{
			new_angle = -new_angle;
			new_x = unit_vs.x*cos(new_angle) - unit_vs.y*sin(new_angle);
			new_y = unit_vs.x*sin(new_angle) + unit_vs.y*cos(new_angle);
			new_c = Point2f(new_leng*new_x, new_leng*new_y) + cent;
			if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_c - end) > 0) cout << "succeed!" << endl;
		}

		arc_line = arc_gen(start, new_c, cent, tile_c);
		arc_line.pop_back();
		append(arc_line, arc_gen(new_c, end, cent, tile_c));
	}
	else 
	{
		double angle = 0;
		if (sin_2v < 0) angle = -acos(cos_2v);// / PI * 180;
		else angle = acos(cos_2v);// / PI * 180;
		double in_angle = angle / arc_line_num; //ÿ�������ĽǶȼ��
		double in_length = (length_e - length_s) / arc_line_num;  //ÿ����������������
		cout << cos_2v << "   " << sin_2v << "  " << in_angle << endl;
		//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}

		for (int i = 0; i <= arc_line_num; i++)
		{
			double new_angle = i*in_angle;
			double new_leng = length_s + i*in_length;
			double new_x = unit_vs.x*cos(new_angle) - unit_vs.y*sin(new_angle);
			double new_y = unit_vs.x*sin(new_angle) + unit_vs.y*cos(new_angle);
			Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
			arc_line.push_back(new_point);
		}
	}

	return arc_line;
}

//����һ�����������˵������Լ����ߣ������������߱�֤ƽ���νӣ����ʱ�֤�����仯����
//curvatures �Ľṹ��:��һ��ĵ���(����б��),����;�ڶ���ĵ���(����б��),����
vector<Point2f> arc_gen(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures)
{
	//���ͬһ���ϵ����㣬��ʱ����tile���ĵ���ȷ��������	
	int arc_line_num = 20;
	//cout << arc_line_num << endl;
	vector<double> curvas;
	vector<Point2f> arc_line;
	Point2f Vs_c = start - cent;
	Point2f Ve_c = end - cent;
	Point2f unit_vs = unit_vec(Vs_c);
	double length_s = length_two_point2f(start, cent);
	double length_e = length_two_point2f(end, cent);
	//���������˵㶼�ڶ����������������������־���ں���R_Edge��input_curva�����м�������б��
	if (length_s < 0.001&&length_e < 0.001) 
	{
		arc_line.push_back(cent);
		//����֮������,���ʶ�Ϊ0,���Է���{0,0}
		curvas = { 0, 0 };
		//return arc_line;
	}
	else if (length_s < 0.001 || length_e < 0.001) //����ĳ���˵��ڶ��������������������Ƶ������м仭Բ
	{
		Point2f new_cent = 0.5 * (start + end);
		arc_line = arc_gen(start, end, new_cent, tile_c, curvas);
	}
	else
	{
		//cout << "Vs_c  " << Vs_c << "Ve_c" << Ve_c << endl;
		double cos_2v = cos_two_vector(Vs_c, Ve_c);
		double sin_2v = sin_two_vector(Vs_c, Ve_c);
		//cout << "sin_2v  " << sin_2v << endl;
		cos_2v = floor(cos_2v * 10000.000f + 0.5) / 10000.000f;
		sin_2v = floor(sin_2v * 10000.000f + 0.5) / 10000.000f;
		double angle = PI;
		//ȷ�������Ƕȵ�����
		if (abs(sin_2v) < 0.00001) //˵��180��,��Բ������ֱ����1/R����
		{			
			double new_leng = length_two_point2f(start, end) / 2;
			//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
			double new_x = unit_vs.x*cos(angle / 2) - unit_vs.y*sin(angle / 2);
			double new_y = unit_vs.x*sin(angle / 2) + unit_vs.y*cos(angle / 2);
			Point2f new_p = Point2f(new_leng*new_x, new_leng*new_y) + cent;
			if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) < 0) //��ͬ��˵���ڲ�ͬ��
			{
				angle = -angle;
				if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) > 0) cout << "succeed!" << endl;
			}
			for (int i = 0; i <= arc_line_num; i++)
			{
				double in_angle = angle / arc_line_num; //ÿ�������ĽǶȼ��
				double new_angle = i*in_angle;
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = unit_vs.x * cos(new_angle) - unit_vs.y * sin(new_angle);
				double new_y = unit_vs.x * sin(new_angle) + unit_vs.y * cos(new_angle);
				Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
				arc_line.push_back(new_point);
			}
			double curva = 1 / new_leng;
			if (start.x == end.x) curvas = { 0, curva, 0, curva };
			else if (start.y == end.y) curvas = { 10000, curva, 10000, curva };
		}
		else 
		{
			if (sin_2v < 0) angle = -acos(cos_2v);
			else angle = acos(cos_2v);
			vector<Point2f> arc_line_tem;
			double in_angle = angle / arc_line_num; //ÿ�������ĽǶȼ��
			double in_length = (length_e - length_s) / arc_line_num;  //ÿ����������������
			//cout << cos_2v << "   " << sin_2v << "  " << in_angle << endl;
			for (int i = -1; i <= arc_line_num + 1; i++) //������������˵���ĵ�(-1,+1)�������㵼��������
			{
				double new_angle = i*in_angle;
				double new_leng = length_s + i*in_length;
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = unit_vs.x * cos(new_angle) - unit_vs.y * sin(new_angle);
				double new_y = unit_vs.x * sin(new_angle) + unit_vs.y * cos(new_angle);
				Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
				arc_line_tem.push_back(new_point);
			}
			//����˵�����ʺ͵���
			int tem_size = arc_line_tem.size();
			double s_deriv = com_derivative(arc_line_tem[0], arc_line_tem[2]);
			double s_curva = com_curvature(arc_line_tem[0], arc_line_tem[1], arc_line_tem[2]);
			double e_deriv = com_derivative(arc_line_tem[tem_size - 3], arc_line_tem[tem_size - 1]);
			double e_curva = com_curvature(arc_line_tem[tem_size - 3], arc_line_tem[tem_size - 2], arc_line_tem[tem_size - 1]);
			s_deriv = floor(s_deriv * 10000.000f + 0.5) / 10000.000f;
			s_curva = floor(s_curva * 10000.000f + 0.5) / 10000.000f;
			e_deriv = floor(e_deriv * 10000.000f + 0.5) / 10000.000f;
			e_curva = floor(e_curva * 10000.000f + 0.5) / 10000.000f;
			curvas = { s_deriv, s_curva, e_deriv, e_curva };
			for (int i = 1; i < arc_line_tem.size() - 1; i++)
			{
				arc_line.push_back(arc_line_tem[i]);
			}
		}		
	}
	curvatures = curvas;
	return arc_line;
}

//vector<Point2f> arc_gen_b(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures)
//{
//	int break_index = -1;
//	//cout << "all_num" << all_num << endl;
//	if (all_num == break_index) cout << "start��"<<start<<" end:  "<<end<<" cent:  "<<cent<< endl;
//	//���ͬһ���ϵ����㣬��ʱ����tile���ĵ���ȷ��������	
//	int arc_line_num = arc_point_num; //ÿ�������ϵĵ���
//	//cout << arc_line_num << endl;
//	vector<double> curvas;
//	vector<Point2f> arc_line;
//	Point2f Vs_c = start - cent;
//	Point2f Ve_c = end - cent;
//	Point2f unit_vs = unit_vec(Vs_c);
//	double length_s = length_two_point2f(start, cent);
//	double length_e = length_two_point2f(end, cent);
//	//���������˵㶼�ڶ����������������������־���ں���R_Edge��input_curva�����м�������б��
//	if (length_s < 0.001&&length_e < 0.001)
//	{
//		arc_line.push_back(cent);
//		//����֮������,���ʶ�Ϊ0,���Է���{0,0}
//		curvas = { 0, 0 };
//		if (all_num == break_index) cout << "Two endpoints are peakpoints" << endl;
//		//return arc_line;
//	}
//	else if (length_s < 0.001 || length_e < 0.001) //����ĳ���˵��ڶ��������������������Ƶ������м仭b����
//	{
//		Point2f new_cent; //= 0.5 * (start + end);
//		double leng_radius;// = length_two_point2f(new_cent, end);
//		double ratio = 0.55; //����b������Ȧ�İ뾶,ֵԽ��뾶Խ��
//		bool k_zero = abs(start.y - end.y) < 0.01;
//		vector<Point2f> controlPoints;
//		if (all_num == break_index) cout << "B spline " << endl;
//		if (length_s < 0.001)
//		{
//			new_cent = ratio * start + (1 - ratio) * end;
//			leng_radius = length_two_point2f(new_cent, end);
//			Point2f p1, p2;
//			if (k_zero)
//			{
//				p1 = end - Point2f(0, leng_radius);
//				if (cos_two_vector((p1 - end), (tile_c-end))<0)
//					p1 = end + Point2f(0, leng_radius);
//				p2 = new_cent + p1 - end;
//			}
//			else
//			{
//				p1 = end - Point2f(leng_radius, 0);
//				if (cos_two_vector((p1 - end), (tile_c - end))<0)
//					p1 = end + Point2f(leng_radius, 0);
//				p2 = new_cent + p1 - end;
//			}
//			controlPoints.push_back(start);
//			controlPoints.push_back(new_cent);
//			controlPoints.push_back(p2);
//			controlPoints.push_back(p1);
//			controlPoints.push_back(end);
//		}
//		if (length_e < 0.001)
//		{
//			new_cent = (1 - ratio) * start + ratio * end;
//			leng_radius = length_two_point2f(new_cent, start);
//			Point2f p1, p2;
//			if (k_zero)
//			{
//				p1 = start - Point2f(0, leng_radius);
//				if (cos_two_vector((p1 - start), (tile_c - start))<0)
//					p1 = start + Point2f(0, leng_radius);
//				p2 = new_cent + p1 - start;
//			}
//			else
//			{
//				p1 = start - Point2f(leng_radius, 0);
//				if (cos_two_vector((p1 - start), (tile_c - start))<0)
//					p1 = start + Point2f(leng_radius, 0);
//				p2 = new_cent + p1 - start;
//			}
//			controlPoints.push_back(start);
//			controlPoints.push_back(p1);
//			controlPoints.push_back(p2);
//			controlPoints.push_back(new_cent);
//			controlPoints.push_back(end);
//		}
//		arc_line = generate_b_spline(controlPoints);
//		int tem_size = arc_line.size();
//		double s_deriv = com_derivative(arc_line[0], arc_line[2]);
//		double s_curva = com_curvature(arc_line[0], arc_line[1], arc_line[2]);
//		double e_deriv = com_derivative(arc_line[tem_size - 3], arc_line[tem_size - 1]);
//		double e_curva = com_curvature(arc_line[tem_size - 3], arc_line[tem_size - 2], arc_line[tem_size - 1]);
//		s_deriv = floor(s_deriv * 10000.000f + 0.5) / 10000.000f;
//		s_curva = floor(s_curva * 10000.000f + 0.5) / 10000.000f;
//		e_deriv = floor(e_deriv * 10000.000f + 0.5) / 10000.000f;
//		e_curva = floor(e_curva * 10000.000f + 0.5) / 10000.000f;
//		curvas = { s_deriv, s_curva, e_deriv, e_curva };
//	}
//	else //�����˵㶼�ڱ߽���
//	{
//		//cout << "Vs_c  " << Vs_c << "Ve_c" << Ve_c << endl;
//		double cos_2v = cos_two_vector(Vs_c, Ve_c);
//		double sin_2v = sin_two_vector(Vs_c, Ve_c);
//		//cout << "sin_2v  " << sin_2v << endl;
//		cos_2v = floor(cos_2v * 10000.000f + 0.5) / 10000.000f;
//		sin_2v = floor(sin_2v * 10000.000f + 0.5) / 10000.000f;
//		double angle = PI;
//		//ȷ�������Ƕȵ�����
//		if (abs(sin_2v) < 0.00001) //˵��180��,��Բ������ֱ����1/R����
//		{
//			if (all_num == break_index) cout << "Circle curve; " << endl;
//			double new_leng = length_two_point2f(start, end) / 2;
//			//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
//			double new_x = unit_vs.x*cos(angle / 2) - unit_vs.y*sin(angle / 2);
//			double new_y = unit_vs.x*sin(angle / 2) + unit_vs.y*cos(angle / 2);
//			Point2f new_p = Point2f(new_leng*new_x, new_leng*new_y) + cent;
//			if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) < 0) //��ͬ��˵���ڲ�ͬ��
//			{
//				angle = -angle;
//				if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) > 0) cout << "succeed!" << endl;
//			}
//			for (int i = 0; i <= arc_line_num; i++)
//			{
//				double new_angle = i * angle / arc_line_num; //ÿ�������ĽǶȼ��
//				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
//				double new_x = unit_vs.x * cos(new_angle) - unit_vs.y * sin(new_angle);
//				double new_y = unit_vs.x * sin(new_angle) + unit_vs.y * cos(new_angle);
//				Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
//				arc_line.push_back(new_point);
//			}
//			double curva = 1 / new_leng;
//			if (start.x == end.x) curvas = { 0, curva, 0, curva };
//			else if (start.y == end.y) curvas = { 10000, curva, 10000, curva };
//		}
//		else //��180��Ϊ90,������Բ��,��Բ������:��(a,0)��Ϊa/b^2,��(0,b)��Ϊb/a^2  ��Բ��������x=a*cos  y=b*sin
//		{
//
//			if (all_num == break_index) cout << "Ellipse curve; " << endl;
//			double length_s = length_two_point2f(start,cent);
//			double length_e = length_two_point2f(end, cent);
//			Point2f unit_c_s = 1.0 / arc_line_num * (cent - start);
//			Point2f unit_c_e = 1.0 / arc_line_num * (cent - end);
//			//cout << "uit_c_s: " << unit_c_s << "   unit_c_e" << unit_c_e<<endl;
//			bool s_xaxis = abs(start.y - cent.y) < 0.01;
//			//cout << "start: " << start << "  end: " << end << "   cent: " << cent << endl;
//			if (s_xaxis) //start ����x����
//			{
//				for (int i = 0; i <= arc_line_num; i++)
//				{
//					Point2f tem_p = start + i*unit_c_s;
//					double tem_x = tem_p.x - cent.x;
//					tem_x = tem_x*tem_x / (length_s*length_s);
//					int flag = -1;
//					if (unit_c_e.y < 0) flag = -flag;
//					double tem_y = cent.y + flag*sqrt(length_e*length_e*(1 - tem_x));
//					arc_line.push_back(Point2f(tem_p.x, tem_y));
//					/*cout << "Point:  " << Point2f(tem_p.x, tem_y) << endl
//						<< "   unit_c_e: " << unit_c_e << "  flag: " << flag << endl;*/
//				}
//				curvas = { 10000, length_s / (length_e*length_e), 0, length_e / (length_s*length_s) };
//			}
//			else  //end ����x����
//			{
//				for (int i = 0; i <= arc_line_num; i++)
//				{
//					Point2f tem_p = cent - i*unit_c_e;
//					double tem_x = tem_p.x - cent.x;
//					tem_x = tem_x*tem_x / (length_e*length_e);
//					int flag = -1;
//					if (unit_c_s.y < 0) flag = -flag;
//					double tem_y = cent.y + flag*sqrt(length_s*length_s*(1 - tem_x));
//					arc_line.push_back(Point2f(tem_p.x, tem_y));
//					/*cout << "tem_x:  " << tem_x << "  tem_y" << tem_y<<endl<<"   Point:  " << Point2f(tem_p.x, tem_y) << endl
//						<< "   unit_c_e: " << unit_c_e << "  flag: " << flag << endl;*/
//				}
//				curvas = { 0, length_s / (length_e*length_e), 10000, length_e / (length_s*length_s) };
//			}
//		}
//	}
//	curvatures = curvas;
//	return arc_line;
//}


vector<Point2f> arc_gen_b(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures)
{
	int break_index = -1;
	//cout << "all_num" << all_num << endl;
	if (all_num == break_index) cout << "start��" << start << " end:  " << end << " cent:  " << cent << endl;
	//���ͬһ���ϵ����㣬��ʱ����tile���ĵ���ȷ��������	
	int arc_line_num = 50; //ÿ�������ϵĵ���
	//cout << arc_line_num << endl;
	vector<double> curvas;
	vector<Point2f> arc_line, arc_lines;
	Point2f Vs_c = start - cent;
	Point2f Ve_c = end - cent;
	Point2f unit_vs = unit_vec(Vs_c);
	double length_s = length_two_point2f(start, cent);
	double length_e = length_two_point2f(end, cent);
	//���������˵㶼�ڶ����������������������־���ں���R_Edge��input_curva�����м�������б��
	if (length_s < 0.001&&length_e < 0.001)
	{
		arc_line.push_back(cent);
		//����֮������,���ʶ�Ϊ0,���Է���{0,0}
		curvas = { 0, 0 };
		if (all_num == break_index) cout << "Two endpoints are peakpoints" << endl;
		//return arc_line;
	}
	else if (length_s < 0.001 || length_e < 0.001) //����ĳ���˵��ڶ��������������������Ƶ������м仭b����
	{
		Point2f new_cent; //= 0.5 * (start + end);
		double leng_radius;// = length_two_point2f(new_cent, end);
		double ratio = 0.55; //����b������Ȧ�İ뾶,ֵԽ��뾶Խ��
		bool k_zero = abs(start.y - end.y) < 0.01;
		vector<Point2f> controlPoints;
		if (all_num == break_index) cout << "B spline " << endl;
		if (length_s < 0.001)
		{
			new_cent = ratio * start + (1 - ratio) * end;
			leng_radius = length_two_point2f(new_cent, end);
			Point2f p1, p2;
			if (k_zero)
			{
				p1 = end - Point2f(0, leng_radius);
				if (cos_two_vector((p1 - end), (tile_c - end))<0)
					p1 = end + Point2f(0, leng_radius);
				p2 = new_cent + p1 - end;
			}
			else
			{
				p1 = end - Point2f(leng_radius, 0);
				if (cos_two_vector((p1 - end), (tile_c - end))<0)
					p1 = end + Point2f(leng_radius, 0);
				p2 = new_cent + p1 - end;
			}
			controlPoints.push_back(start);
			controlPoints.push_back(new_cent);
			controlPoints.push_back(p2);
			controlPoints.push_back(p1);
			controlPoints.push_back(end);
		}
		if (length_e < 0.001)
		{
			new_cent = (1 - ratio) * start + ratio * end;
			leng_radius = length_two_point2f(new_cent, start);
			Point2f p1, p2;
			if (k_zero)
			{
				p1 = start - Point2f(0, leng_radius);
				if (cos_two_vector((p1 - start), (tile_c - start))<0)
					p1 = start + Point2f(0, leng_radius);
				p2 = new_cent + p1 - start;
			}
			else
			{
				p1 = start - Point2f(leng_radius, 0);
				if (cos_two_vector((p1 - start), (tile_c - start))<0)
					p1 = start + Point2f(leng_radius, 0);
				p2 = new_cent + p1 - start;
			}
			controlPoints.push_back(start);
			controlPoints.push_back(p1);
			controlPoints.push_back(p2);
			controlPoints.push_back(new_cent);
			controlPoints.push_back(end);
		}
		arc_line = generate_b_spline(controlPoints);
		int tem_size = arc_line.size();
		double s_deriv = com_derivative(arc_line[0], arc_line[2]);
		double s_curva = com_curvature(arc_line[0], arc_line[1], arc_line[2]);
		double e_deriv = com_derivative(arc_line[tem_size - 3], arc_line[tem_size - 1]);
		double e_curva = com_curvature(arc_line[tem_size - 3], arc_line[tem_size - 2], arc_line[tem_size - 1]);
		s_deriv = floor(s_deriv * 10000.000f + 0.5) / 10000.000f;
		s_curva = floor(s_curva * 10000.000f + 0.5) / 10000.000f;
		e_deriv = floor(e_deriv * 10000.000f + 0.5) / 10000.000f;
		e_curva = floor(e_curva * 10000.000f + 0.5) / 10000.000f;
		curvas = { s_deriv, s_curva, e_deriv, e_curva };
	}
	else
	{
		//cout << "Vs_c  " << Vs_c << "Ve_c" << Ve_c << endl;
		double cos_2v = cos_two_vector(Vs_c, Ve_c);
		double sin_2v = sin_two_vector(Vs_c, Ve_c);
		//cout << "sin_2v  " << sin_2v << endl;
		cos_2v = floor(cos_2v * 10000.000f + 0.5) / 10000.000f;
		sin_2v = floor(sin_2v * 10000.000f + 0.5) / 10000.000f;
		double angle = PI;
		//ȷ�������Ƕȵ�����
		if (abs(sin_2v) < 0.00001) //˵��180��,��Բ������ֱ����1/R����
		{
			if (all_num == break_index) cout << "Circle curve; " << endl;
			double new_leng = length_two_point2f(start, end) / 2;
			//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
			double new_x = unit_vs.x*cos(angle / 2) - unit_vs.y*sin(angle / 2);
			double new_y = unit_vs.x*sin(angle / 2) + unit_vs.y*cos(angle / 2);
			Point2f new_p = Point2f(new_leng*new_x, new_leng*new_y) + cent;
			if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) < 0) //��ͬ��˵���ڲ�ͬ��
			{
				angle = -angle;
				if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) > 0) cout << "succeed!" << endl;
			}
			for (int i = 0; i <= arc_line_num; i++)
			{
				double new_angle = i * angle / arc_line_num; //ÿ�������ĽǶȼ��
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = unit_vs.x * cos(new_angle) - unit_vs.y * sin(new_angle);
				double new_y = unit_vs.x * sin(new_angle) + unit_vs.y * cos(new_angle);
				Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
				arc_line.push_back(new_point);
			}
			double curva = 1 / new_leng;
			if (start.x == end.x) curvas = { 0, curva, 0, curva };
			else if (start.y == end.y) curvas = { 10000, curva, 10000, curva };
		}
		else //��180��Ϊ90,������Բ��,��Բ������:��(a,0)��Ϊa/b^2,��(0,b)��Ϊb/a^2  ��Բ��������x=a*cos  y=b*sin
		{
			if (all_num == break_index) cout << "Ellipse curve; " << endl;
			double length_s = length_two_point2f(start, cent);
			double length_e = length_two_point2f(end, cent);
			Point2f unit_c_s = 1.0 / arc_line_num * (cent - start);
			Point2f unit_c_e = 1.0 / arc_line_num * (cent - end);
			//cout << "uit_c_s: " << unit_c_s << "   unit_c_e" << unit_c_e<<endl;
			bool s_xaxis = abs(start.y - cent.y) < 0.01;
			//cout << "start: " << start << "  end: " << end << "   cent: " << cent << endl;

			//��������
			double theta = 0;
			Point2f aa = start - cent;
			Point2f bb = end - cent;
			double a, b;
			if (abs(aa.x - 0) < 0.0001)
			{
				a = bb.x;
				b = aa.y;
			}
			else
			{
				a = aa.x;
				b = bb.y;
			}
			while (theta <= 90)
			{
				double dx = a*cos(theta*PI / 180.0);
				double dy = b*sin(theta*PI / 180.0);
				Point2f tp = Point2f(dx, dy) + cent;
				arc_line.push_back(tp);
				theta += (90.0 / arc_line_num);
				//cout << tp.x << " " << tp.y << endl;
			}
			if (s_xaxis == 0)
				reverse(arc_line.begin(), arc_line.end());
			curvas = { 10000, length_s / (length_e*length_e), 0, length_e / (length_s*length_s) };
		}
	}
	curvatures = curvas;
	return arc_line;
}


vector<Point2f> arc_gen_h(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures)
{
	int break_index = -1;
	//cout << "all_num" << all_num << endl;
	if (all_num == break_index) cout << "start��" << start << " end:  " << end << " cent:  " << cent << endl;
	//���ͬһ���ϵ����㣬��ʱ����tile���ĵ���ȷ��������	
	int arc_line_num = 30; //ÿ�������ϵĵ���
	//cout << arc_line_num << endl;
	vector<double> curvas;
	vector<Point2f> arc_line;
	Point2f Vs_c = start - cent;
	Point2f Ve_c = end - cent;
	Point2f unit_vs = unit_vec(Vs_c);
	double length_s = length_two_point2f(start, cent);
	double length_e = length_two_point2f(end, cent);
	//���������˵㶼�ڶ����������������������־���ں���R_Edge��input_curva�����м�������б��
	if (length_s < 0.001&&length_e < 0.001)
	{
		arc_line.push_back(cent);
		//����֮������,���ʶ�Ϊ0,���Է���{0,0}
		curvas = { 0, 0 };
		if (all_num == break_index) cout << "Two endpoints are peakpoints" << endl;
		//return arc_line;
	}
	else if (length_s < 0.001 || length_e < 0.001) //����ĳ���˵��ڶ��������������������Ƶ������м仭b����
	{
		if (all_num == break_index) cout << "Hermite curve " << endl;
		vector<Point2f> controlPoints;
		double ratio1 = 1.2;
		double ratio2 = 2;
		if (length_s < 0.001)
		{
			Point2f r0 = ratio1 * (end - start);
			Point2f r1 = ratio2 * Point2f(-r0.y, r0.x);
			if (cos_two_vector(r1, (tile_c - end)) > 0) r1 = -r1;
			controlPoints.push_back(start);
			controlPoints.push_back(end);
			controlPoints.push_back(r0);
			controlPoints.push_back(r1);
		}
		else if (length_e < 0.001)
		{
			Point2f r1 = ratio1 * (end - start);
			Point2f r0 = ratio2 * Point2f(-r1.y, r1.x);
			if (cos_two_vector(r0, (tile_c - start)) < 0) r0 = -r0;
			controlPoints.push_back(start);
			controlPoints.push_back(end);
			controlPoints.push_back(r0);
			controlPoints.push_back(r1);
		}
		vector<Point2f> HermP;
		arc_line = generate_hermite(controlPoints, HermP); //����hermite��ϵ��������0,1ʱ������
		int tem_size = arc_line.size();
		double s_deriv = com_derivative(arc_line[0], arc_line[2]);
		double s_curva = com_curvature(arc_line[0], arc_line[1], arc_line[2]);
		double e_deriv = com_derivative(arc_line[tem_size - 3], arc_line[tem_size - 1]);
		double e_curva = com_curvature(arc_line[tem_size - 3], arc_line[tem_size - 2], arc_line[tem_size - 1]);
		s_deriv = floor(s_deriv * 10000.000f + 0.5) / 10000.000f;
		s_curva = floor(s_curva * 10000.000f + 0.5) / 10000.000f;
		e_deriv = floor(e_deriv * 10000.000f + 0.5) / 10000.000f;
		e_curva = floor(e_curva * 10000.000f + 0.5) / 10000.000f;
		curvas = { s_deriv, s_curva, e_deriv, e_curva };
	}
	else
	{
		//cout << "Vs_c  " << Vs_c << "Ve_c" << Ve_c << endl;
		double cos_2v = cos_two_vector(Vs_c, Ve_c);
		double sin_2v = sin_two_vector(Vs_c, Ve_c);
		//cout << "sin_2v  " << sin_2v << endl;
		cos_2v = floor(cos_2v * 10000.000f + 0.5) / 10000.000f;
		sin_2v = floor(sin_2v * 10000.000f + 0.5) / 10000.000f;
		double angle = PI;
		//ȷ�������Ƕȵ�����
		if (abs(sin_2v) < 0.00001) //˵��180��,��Բ������ֱ����1/R����
		{
			if (all_num == break_index) cout << "Circle curve; " << endl;
			double new_leng = length_two_point2f(start, end) / 2;
			//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
			double new_x = unit_vs.x*cos(angle / 2) - unit_vs.y*sin(angle / 2);
			double new_y = unit_vs.x*sin(angle / 2) + unit_vs.y*cos(angle / 2);
			Point2f new_p = Point2f(new_leng*new_x, new_leng*new_y) + cent;
			if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) < 0) //��ͬ��˵���ڲ�ͬ��
			{
				angle = -angle;
				if (sin_two_vector(start - end, tile_c - end)*sin_two_vector(start - end, new_p - end) > 0) cout << "succeed!" << endl;
			}
			for (int i = 0; i <= arc_line_num; i++)
			{
				double in_angle = angle / arc_line_num; //ÿ�������ĽǶȼ��
				double new_angle = i*in_angle;
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = unit_vs.x * cos(new_angle) - unit_vs.y * sin(new_angle);
				double new_y = unit_vs.x * sin(new_angle) + unit_vs.y * cos(new_angle);
				Point2f new_point = Point2f(new_leng*new_x, new_leng*new_y) + cent;
				arc_line.push_back(new_point);
			}
			double curva = 1 / new_leng;
			if (start.x == end.x) curvas = { 0, curva, 0, curva };
			else if (start.y == end.y) curvas = { 10000, curva, 10000, curva };
		}
		else //��180��Ϊ90,����hermite����
		{
			//if (all_num == break_index) cout << "Ellipse curve; " << endl;
			//double length_s = length_two_point2f(start, cent);
			//double length_e = length_two_point2f(end, cent);
			//Point2f unit_c_s = 1.0 / arc_line_num * (cent - start);
			//Point2f unit_c_e = 1.0 / arc_line_num * (cent - end);
			////cout << "uit_c_s: " << unit_c_s << "   unit_c_e" << unit_c_e<<endl;
			//bool s_xaxis = abs(start.y - cent.y) < 0.01;
			////cout << "start: " << start << "  end: " << end << "   cent: " << cent << endl;
			//if (s_xaxis) //start ����x����
			//{
			//	for (int i = 0; i <= arc_line_num; i++)
			//	{
			//		Point2f tem_p = start + i*unit_c_s;
			//		double tem_x = tem_p.x - cent.x;
			//		tem_x = tem_x*tem_x / (length_s*length_s);
			//		int flag = -1;
			//		if (unit_c_e.y < 0) flag = -flag;
			//		double tem_y = cent.y + flag*sqrt(length_e*length_e*(1 - tem_x));
			//		arc_line.push_back(Point2f(tem_p.x, tem_y));
			//		/*cout << "Point:  " << Point2f(tem_p.x, tem_y) << endl
			//		<< "   unit_c_e: " << unit_c_e << "  flag: " << flag << endl;*/
			//	}
			//	curvas = { 10000, length_s / (length_e*length_e), 0, length_e / (length_s*length_s) };
			//}
			//else  //end ����x����
			//{
			//	for (int i = 0; i <= arc_line_num; i++)
			//	{
			//		Point2f tem_p = cent - i*unit_c_e;
			//		double tem_x = tem_p.x - cent.x;
			//		tem_x = tem_x*tem_x / (length_e*length_e);
			//		int flag = -1;
			//		if (unit_c_s.y < 0) flag = -flag;
			//		double tem_y = cent.y + flag*sqrt(length_s*length_s*(1 - tem_x));
			//		arc_line.push_back(Point2f(tem_p.x, tem_y));
			//		/*cout << "tem_x:  " << tem_x << "  tem_y" << tem_y<<endl<<"   Point:  " << Point2f(tem_p.x, tem_y) << endl
			//		<< "   unit_c_e: " << unit_c_e << "  flag: " << flag << endl;*/
			//	}
			//	curvas = { 0, length_s / (length_e*length_e), 10000, length_e / (length_s*length_s) };
			//}
			if (all_num == break_index) cout << "Ellipse Hermite curve; " << endl;
			vector<Point2f> controlPoints;
			Point2f cent_ = Point2f(start.x, end.y);
			if (length_two_point2f(cent_, cent)<0.1) cent_ = Point2f(end.x, start.y);
			Point2f r0 = 1.5 * (cent_ - start);
			Point2f r1 = 1.5 * (end - cent_);
			controlPoints.push_back(start);
			controlPoints.push_back(end);
			controlPoints.push_back(r0);
			controlPoints.push_back(r1);

			vector<Point2f> HermP;
			arc_line = generate_hermite(controlPoints, HermP); //����hermite��ϵ��������0,1ʱ������
			int tem_size = arc_line.size();
			double s_deriv = com_derivative(arc_line[0], arc_line[2]);
			double s_curva = com_curvature(arc_line[0], arc_line[1], arc_line[2]);
			double e_deriv = com_derivative(arc_line[tem_size - 3], arc_line[tem_size - 1]);
			double e_curva = com_curvature(arc_line[tem_size - 3], arc_line[tem_size - 2], arc_line[tem_size - 1]);
			s_deriv = floor(s_deriv * 10000.000f + 0.5) / 10000.000f;
			s_curva = floor(s_curva * 10000.000f + 0.5) / 10000.000f;
			e_deriv = floor(e_deriv * 10000.000f + 0.5) / 10000.000f;
			e_curva = floor(e_curva * 10000.000f + 0.5) / 10000.000f;
			curvas = { s_deriv, s_curva, e_deriv, e_curva };

		}
	}
	curvatures = curvas;
	return arc_line;
}


vector<Point2f> semicir_gen(Point2f start, Point2f end, Point2f cent)
{
	//�ȼ����xos
	Point2f x_axis(1, 0);
	Point2f Vs_c = start - cent;
	Point2f Ve_c = end - cent;
	double cos_s_x = floor(cos_two_vector(x_axis, Vs_c) * 10000.000f + 0.5) / 10000.000f;
	double sin_s_x = floor(sin_two_vector(x_axis, Vs_c) * 10000.000f + 0.5) / 10000.000f;
	double angle_s = acos(cos_s_x);
	//cout << "angle_s1: " << angle_s / PI * 180 << endl;
	if (asin(sin_s_x < 0)) angle_s = -angle_s;
	//cout << "angle_s1: " << angle_s / PI * 180 << endl;
	//�ټ����soe
	double cos_se = floor(cos_two_vector(Vs_c, Ve_c) * 10000.000f + 0.5) / 10000.000f;
	double sin_se = floor(sin_two_vector(Vs_c, Ve_c) * 10000.000f + 0.5) / 10000.000f;
	double angle_se = acos(cos_se);
	//cout << "angle_se1: " << angle_se / PI * 180 << endl;
	if (asin(sin_se < 0)) angle_se = -angle_se;
	//cout << "angle_se2: " << angle_se / PI * 180 << endl;

	//��Բ
	int semicir_size = 20;
	vector<Point2f> semicir;
	double angle_ = angle_se / semicir_size;
	semicir.push_back(start);
	double radius = length_two_point2f(start, cent);
	for (int i = 1; i < semicir_size; i++)
	{
		double new_angle = i * angle_ + angle_s; //ÿ�������ĽǶȼ��
		//cout << "new_angle: " << new_angle / PI * 180 << endl;
		double new_x = radius * cos(new_angle);
		double new_y = radius * sin(new_angle);
		Point2f new_point = Point2f(new_x, new_y);
		semicir.push_back(new_point + cent);
	}
	semicir.push_back(end);
	return semicir;

}

double N3(int i, double u)
{
	double t1 = 1 - u;
	double t2 = 1 - 2 * u;
	double t3 = 2 - 3 * u;
	switch (i)
	{
	case 0:
	{
		if (0 <= u && u < 0.5)
			return t2*t2*t2;
		else return 0;
	}
	case 1:
	{
		if (0 <= u && u < 0.5)
			return 2 * u*t2*t2 + 2 * t1*u*t3;
		else return 2 * t1*t1*t1;
	}
	case 2:
	{
		if (0 <= u && u < 0.5)
			return 2 * u*u*(t3 + t1);
		else return t1*t1*(8 * u - 2);
	}
	case 3:
	{
		if (0 <= u && u < 0.5)
			return 2 * u*u*u;
		else return 2 * t1*(3 * u*u - u + t2*t2);
	}
	case 4:
	{
		if (0 <= u && u < 0.5)
			return 0;
		else return -t2*t2*t2;
	}
	}

	/*double t = 1 - u;
	switch (i)
	{
	case 0:
	return t*t*t;
	case 1:
	return 3*u*t*t;
	case 2:
	return 3*u*u*t;
	case 3:
	return u*u*u;
	}*/
}

vector<Point2f> generate_b_spline(vector<Point2f> ctrlPoints)
{
	vector<Point2f> curvePoints;
	for (double u = 0; u <= 1.01; u += 0.01)
	{
		Point2f tmp(0, 0);
		for (int i = 0; i<ctrlPoints.size(); i++)
		{
			Point2f t = ctrlPoints[i];

			t *= N3(i, u);

			tmp += t;
		}
		curvePoints.push_back(tmp);
	}
	return curvePoints;
}
vector<Point2f> generate_hermite(vector<Point2f> ctrlPoints, vector<Point2f>& HermP)  //ctrlPoints 4����ֱ���p0, p1, r0, r1
{
	HermP = HermiteP(ctrlPoints);
	vector<Point2f> curvePoints;
	for (double u = 0; u <= 1.01; u += 0.05)
	{
		Point2f tmp = u*u*u*HermP[0] + u*u*HermP[1] + u*HermP[2] + HermP[3];// (0, 0);
		/*tmp += (2 * u*u*u - 3 * u*u + 1)*ctrlPoints[0];
		tmp += (-2 * u*u*u + 3 * u*u)*ctrlPoints[1];
		tmp += (u*u*u - 2 * u*u + u)*ctrlPoints[2];
		tmp += (u*u*u - u*u)*ctrlPoints[3];*/
		curvePoints.push_back(tmp);
	}
	return curvePoints;
}

vector<Point2f> HermiteP(vector<Point2f> ctrlPoints) //���������˵㼰����ȷ��hermite����ϵ��a,b,c,d
{
	vector<Point2f> Cpoint;
	int ctrlsize = ctrlPoints.size();  //p0,p1,r0,r1
	//cout << " ctrlPoints:  " << ctrlPoints.size() << endl;
	Point2f a = 2 * ctrlPoints[0] - 2 * ctrlPoints[1] + ctrlPoints[2] + ctrlPoints[3];
	Point2f b = -3 * ctrlPoints[0] + 3 * ctrlPoints[1] - 2 * ctrlPoints[2] - ctrlPoints[3];
	Point2f c = ctrlPoints[2];
	Point2f d = ctrlPoints[0];
	Cpoint.push_back(a);
	Cpoint.push_back(b);
	Cpoint.push_back(c);
	Cpoint.push_back(d);
	//ctrlPoints p0,p2 are endpoints, p1-p0, p3-p2 are tangent vector
	return Cpoint;
}

void fileout(string filepath, vector<cv::Point> contour_)
{
	ofstream out(filepath);
	if (out.is_open())
	{
		out << contour_.size() << endl;//contours[0].size()
		for (int j = 0; j < contour_.size(); j++)
			out << contour_[j].x << "," << contour_[j].y << endl;
		//out << contour_[0].x << "," << contour_[0].y << endl;  //��β������
	}
	cout << "contours[0].size(): " << contour_.size() << endl;
	out.close();
}

void fileout_array(string filepath, int index_tiles[][Array_num], int row, int col)
{
	ofstream out(filepath);
	if (out.is_open())
	{
		for (int b = 0; b < row; b++)
		{
			for (int d = 0; d < col; d++)
			{
				out << index_tiles[b][d] << "  ";
			}
			out << endl;
		}		
	}
	out.close();
}

vector<vector<int>> filein_array(string filepath, int col)
{
	vector<vector<int>> index_tiles;
	ifstream in(filepath);
	if (in.is_open())
	{
		vector<int> index_row;
		int index_;
		int num = 0;
		while (!in.eof())
		{
			in >> index_;
			if (in.eof())
				break;
			index_row.push_back(index_);
			num++;
			if (num == col)
			{
				index_tiles.push_back(index_row);
				index_row.swap(vector<int>());
				num = num % col;
			}
		}
	}
	in.close();
	return index_tiles;
}

vector<Point2f> readTxt(string filepath)
{
	vector<Point2f> con_point;
	//��ȡһ��������������ļ�����ʽ��Ӧ��һ�����������㱣����ļ�
	ifstream in(filepath);
	string s;
	if (!in.is_open())
	{
		cout << "δ�ɹ����ļ�" << endl;
	}
	double number1, number2;
	getline(in, s);
	while (!in.eof())
	{
		char ccc;
		vector<Point2f> c;
		in >> number1;
		in >> ccc;
		in >> number2;
		if (in.eof())
			break;
		//cout << number1 << "  " << ccc << "  " << number2 << endl;
		con_point.push_back(Point2f(number1, number2));
	}

	in.close();
	return con_point;

}

void getString(string line, vector<string> &Line)
{
	string temp;
	for (int i = 0; i < line.length(); i++)
	{
		if (line[i] == ' ')
		{
			Line.push_back(temp);
			temp = "";
		}
		else
			temp = temp + line[i];
	}
	Line.push_back(temp);
}

void write_text(string name, int scale, vector<pair<double, int> >txt)
{
	ofstream outfile(name, ios::app);
	for (int i = 0; i < txt.size(); i++)
	{
		outfile << scale << " " << txt[i].first << " " << txt[i].second << endl;
	}
	outfile.close();
}

void write_obj(string filepath, vector<Point2f> contour, Point2f shift, double height)
{
	double H = height;//ģ�ͺ��
	int sizec = contour.size();
	ofstream outfile1(filepath, ios::out);
	//ע��������.obj�ļ���ʱ�������Ϣ���ɶ����±�+1��ɵģ��Ǵ�1��ʼ�ģ�������������0��ʼ������
	if (!outfile1)
	{
		cerr << "open error";
		exit(1);
	}

	outfile1 << "#List of geometric vertices, with (x,y,z) coordinates" << endl;

	for (int i = 0; i < sizec; i++)
	{
		contour[i] += shift;
		outfile1 << "v" << " " << contour[i].x << " " << contour[i].y << " " << 0 << endl;
	}
	for (int i = 0; i < sizec; i++)
	{
		outfile1 << "v" << " " << contour[i].x << " " << contour[i].y << " " << H << endl;
	}
	outfile1 << "#Polygonal face element" << endl;

	vector<vector<int>> face;
	vector<int> f;
	Rect rc = Rect(0, 0, 600, 600);//������ͼ��Ĵ�С
	//cout << "doing triangulation..." << endl;
	vector<Vec3i> tri;
	TriSubDiv(contour, rc, tri);
	for (int i = 0; i < tri.size(); i++)
	{
		face.push_back(vector<int>{tri[i][0] + 1, tri[i][2] + 1, tri[i][1] + 1});
		face.push_back(vector<int>{tri[i][0] + sizec + 1, tri[i][1] + sizec + 1, tri[i][2] + sizec + 1});
	}

	for (int i = 0; i < sizec; i++)
	{
		f.push_back(i + 1);
		f.push_back((i + 1) % sizec + 1);
		f.push_back((i + 1) % sizec + sizec + 1);
		face.push_back(f);
		f.swap(vector<int>());

		f.push_back((i + 1) % sizec + sizec + 1);
		f.push_back(i + sizec + 1);
		f.push_back(i + 1);
		face.push_back(f);
		f.swap(vector<int>());
	}
	for (int i = 0; i < face.size(); i++)
	{
		outfile1 << "f";//ע��������.obj�ļ���ʱ�������Ϣ���ɶ����±�+1��ɵģ��Ǵ�1��ʼ�ģ������������ж����±���ɣ�Ҳ���ǲ�������0��ʼ����
		int sizef = face[i].size();
		for (int j = 0; j < sizef; j++)
		{
			outfile1 << " " << face[i][j];

		}
		outfile1 << endl;
	}
	outfile1.close();
}


void create_svg(string svg_path)
{
	ofstream outfile(svg_path);
	outfile << "<?xml version=\"1.0\" standalone=\"no\"?>" << endl
		<< "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\"" << endl
		<< "\"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">" << endl << endl;
	outfile << "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">" << endl;
	outfile.close();
}

//��tile����Ϊsvg��ʽ,ps:ֻ����ʸ��Ԫ��,����ļ�ͷβ����Ҫ����д��
void save_tile_svg(string svg_path, vector<Point2f> contour, Scalar color, Point2f shift, double zoom_scale)
{
	if (_access(svg_path.c_str(), 0) == -1) return;
	ofstream outfile(svg_path, ios::app);
	outfile << " <polygon points=\" ";
	//cout << " polygon points: " << contour[0] << endl;
	for (int i = 0; i < contour.size(); i++)
	{
		Point2f one = zoom_scale * contour[i] + shift;
		outfile << one.x << "," << one.y << " ";
	}
	outfile << "\"" << endl << "style=\"fill:rgb(" << to_string(int(color[2])) << "," << to_string(int(color[1])) << "," << to_string(int(color[0])) << ")\"/>" << endl;
	outfile.close();
}

void add_word_svg(string svg_path, string word, Scalar color, Point2f shift)
{
	if (_access(svg_path.c_str(), 0) == -1) return;
	ofstream outfile(svg_path, ios::app);
	outfile << " <text x = \"" << shift.x << "\" y = \"" << shift.y << "\" fill=\"rgb(" << to_string(int(color[2])) << "," << to_string(int(color[1])) << "," << to_string(int(color[0])) << ")\">";
	outfile << word << "</text> " << endl;
	outfile.close();
}

void end_svg(string &svg_path)
{
	if (_access(svg_path.c_str(), 0) == -1)
		return;
	ofstream outfile(svg_path, ios::app);
	outfile << "</svg>" << endl;
	outfile.close();
	svg_path.clear();
}


string d2s_mant(double number, int mantissa)
{
	stringstream ss;
	ss << setiosflags(ios::fixed) << setprecision(mantissa) << number << endl;
	string x_value_s;
	ss >> x_value_s;
	return x_value_s;
}



vector<Point2f> mix_contour(vector<vector<Point2f>> contours) //opencv 
{
	int break_index = -1;
	//cout << "all_num" << all_num << endl;
	if (all_num == break_index) cout << "break_index��" << break_index << endl;
	vector<Point2f> mixC;
	if (!poly_group(contours)) //û���ص����޷��ϲ���һ����ֱ�ӷ��ؿ�����
	{
		return  mixC;
	}
	int width = 300;
	int height = 300;
	Mat draw = Mat(height, width, CV_8UC3, Scalar(255, 255, 255));
	double xm = 0;
	double ym = 0;
	for (int i = 0; i < contours.size(); i++)
	{
		int n = contours[i].size();
		//cout << "n: " << n << endl;
		Point rook_points[1][2000];
		for (int j = 0; j < n; j++)
		{
			rook_points[0][j] = contours[i][j];
			if (contours[i][j].x>xm) xm = contours[i][j].x;
			if (contours[i][j].y>ym) ym = contours[i][j].y;
		}
		const Point* ppt[1] = { rook_points[0] };
		int npt[] = { n };
		fillPoly(draw,
			ppt,
			npt,
			1,
			Scalar(0, 0, 0) //��ɫ
							//Scalar(255, 255, 255) //��ɫ
		);
	}
	//cout << xm << "  " << ym << endl;
	if (all_num == break_index)	imshow("ttt", draw);
	vector<vector<cv::Point> > Contours;
	vector<Vec4i> hierarchy;

	//��candy���ɻҶ�ͼ�������ͼ
	cvtColor(draw, draw, COLOR_BGR2GRAY);
	GaussianBlur(draw, draw, Size(3, 3), 10, 10);
	threshold(draw, draw, 128, 255, cv::THRESH_BINARY); //255 white
	blur(draw, draw, Size(2, 2));
	//GaussianBlur(draw, draw, Size(4, 4), 10, 10);
	Canny(draw, draw, 100, 200, 3);
	//imshow("canny_output", draw);
	//������ͼ�������������
	findContours(draw, Contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE, cv::Point(0, 0));
	//imshow("ttt123", draw);
	//cout << "contours num:" << Contours.size() << endl;
	double xm_ = 0;
	double ym_ = 0;
	for (int t = 0; t < Contours[0].size(); t++)
	{
		mixC.push_back(Contours[0][t]);
		//if (Contours[0][t].x>xm_) xm_ = Contours[0][t].x;
		//if (Contours[0][t].y>ym_) ym_ = Contours[0][t].y;
	}
	//cout << xm_ << "  " << ym_ << endl;
	//show mixC
	if (all_num == break_index)
	{
		Mat draw2 = Mat(height, width, CV_8UC3, Scalar(255, 255, 255));
		int n = mixC.size();
		cout << "n: " << n << endl;
		Point rook_points[1][2000];
		for (int j = 0; j < n; j++)
		{
			rook_points[0][j] = mixC[j];
		}
		const Point* ppt[1] = { rook_points[0] };
		int npt[] = { n };
		fillPoly(draw2,
			ppt,
			npt,
			1,
			Scalar(0, 0, 0) //��ɫ
							//Scalar(255, 255, 255) //��ɫ
		);
		imshow("final", draw2);

		Mat draw22 = Mat(height, width, CV_8UC3, Scalar(255, 255, 255));
		for (int j = 0; j < n / 3; j++)
		{
			circle(draw22, mixC[j], 2, Scalar(255, 0, 0), -1);
		}
		for (int j = n / 3; j < 2 * n / 3; j++)
		{
			circle(draw22, mixC[j], 2, Scalar(0, 255, 0), -1);
		}
		for (int j = 2 * n / 3; j < n; j++)
		{
			circle(draw22, mixC[j], 1, Scalar(0, 0, 255), -1);
		}

		imshow("final2", draw22);
	}

	return mixC;
}
vector<Point2f> polyline_gen(Point2f start, Point2f end, Point2f cent, vector<double>& curvatures)
{
	Point2f mid_p = Point2f(start.x, end.y);
	vector<double> curvas = { 10000,0,0,0 };
	if (length_two_point2f(mid_p, cent) < 0.1)
	{
		mid_p = Point2f(end.x, start.y);
		curvas = { 0, 0, 10000, 0 };
	}
	vector<Point2f> polyline = { start, mid_p, end };
	curvatures = curvas;
	return polyline;
}


double normalize(double x, double y)  //����ȡ�������ȡ��
{
	for (double i = 0; i <= 1; i += y)
	{
		if (x - i >= 0 && x - (i + y) < 0)
		{
			if (abs(x - i) > abs(i + y - x))
			{
				return i + y;
			}
			else return i;
		}		
	}

	/*for (double i = 0; i <= 1; i += y)
	{
		if (x - i >= 0 && x - (i + y) < 0)
			return i;
	}*/

}

void image_histogram(string image_path, int unit_size, int patch_size) //for 3*3, patch_size=3;
{
	Mat src;
	vector<int> num_density_gradient(20, 0);
	vector<double> range_density = { 0, 1 };
	double density_grad = (range_density[1] - range_density[0]) / num_density_gradient.size();
	src = imread(image_path, IMREAD_GRAYSCALE);
	if (src.empty())
	{
		cerr << "No image supplied ..." << endl;
		return;
	}
	int col = src.cols;
	int row = src.rows;
	int num_col = col / unit_size;
	int num_row = row / unit_size;
	int patch_area = pow(patch_size*unit_size, 2);
	cout << image_path << endl << "density_gradient: " << density_grad <<
		"  col: " << col << "  row: " << row << "  num_col: " << num_col << " num_row: " << num_row << "  patch_area: " << patch_area << endl;
	int count = 0;
	for (int i = 0; i < num_row - patch_size + 1; i++)
	{
		for (int j = 0; j < num_col - patch_size + 1; j++)
		{
			//����ÿ������Ҫ�����ݣ�������ʱֻ����Ҷ���ֵ
			double total_gray = 0;
			for (int ii = i*unit_size; ii < (i + patch_size)*unit_size; ii++)
			{
				for (int jj = j*unit_size; jj < (j + patch_size)*unit_size; jj++)
				{
					total_gray += (int)src.at<uchar>(ii, jj);
				}
			}
			count++;
			total_gray = 1 - total_gray / patch_area / 255;
			//cout << "total_gray: " << total_gray << "   " << (int)(total_gray / 0.05)<< endl;
			num_density_gradient[(int)(total_gray / 0.05)]++;
		}
	}
	cout << "count: " << count << endl;
	int max = 0;
	for (int n = 0; n < 20; n++)
	{
		cout << n << ": " << num_density_gradient[n] << endl;
		if (num_density_gradient[n] > max) max = num_density_gradient[n];
	}
	Mat histImage = draw_histogram(num_density_gradient, range_density);

}

Mat draw_histogram(vector<int> data, vector<double> range, string his_name, Scalar color)
{
	//draw histogram
	int hist_h = 600;
	int hist_w = 900;
	int margin = 100;
	int axis_margin = 40;
	int num_interval = data.size();
	double range_x = range[1] - range[0];
	int max_data = 0;
	for (int i = 0; i < num_interval; i++)
	{
		if (data[i] > max_data) max_data = data[i];
	}
	double each_leng_x = (hist_w - margin - axis_margin) / num_interval;
	double each_range = range_x / num_interval;
	double each_leng_y = (hist_h - margin - axis_margin) / 10.0; //y��ֳ�10��
	//int d_max = int(max_data / 10) * 10;
	double y_inter_value = max_data / 10.0;
	double unit_leng_y = each_leng_y / y_inter_value;

	cout << each_leng_y << "y_inter_value: " << unit_leng_y << endl;

	Point center = Point(50, 40);
	Point x_end = center + Point(hist_w - margin, 0);
	Point y_end = center + Point(0, hist_h - margin);
	Mat histImage(hist_h, hist_w, CV_8UC3, Scalar::all(255));

	//��x���y��
	line(histImage, center, x_end, Scalar::all(0), 1);
	line(histImage, x_end, x_end + Point(-8, 6), Scalar::all(0), 1);
	line(histImage, x_end, x_end + Point(-8, -6), Scalar::all(0), 1);
	for (int xnum = 1; xnum <= num_interval; xnum++)
	{
		line(histImage, Point(each_leng_x*xnum, -3) + center, Point(each_leng_x*xnum, 3) + center, Scalar::all(0), 1);
	}

	line(histImage, center, y_end, Scalar::all(0), 1);
	line(histImage, y_end, y_end + Point(-6, -8), Scalar::all(0), 1);
	line(histImage, y_end, y_end + Point(6, -8), Scalar::all(0), 1);
	for (int ynum = 1; ynum <= 10; ynum++)
	{
		line(histImage, Point(-3, each_leng_y*ynum) + center, Point(3, each_leng_y*ynum) + center, Scalar::all(0), 1);
	}

	circle(histImage, center, 3, Scalar(0, 0, 255), -1);
	for (int i = 0; i < num_interval; i++)
	{
		if (data[i]>0)
			rectangle(histImage, Point(i*each_leng_x, 0) + center, Point((i + 1)*each_leng_x, data[i] * unit_leng_y) + center, color, -1, 8, 0);
	}
	flip(histImage, histImage, 0);

	for (int xnum = 0; xnum <= num_interval; xnum++)
	{
		stringstream ss;
		ss << setiosflags(ios::fixed) << setprecision(2) << xnum*each_range << endl;
		string x_value;
		ss >> x_value;
		putText(histImage, x_value, Point(each_leng_x*xnum + center.x - 10, hist_h - center.y + 15), CV_FONT_HERSHEY_SCRIPT_COMPLEX, 0.35, CV_RGB(0, 0, 0), 1.8);
		if (xnum<num_interval && data[xnum]>0)
			putText(histImage, to_string(data[xnum]), Point(each_leng_x*(xnum + 0.15) + center.x, hist_h - data[xnum] * unit_leng_y - center.y - 5), CV_FONT_HERSHEY_SCRIPT_COMPLEX, 0.35, CV_RGB(0, 0, 0), 1.8);
	}
	for (int ynum = 1; ynum <= 10; ynum++)
	{
		/*stringstream ss;
		ss << setiosflags(ios::fixed) << setprecision(2) << (int)ynum*y_inter_value << endl;
		string y_value;
		ss >> y_value;*/
		putText(histImage, to_string((int)(ynum*y_inter_value)), Point(center.x - 35, hist_h - each_leng_y*ynum - center.y), CV_FONT_HERSHEY_SCRIPT_COMPLEX, 0.35, CV_RGB(0, 0, 0), 1.8);
	}

	imshow(his_name, histImage);
	return histImage;
}

double measure_high_frequency(vector<double> density_ima)
{
	int ima_size = sqrt(density_ima.size());
	int count = 0;
	double gradient_error = 0;
	for (int i = 0; i <density_ima.size(); i++)  //�Ҽ���
	{
		if ((i + 1) % ima_size != 0 && i < ima_size*(ima_size - 1))
		{
			double err = sqrt(pow(density_ima[i + 1] - density_ima[i], 2) + pow(density_ima[i + ima_size] - density_ima[i], 2));
			//cout << "err_mea: " << err << endl; 
			gradient_error += err;
			count++;
		}
	}
	//cout << "ave: " << average_error << "  max: " << max_tile_error;
	//cout << "  gradi: " << gradient_error<<endl;
	gradient_error = gradient_error / count;
	return gradient_error;
}

double measure_high_frequency_sober(vector<double> density_ima)
{
	int ima_size = sqrt(density_ima.size());
	//����߽�
	double enlarge[10][10];
	for (int m = 1; m <= ima_size; m++)
	{
		for (int n = 0; n < ima_size + 2; n++)
		{
			if (n == 0) enlarge[m][n] = density_ima[(m - 1)*ima_size];
			else if (n == ima_size + 1) enlarge[m][n] = density_ima[(m - 1)*ima_size + n - 2];
			else enlarge[m][n] = density_ima[(m - 1)*ima_size + n - 1];
		}
	}
	for (int m = 0; m < ima_size + 2; m++)
	{
		for (int n = 0; n < ima_size + 2; n++)
		{
			if (m == 0)
			{
				enlarge[m][n] = enlarge[m + 1][n];
			}
			if (m == ima_size + 1)
			{
				enlarge[m][n] = enlarge[m - 1][n];
			}
		}
	}
	density_ima.swap(vector<double>());
	for (int m = 0; m < ima_size + 2; m++)
	{
		for (int n = 0; n < ima_size + 2; n++)
		{
			density_ima.push_back(enlarge[m][n]);
		}
	}
	// 
	ima_size = sqrt(density_ima.size());
	int count = 0;
	double gradient_error = 0;
	for (int i = 0; i <density_ima.size(); i++)  //�Ҽ���
	{
		if (i % ima_size != 0 && i % ima_size != ima_size - 1 && i < ima_size*(ima_size - 1) && i>ima_size - 1)
		{
			double err_v = -(density_ima[i - ima_size - 1] + 2 * density_ima[i - ima_size] + density_ima[i - ima_size + 1]);
			err_v += (density_ima[i + ima_size + 1] + 2 * density_ima[i + ima_size] + density_ima[i + ima_size + 1]);

			double err_h = -(density_ima[i - ima_size - 1] + 2 * density_ima[i - 1] + density_ima[i + ima_size - 1]);
			err_h += (density_ima[i - ima_size + 1] + 2 * density_ima[i + 1] + density_ima[i + ima_size + 1]);

			double err = sqrt(pow(err_v, 2) + pow(err_h, 2));
			//cout << "err_mea: " << err << endl; 
			gradient_error += err;
			count++;
		}
	}
	//cout << "ave: " << average_error << "  max: " << max_tile_error;
	//cout << "  gradi: " << gradient_error<<endl;
	gradient_error = gradient_error / count;
	return gradient_error;
}


int measure_trend(vector<double> ima)
{
	int d[8][2] = { -1, -1, -1, 0, -1, 1, 0, -1, 0, 1, 1, -1, 1, 0, 1, 1 };
	//1.�жϷ���
	//2.����Ƿ����ݶȷ��򵥵�
	Point2f p(0, 0);//ÿ��sup���ݶȷ���
	int angle = 0;
	int size = sqrt(ima.size());
	for (int ii = 0; ii < ima.size(); ii++)
	{
		int i = ii / size;
		int j = ii%size;

		double x = 0, y = 0;
		for (int k = 0; k<8; k++)
		{
			int dx = i + d[k][0];
			int dy = j + d[k][1];
			if (dx >= 0 && dx < size && dy >= 0 && dy < size)
			{
				x = x + d[k][0] * (ima[dx*size + dy] - ima[i*size + j]);
				y = y + d[k][1] * (ima[dx*size + dy] - ima[i*size + j]);
			}
		}
		p.x += x;
		p.y += y;
	}


	double angle_ = p.y / sqrt(pow(p.x, 2) + pow(p.y, 2));
	angle = acos(angle_)*(180 / PI);

	/*if (sqrt(pow(p.x, 2) + pow(p.y, 2)) < 2)
	return -1;*/

	double angle_thres = 20;
	if ((angle <= angle_thres) || ((angle >= 90 - angle_thres) && (angle <= 90 + angle_thres)) || (angle >= 180 - angle_thres))//��������
	{
		//add �ж��Ƿ񵥵�
		if (angle <= angle_thres)
		{
			vector<double> temp = rotate(ima, 2);
			if (is_monotonic(temp, 1))
				return 0;
			//return angle;
		}
		else if ((angle >= 90 - angle_thres && angle <= 90 + angle_thres) && p.x < 0)
		{
			vector<double> temp = rotate(ima, 1);
			if (is_monotonic(temp, 1))
				return 0;
			//return angle;
		}
		else if ((angle >= 90 - angle_thres && angle <= 90 + angle_thres) && p.x >= 0)
		{
			vector<double> temp = rotate(ima, 3);
			if (is_monotonic(temp, 1))
				return 0;
			//return angle;
		}
		else
		{
			vector<double> temp = rotate(ima, 0);
			if (is_monotonic(temp, 1))
				return 0;
			//return angle;
		}
	}
	else if ((angle > 45 - angle_thres&&angle < 45 + angle_thres) || (angle > 135 - angle_thres&&angle < 135 + angle_thres))
	{

		//add �ж��Ƿ񵥵�
		if (angle > angle_thres && angle < 90 - angle_thres && p.x < 0)
		{
			vector<double> temp = rotate(ima, 1);
			if (is_monotonic(temp, 2))
				return 1;
			//return angle;
		}
		else if (angle > angle_thres && angle < 90 - angle_thres && p.x >= 0)
		{
			vector<double> temp = rotate(ima, 2);
			if (is_monotonic(temp, 2))
				return 1;
			//return angle;
		}
		else if (angle > 90 + angle_thres && angle < 180 - angle_thres && p.x >= 0)
		{
			vector<double> temp = rotate(ima, 3);
			if (is_monotonic(temp, 2))
				return 1;
			//return angle;
		}
		else
		{
			vector<double> temp = rotate(ima, 0);
			if (is_monotonic(temp, 2))
				return 1;
			//return angle;
		}
	}
	return angle;
}

void txt_histogram(string filepath)
{
	vector<int> patch_1(20, 0);
	vector<int> patch_2(20, 0);
	vector<int> patch_3(20, 0);

	vector<int> all_num(3, 0);
	vector<double> range = { 0, 1 };
	ifstream in(filepath);
	string s;
	if (!in.is_open())
	{
		cout << "δ�ɹ����ļ�" << endl;
	}
	int size;
	double value;
	int num;
	while (!in.eof())
	{
		//	//vector<Point2f> c;

		in >> size;
		in >> value;
		in >> num;
		if (in.eof())
			break;
		cout << size << "  " << value << " " << num << endl;
		if (size == 1)
		{
			patch_1[(int)(value / 0.05)] += num;
			all_num[0] += num;
		}
		else if (size == 2)
		{
			patch_2[(int)(value / 0.05)] += num;
			all_num[1] += num;
		}
		else if (size == 3)
		{
			patch_3[(int)(value / 0.05)] += num;
			all_num[2] += num;
		}

	}

	cout << all_num[0] << " " << all_num[1] << " " << all_num[2] << endl;
	in.close();
	draw_histogram(patch_1, range, "patch_1", Scalar(255, 128, 0));
	draw_histogram(patch_2, range, "patch_2", Scalar(255, 0, 128));
	draw_histogram(patch_3, range, "patch_3");
	return;
}



vector<vector<double>> readError(string txtpath, int col, double &min, double &max)
{
	vector<vector<double>> total_e;
	vector<double> error_v;
	min = 10000;
	max = 0;
	ifstream in(txtpath);
	string s;
	if (!in.is_open())
	{
		cout << "δ�ɹ����ļ�" << endl;
	}
	double error_one;
	int count = 0;
	while (!in.eof())
	{
		//	//vector<Point2f> c;

		in >> error_one;
		if (in.eof())
			break;
		count++;
		if (error_one < min) min = error_one;
		if (error_one > max) max = error_one;
		//cout << error_one << endl;
		error_v.push_back(error_one);
		if ((count % col) == 0)
		{
			total_e.push_back(error_v);
			error_v.swap(vector<double>());
		}

	}
	//cout << count << endl;
	in.close();
	return total_e;
}


void draw_error_map(Mat& source, vector<Scalar> colorbar, Point leftBottom, int error_level, int unit_pixels, int num)
{
	Point rightt = leftBottom + Point(unit_pixels*num, unit_pixels*num);
	rectangle(source, leftBottom, rightt, colorbar[error_level], -1);
}

void merge_two_maps(string image1, string error_map, string outpath, int offset)
{
	Mat frame = imread(image1, IMREAD_COLOR);
	Mat error = imread(error_map, IMREAD_COLOR);
	int row = error.rows;
	int col = error.cols;
	int count = 0;
	int count2 = 0;
	cout << col << endl;
	//cout << (int)frame.at<uchar>(100, 100) << endl;
	//cout << (int)frame.at<uchar>(500, 600) << endl;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			Point off(j + offset, i + offset);
			if (j + offset >= frame.cols || j + offset <0 || i + offset >= frame.rows || i + offset <0) continue;
			if ((int)frame.at<Vec3b>(off)[0] != 255 || (int)frame.at<Vec3b>(off)[1] != 255 || (int)frame.at<Vec3b>(off)[2] != 255)
			{
				error.at<Vec3b>(i, j) = frame.at<Vec3b>(off);
				count++;
			}
		}
	}
	imwrite(outpath, error);
	//cout << "count:  " << count << "  " << count2 << endl;
	return;
}

vector<double> rotate(vector<double> A, int c)
{
	vector<double>temp_A = A;
	int n = sqrt(A.size());
	if (c == 0)//nsz0
	{
		temp_A = A;
	}
	else if (c == 1)//nsz90
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = i + 1; j < n; j++)
			{
				swap(A[i*n + j], A[j*n + i]);
			}
		}
		for (int i = 0; i < n / 2; i++)
		{
			for (int j = 0; j < n; j++)
			{
				swap(A[i*n + j], A[(n - 1 - i)*n + j]);
			}
		}
		temp_A = A;
	}
	else if (c == 2)//nsz180
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = i + 1; j < n; j++)
			{
				swap(A[i*n + j], A[j*n + i]);
			}
		}
		for (int i = 0; i < n / 2; i++)
		{
			for (int j = 0; j < n; j++)
			{
				swap(A[i*n + j], A[(n - 1 - i)*n + j]);
			}
		}
		for (int i = 0; i < n; i++)
		{
			for (int j = i + 1; j < n; j++)
			{
				swap(A[i*n + j], A[j*n + i]);
			}
		}
		for (int i = 0; i < n / 2; i++)
		{
			for (int j = 0; j < n; j++)
			{
				swap(A[i*n + j], A[(n - 1 - i)*n + j]);
			}
		}
		temp_A = A;
	}
	else if (c == 3)//nsz270
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n - i; j++)
			{
				swap(A[i*n + j], A[(n - 1 - j)*n + (n - 1 - i)]);
			}
		}
		for (int i = 0; i < n / 2; i++)
		{
			for (int j = 0; j < n; j++)
			{
				swap(A[i*n + j], A[(n - 1 - i)*n + j]);
			}
		}
		temp_A = A;
	}
	return temp_A;
}

void cal_direction(vector<double> vec, double &x, double &y, double &angle)
{
	Point2f p(0, 0);//ÿ��sup���ݶȷ���
	int size = sqrt(vec.size());
	int d[8][2] = { -1,-1,-1,0,-1,1,0,-1,0,1,1,-1,1,0,1,1 };
	for (int ii = 0; ii < vec.size(); ii++)
	{
		int i = ii / size;
		int j = ii%size;

		double x = 0, y = 0;
		for (int k = 0; k<8; k++)
		{
			int dx = i + d[k][0];
			int dy = j + d[k][1];
			if (dx >= 0 && dx < size && dy >= 0 && dy < size)
			{
				x = x + d[k][0] * (vec[dx*size + dy] - vec[i*size + j]);
				y = y + d[k][1] * (vec[dx*size + dy] - vec[i*size + j]);
			}
		}
		p.x += x;
		p.y += y;
	}
	double angle_;
	if (abs(p.x) < 0.001&&abs(p.y) < 0.001) angle_ = 1;
	else angle_ = p.y / sqrt(pow(p.x, 2) + pow(p.y, 2));
	angle = acos(angle_)*(180 / PI);

	x = p.x;
	y = p.y;
}
bool is_monotonic(vector<double> vec, int type/*1:hor 2:dia*/)
{
	double thres = 0.15;

	int size = sqrt(vec.size());
	double a[10][10];
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			a[i][j] = vec[i*size + j];
		}
	}
	int flag = 0;
	vector<int> fanzhuan;
	for (int i = 0; i < size; i++)//every hang
	{
		int flag = 0;
		for (int j = 1; j < size; j++)
		{
			if (a[i][j - 1] - a[i][j] > thres + 0.01)//->
			{
				//fanzhuan.push_back(1);
				flag = 1;
			}
			else if (abs(a[i][j - 1] - a[i][j]) <= thres + 0.01)//--
			{
				//fanzhuan.push_back(0);
				//flag = 0;
			}
			else//<-
			{
				return false;
			}
		}
		fanzhuan.push_back(flag);
	}
	//if (type == 1)
	//{
	//	/*int flag = 1;
	//	for (int i = 0; i < size; i++)
	//	{
	//		if (fanzhuan[i] != 1)
	//			return false;
	//	}
	//	return true;*/

	//	int flag = 1;
	//	for (int i = 0; i < size; i++)
	//	{
	//		if (fanzhuan[i] != 1)
	//			flag = 0;
	//		else
	//		{
	//			if (flag == 0)
	//				return false;
	//		}
	//	}
	//	return true;
	//}
	//else
	//{
	//	int flag = 1;
	//	for (int i = 0; i < size; i++)
	//	{
	//		if (fanzhuan[i] != 1)
	//			flag = 0;
	//		else
	//		{
	//			if (flag == 0)
	//				return false;
	//		}
	//	}
	//}
	return true;
}

bool is_equal_vector(vector<double> a, vector<double> b)
{
	for (int i = 0; i < a.size(); i++)
	{
		if (abs(a[i] - b[i]) > 0.0001)
			return false;
	}
	return true;
}

vector<int> stable_matching(vector<vector<double>> error_map)  //error_map.x represent bound, y represent density
{
	int num = error_map.size();
	if (num == error_map[0].size()) cout << num << " pairs!" << endl;
	else cout << "number does not match!" << endl;

	/*for (int i = 0; i < num; i++)
	{
		cout << endl;
		for (int j = 0; j < num; j++)
		{
			cout << error_map[i][j] << "  ";
		}
	}*/
	//��������
	vector<vector<int>> bound_order;
	vector<vector<int>> density_order;
	for (int i = 0; i < num; i++)
	{
		vector<pair<double, int>> bound_i;
		vector<pair<double, int>> density_i;

		for (int j = 0; j < num; j++)
		{
			bound_i.push_back(make_pair(error_map[i][j], j));
			density_i.push_back(make_pair(error_map[j][i], j));
		}
		sort(bound_i, cmp_pair);
		sort(density_i, cmp_pair);
		/*sort(bound_i.begin(), bound_i.end(), cmp_pair);
		sort(density_i.begin(), density_i.end(), cmp_pair);*/
		//sort(bound_i.begin(), bound_i.end(), cmp_pair);
		bound_order.push_back(assign_order(bound_i));
		density_order.push_back(assign_order(density_i));
	}
	//���ɱ߽�����
	/*vector<vector<int>> temp = bound_order;
	bound_order = density_order;
	density_order = temp;*/
	/*for (int i = 0; i < num; i++)
	{
		cout << endl;
		for (int j = 0; j < num; j++)
		{
			cout << bound_order[i][j] << "  ";
		}
	}
	cout << endl;
	for (int i = 0; i < num; i++)
	{
		cout << endl;
		for (int j = 0; j < num; j++)
		{
			cout << density_order[i][j] << "  ";
		}
	}*/
	cout << endl;
	vector<int> bound_flag(num, -1);
	vector<int> density_flag(num, -1);
	vector<int> query_order(num, 0);
	int all_unpaired = num;
	int itera = 0;
	while (all_unpaired > 0)
	{
		itera++;
		cout << "The " << itera << " round result!" << endl;
		for (int i = 0; i < num; i++)  //for each unpaired "man"-density, compute its partner
		{
			if (density_flag[i] == -1) // density no partner
			{
				int candi_bound = density_order[i][query_order[i]++];
				//cout << "Density: " << i << "  bound: " << candi_bound << "  query_order:" << query_order[i] << endl;
				if (bound_flag[candi_bound] == -1) //bound no partner, pair up
				{
					density_flag[i] = candi_bound;
					bound_flag[candi_bound] = i;
					all_unpaired--;
				}
				else //bound has partner, compare, high order, pair up
				{
					int pre_index = locate_in_order(bound_order[candi_bound], bound_flag[candi_bound]);
					//cout << "Pre candi:" << bound_flag[candi_bound] << "  order: " << pre_index << "   new order:" << locate_in_order(bound_order[candi_bound], bound_flag[i]) << endl;
					if (locate_in_order(bound_order[candi_bound], i) < pre_index)  //high index for new one, replace
					{
						density_flag[bound_flag[candi_bound]] = -1;
						density_flag[i] = candi_bound;
						bound_flag[candi_bound] = i;
					}
				}
			}
		}
		cout << "all_unpaired:" << all_unpaired << endl;
		//all_unpaired--; 
	}
	cout << "itera times: " << itera << endl;
	for (int i = 0; i < num; i++)
		cout << "bound " << i << "  :" << bound_flag[i] << endl;
	for (int i = 0; i < num; i++)
		cout << "density " << i << "  :" << density_flag[i] << endl;
	return bound_flag;

}

bool cmp_pair(pair<double, int> a, pair<double, int> b)
{
	if (a.first == b.first)
		return a.second < b.second;
	else
		return a.first < b.first;
}

vector<int> assign_order(vector<pair<double, int>> order_)
{
	vector<int> int_order;
	int size = order_.size();
	for (int i = 0; i < size; i++)
		int_order.push_back(order_[i].second);
	return int_order;
}

int locate_in_order(vector<int> order_, int num)
{
	for (int i = 0; i < order_.size(); i++)
	{
		if (num == order_[i])
			return i;
	}
	return -1;
}


