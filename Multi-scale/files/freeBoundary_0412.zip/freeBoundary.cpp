#include "freeBoundary.h"

namespace FreeBound{

	vector<Scalar>color_map = {
		Scalar(255, 204, 153), //blue
		Scalar(153, 204, 153), //green
		Scalar(153, 204, 255), //orange	
		Scalar(168, 155, 250), //red
		
		
		Scalar(0, 0, 0)
	};

	string Connect_rules_string[] = {
		"allSelf", "lefttopSelf",
		"leftbottomSelf", "righttopSelf",
		"rightbottomSelf", "lefttopConnect",
		"leftbottomConnect", "sequenceConnect" ,

		"ltrbConnect", "rbltConnect",
		"trblConnect", "bltrConnect",
		"tlrbMidS", "ltbrMidS",
		"trlbMidS", "lbtrMidS",
		"ltArbP", "trAblP", "blAtrP", "rbAltP",
		"leftVacancy", "bottomVacancy",
		"rightVacancy", "topVacancy"
	};


	//--------------------------CS------------------------------------------
	colourScheme::colourScheme()
	{
		//Mu = 0.5;
		//Sigma = 0.1;
		//truncation = 0.4; //truncation
		//k_max = 1.0;
		//gary_scale = 255;
		//interval_num = Edge_pn;
		//color = Scalar(255, 255, 255);
		////com_fun();
	}

	colourScheme::colourScheme(int length)
	{
		edge_length = length;
	}

	colourScheme::colourScheme(double center, double sigma, int gary, Scalar color_, double trunc, double km)
	{
		Mu = center;
		Sigma = sigma;
		truncation = trunc; //truncation
		k_max = km;
		gary_scale = gary;
		color = color_;
		interval_num = Edge_pn;
		point_number = interval_num;
		com_fun();
		//com_fun_mul();
	}

	colourScheme::colourScheme(double center, double sigma, Scalar color_)
	{
		Mu = center;
		Sigma = sigma;
		interval_num = Edge_pn;
		double interval = 1.0 / interval_num;
		double bound1 = center - 0.5*sigma;
		double bound2 = center + 0.5*sigma;
		endPoints.push_back(bound1);
		endPoints.push_back(bound2);
		for (double i = 0.0; i < 1.001; i = i + interval)
		{
			Points.push_back(i);
			if (i >= bound1&&i <= bound2)
			{
				Colors.push_back(color_);
			}
			else Colors.push_back(Scalar(230,230,230));
		}
		cout << "Direct distance: " << abs(endPoints[0] - endPoints[1])<<" endPoints num : " << endPoints.size() << "  " << endPoints[0] << "  " << endPoints[1] << endl;
		
	}

	colourScheme::~colourScheme(){}

	void colourScheme::com_fun()
	{
		double interval = 1.0 / interval_num;
		bool flip = false;//��ת��־����flag���־һ��ʱ�����˵����
		int flag = 1;
		for (double i = 0.0; i < 1.001; i = i + interval)
		{
			Points.push_back(i);
			double length = pow((i - Mu), 2);
			double k_value = k_max * pow(e, (-length / (2 * pow(Sigma, 2))));
			Values.push_back(k_value);
			if (flag*k_value > flag*truncation)
			{
				flag = -flag;
				if (flag == -1)	endPoints.push_back(i);
				else endPoints.push_back(i - interval);
				/*if (flag == flip)
				{
					endPoints.push_back(i);
					flip = -flip;
				}*/
			}
		}
		if (endPoints.size() == 1) endPoints.push_back(Points[Points.size() - 1]);
		cout << "endPoints num:  " << endPoints.size() << "  dist: " << abs(endPoints[0]-endPoints[1]) << "  " << endPoints[0] << "  " << endPoints[1] << endl;
		int max_s = max(max(color.val[0], color.val[1]), color.val[2]);
		int num = Values.size();
		//int gray_trunc = truncation*gary_scale;
		//int gray_base = 255 - gray_trunc;
		for (int i = 0; i < num; i++)
		{
			int gray[3];
			for (int j = 0; j < 3; j++)
			{
				int gray_other = (1 - Values[i]) * gary_scale;
				if (color.val[j] == max_s) gray[j] = Values[i] * color.val[j] + gray_other;
				else gray[j] = gray_other;
			}
			Colors.push_back(Scalar(gray[0], gray[1], gray[2]));
		}
	}

	void colourScheme::com_fun_mul()
	{
		double interval = 1.0 / interval_num;
		bool flip = false;//��ת��־����flag���־һ��ʱ�����˵����
		int flag = 1;
		do
		{
			Points.clear();
			Values.clear();
			endPoints.clear();
			int j = 0;
			for (double i = 0.0; i < 1.001; i = i + interval)
			{
				Points.push_back(i);
				double k_value = f(rand() % MAXN);
				pro_value[j++] = k_value;
				Values.push_back(k_value);
				if (flag*k_value > flag*truncation)
				{
					flag = -flag;
					if (flag == -1)	endPoints.push_back(i);
					else endPoints.push_back(i - interval);
				}
			}
		} while (not_single_Peak());
		
		if (endPoints.size() == 1) endPoints.push_back(Points[Points.size() - 1]);
		
		int max_s = max(max(color.val[0], color.val[1]), color.val[2]);
		int num = Values.size();
		
		for (int i = 0; i < num; i++)
		{
			int gray[3];
			for (int j = 0; j < 3; j++)
			{
				int gray_other = (1 - Values[i]) * gary_scale;
				if (color.val[j] == max_s) gray[j] = Values[i] * color.val[j] + gray_other;
				else gray[j] = gray_other;
			}
			Colors.push_back(Scalar(gray[0], gray[1], gray[2]));
		}
	}

	void colourScheme::show_fun()
	{
		Mat show1 = Mat(300, 300, CV_8UC3, Scalar(255, 255, 255));
		int num = Values.size();
		for (int i = 20; i < 220; i = i + 20) //i�Ǻ�����, ���������
		{
			circle(show1, Point(i, 210), 3, Scalar(0, 0, 0), -1);
			line(show1, Point(i, 210), Point(i + 20, 210), Scalar(20, 20, 20));
			//circle(drawing5,a,6,Scalar(0,255,0),-1);
		}
		for (int i = 0; i < num - 1; i++)
		{
			Point first = Point(Points[i] * 200 + 20, 200 - Values[i] * 100);
			Point second = Point(Points[i + 1] * 200 + 20, 200 - Values[i + 1] * 100);
			circle(show1, first, 1, Scalar(0, 0, 255), -1);
			//line(show1, first, second, Scalar(20, 120, 20));
		}
		imshow("GaussFunction", show1);
	}

	void colourScheme::show_fun(Mat& pic, int it_num) //�������һ��ɫϵ
	{
		//Mat show1 = Mat(300, 300, CV_8UC3, Scalar(255, 255, 255));
		int num = Values.size();
		int offset = 220 * it_num;
		for (int i = 20; i < 220; i = i + 20) //i�Ǻ�����, ���������
		{
			circle(pic, Point(i + offset, 210), 2, Scalar(0, 0, 0), -1);
			line(pic, Point(i + offset, 210), Point(i + offset + 20, 210), Scalar(20, 20, 20));
			//circle(drawing5,a,6,Scalar(0,255,0),-1);
		}
		for (int i = 0; i < num - 1; i++) 
		{
			Point first = Point(Points[i] * 200 + 20 + offset, 200 - Values[i] * 100);
			Point second = Point(Points[i + 1] * 200 + 20 + offset, 200 - Values[i + 1] * 100);
			circle(pic, first, 1, Scalar(0, 0, 255), -1);
			//line(show1, first, second, Scalar(20, 120, 20));
		}
		//Point e1 = Point(endPoints[0] * 200 + 20 + offset, 200 - Values[i] * 100);
		//imshow("GaussFunction "+int2string(it_num), pic);
	}

	//--------------------------CS------------------------------------------

	//--------------------------R_Edge------------------------------------------

	R_Edge::R_Edge()
	{
		start = Point2f(0, 0);
		end = Point2f(0, 0);
	}

	R_Edge::R_Edge(Point2f start_, Point2f end_)
	{
		set_endpoints(start_, end_);
	}

	R_Edge::R_Edge(Point2f start_, Point2f end_, CS colorScheme)
	{
		set_parameters(start_, end_, colorScheme);
	}

	R_Edge::~R_Edge(){};

	void R_Edge::set_endpoints(Point2f start_, Point2f end_)
	{
		start = start_;
		end = end_;
	}

	void R_Edge::set_colorScheme(CS colorScheme)
	{
		//if (length_two_point2f(start, end) < 0.001) cout << "Wrong endpoints in R_Edge!" << endl;
		edge_colorScheme = colorScheme;
		id = colorScheme.id;
		vector<double> p = edge_colorScheme.Points;
		//vector<double> v = edge_colorScheme.Values;
		//vector<Scalar> c = edge_colorScheme.Colors;
		Point2f dist = end - start;
		interval_num = p.size();
		for (int i = 0; i < interval_num; i++)   //ÿ������100������б�ʾ
		{
			edge_points.push_back(start + p[i] * dist);
		}
		//cout << "edge_colorScheme.endPoints:  " << edge_colorScheme.endPoints.size() << endl;
		boundp1 = start + edge_colorScheme.endPoints[0] * dist;
		boundp2 = start + edge_colorScheme.endPoints[1] * dist;
		//cout << "dist: " << abs(edge_colorScheme.endPoints[0] - edge_colorScheme.endPoints[1]) << endl;
		//cout << "boundp1: " << boundp1 << "  boundp2: " << boundp2 << endl;

	}
	void R_Edge::set_parameters(Point2f start_, Point2f end_, CS colorScheme)
	{
		set_endpoints(start_, end_);
		set_colorScheme(colorScheme);
	}

	void R_Edge::change_endpoints(Point2f start_, Point2f end_)
	{
		set_endpoints(start_, end_);
		edge_points.swap(vector<Point2f>());
		vector<double> p = edge_colorScheme.Points;
		//vector<double> v = edge_colorScheme.Values;
		//vector<Scalar> c = edge_colorScheme.Colors;
		Point2f dist = end - start;
		interval_num = p.size();
		for (int i = 0; i < interval_num; i++)   //ÿ������100������б�ʾ
		{
			edge_points.push_back(start + p[i] * dist);
		}
		boundp1 = start + edge_colorScheme.endPoints[0] * dist;
		boundp2 = start + edge_colorScheme.endPoints[1] * dist;
		//cout << "boundp1: " << boundp1 << "  boundp2: " << boundp2 << endl;
	}

	void R_Edge::draw_edge(Mat& pic, Point2f shift)
	{
		//�����е����ɫ�仯
		for (int i = 0; i < edge_points.size() - 1; i++)
		{
			int thickness = 5;
			int lineType = 8;
			Scalar color = edge_colorScheme.Colors[i];
			//line(pic, edge_points[i] + shift, edge_points[i + 1] + shift, color, thickness, lineType);
			circle(pic, edge_points[i] + shift, 3, color, -1);
		}
		
		//10-25 ֻ��Ƭ��
		int thickness = 5;
		int lineType = 8;
		line(pic, boundp1 + shift, boundp2 + shift, edge_colorScheme.Colors[50], thickness, lineType);


		//cout << boundp1 << "   " << boundp2 << endl;
		//circle(pic, boundp1+shift, 3, Scalar(0, 0, 0), -1);
		//circle(pic, boundp2+shift, 3, Scalar(0, 0,0), -1);
	}


	double R_Edge::compare_edge(R_Edge opposite) //�������ߵĲ�ֵ������Ҫע��λ�û�Ҫע����ɫ
	{
		//ֻ��Ҫ�Ƚ�����edge_colorScheme��洢�ĻҶ�ֵ
		int sizecs = edge_colorScheme.Colors.size();
		if (sizecs != opposite.edge_colorScheme.Colors.size()) cout << "Different size!" << endl;
		double all_dif = 0;
		//ͬ��Ϊ���ߣ��Ͳ���Ҫ����
		for (int i = 0; i < sizecs; i++)
		{
			all_dif += diff_color(edge_colorScheme.Colors[i], opposite.edge_colorScheme.Colors[i]);
		}
		return all_dif;
	}

	double R_Edge::compare_edge_with(R_Edge opposite)
	{
		//ֻ��Ҫ�Ƚ�����edge_colorScheme��洢�ĻҶ�ֵ
		int sizecs = edge_colorScheme.Colors.size();
		if (sizecs != opposite.edge_colorScheme.Colors.size()) cout << "Different size!" << endl;
		double all_dif = 0;
		double color_diff = 0;
		double position_diff = 0;
		double deriv_curva_diff = 0;
		//ͬ��Ϊ���ߣ��Ͳ���Ҫ����
		/*for (int i = 0; i < sizecs; i++)
		{
			color_diff += diff_color(edge_colorScheme.Colors[i], opposite.edge_colorScheme.Colors[i]);
		}*/
		//deriv_curva_diff = diff_deriv_curva(deriv_curva1, opposite.deriv_curva1) + diff_deriv_curva(deriv_curva2, opposite.deriv_curva2);
		position_diff = (abs(length_two_point2f(boundp1, start) - length_two_point2f(opposite.boundp1, opposite.start)) + abs(length_two_point2f(boundp2, start) - length_two_point2f(opposite.boundp2, opposite.start))) / length_two_point2f(start, end);
		//position_diff = position_diff*position_diff;
		//cout << "deriv_curva_diff: "<<deriv_curva_diff << "   " << position_diff << endl;
		all_dif = position_diff;// +1.5*deriv_curva_diff; // color_diff + 
		//all_dif = color_diff;
		return all_dif;
	}

	//�ѵ��������ʵ�����������û�е�����Ҫ�ں�������
	void R_Edge::input_curva(Point2f boundp, vector<double> deriv_curvas, bool isFirst)
	{
		int size_dc = deriv_curvas.size();
		
		if (size_dc == 2) //��Ӧ������һ����������Ҫ��������(����0��������)
		{
			double k;
			if (boundp1.x == boundp2.x) k = 0;
			else k = 10000;
			if (length_two_point2f(boundp, boundp1) < 0.01) deriv_curva1 = { k, 0 };
			else deriv_curva2 = { k, 0 };
		}
		else //��Ӧ��ͨ���
		{
			if (length_two_point2f(boundp, boundp1) < 0.01)
			{
				if (isFirst) deriv_curva1 = { deriv_curvas[0], deriv_curvas[1] };  
				else deriv_curva1 = { deriv_curvas[2], deriv_curvas[3] };
			}
			else 
			{
				if (isFirst) deriv_curva2 = { deriv_curvas[0], deriv_curvas[1] };
				else deriv_curva2 = { deriv_curvas[2], deriv_curvas[3] };
			}
		}
	}

	//--------------------------R_Edge------------------------------------------

	//--------------------------Tile------------------------------------------
	Tile::Tile()
	{
		topLeft = bottomRight = center = Point2f(0, 0);
		width = height = 0.0;
	}

	Tile::Tile(Point2f topLeft_, Point2f bottomRight_)
	{
		topLeft = topLeft_;
		bottomRight = bottomRight_;
		width = abs(bottomRight.x - topLeft.x);
		height = abs(bottomRight.y - topLeft.y);
		center = 0.5*(topLeft + bottomRight);
		set_edges();
		content_type = -1;
	}

	Tile::Tile(Point2f topLeft_, double width_, double height_)
	{
		topLeft = topLeft_;	
		width = width_;
		height = height_;
		bottomRight = topLeft_ + Point2f(width, -height);
		center = 0.5*(topLeft + bottomRight);
		set_edges();
		content_type = -1;
	}

	Tile::~Tile(){}

	/*void Tile::operator= (Tile& tile)
	{
		topLeft = tile.topLeft;
		bottomRight = tile.bottomRight;
		center = tile.center;
		width = tile.width;
		height = tile.height;
		Left = tile.Left;
		Bottom = tile.Bottom;
		Right = tile.Right;
		Top = tile.Top;
		content_patterns = tile.content_patterns;
	}*/

	void Tile::set_edges() //��ʼ���ñ߽�����
	{
		if (length_two_point2f(topLeft, bottomRight) < 0.1) cout << "Wrong Points in Tile!" << endl;
		//ע�����ﲻ��ʹ��˳ʱ�������ʱ�룬��Ҫ���ֶԱߵķ���һ��
		/*Left.set_endpoints(topLeft, topLeft - Point2f(0, height));
		Bottom.set_endpoints(topLeft - Point2f(0, height), bottomRight);
		Right.set_endpoints(bottomRight, bottomRight + Point2f(0, height));
		Top.set_endpoints(topLeft + Point2f(width, 0),topLeft);*/

		// ���ߴ��ϵ��£���ߴ�����
		Left.set_endpoints(topLeft, topLeft - Point2f(0, height));
		Bottom.set_endpoints(topLeft - Point2f(0, height), bottomRight);
		Right.set_endpoints(bottomRight + Point2f(0, height), bottomRight);
		Top.set_endpoints(topLeft, topLeft + Point2f(width, 0));
	}

	void Tile::set_colors(CS l, CS b, CS r, CS t)
	{
		Left.set_colorScheme(l);
		Bottom.set_colorScheme(b);
		Right.set_colorScheme(r);
		Top.set_colorScheme(t);
	}

	void Tile::change_position(Point2f new_topLeft)//�ƶ�λ�ã��ı�����
	{
		Point2f shift = new_topLeft - topLeft;
		topLeft = new_topLeft;
		bottomRight = topLeft + Point2f(width, -height);
		center = 0.5*(topLeft + bottomRight);
		Left.change_endpoints(topLeft, topLeft - Point2f(0, height));
		Bottom.change_endpoints(topLeft - Point2f(0, height), bottomRight);
		Right.change_endpoints(bottomRight + Point2f(0, height), bottomRight);
		Top.change_endpoints(topLeft, topLeft + Point2f(width, 0));
		for (int i = 0; i < content_patterns.size(); i++)
		{
			for (int j = 0; j < content_patterns[i].size(); j++)
			{
				content_patterns[i][j] += shift;
			}
		}
		/*Left.change_endpoints(topLeft, topLeft - Point2f(0, height));
		Bottom.change_endpoints(topLeft - Point2f(0, height), bottomRight);
		Right.change_endpoints(bottomRight, bottomRight + Point2f(0, height));
		Top.change_endpoints(topLeft + Point2f(width, 0), topLeft);*/
	}

	void Tile::draw_tileEdges(Mat& pic, Point2f shift)
	{
		Left.draw_edge(pic, shift);
		Bottom.draw_edge(pic, shift);
		Right.draw_edge(pic, shift);
		Top.draw_edge(pic, shift);
	}


	void Tile::draw_tileConts(Mat& pic, Point2f shift, double zoom_scale)
	{
		int content_num = content_patterns.size();
		//cout << "content_num: " << content_num << endl;
		if (content_num < 1) cout << "No content pattern!" << endl;
		else
		{
			for (int i = 0; i < content_num; i++)
			{
				draw_poly(pic, content_patterns[i], shift, Scalar(0, 0, 0), zoom_scale);
				//draw_poly_contour(pic, content_patterns[i], shift);
				save_tile_svg(patch_svg_name, content_patterns[i], Scalar(0, 0, 0), shift, zoom_scale);
			}
		}
	}

	void Tile::draw_tileConts(Mat& pic, Point2f shift, int color_cho, double zoom_scale)
	{
		if (color_cho == -1) color_cho = color_map.size() - 1;
		int content_num = content_patterns.size();
		//cout << "content_num: " << content_num << endl;
		if (content_num < 1) cout << "No content pattern!" << endl;
		else
		{
			for (int i = 0; i < content_num; i++)
			{
				draw_poly(pic, content_patterns[i], shift, color_map[color_cho], zoom_scale);
				//draw_poly_contour(pic, content_patterns[i], shift);
				//save_tile_svg(patch_svg_name, content_patterns[i], Scalar(0, 0, 0), shift, zoom_scale);
			}
		}
	}

	void Tile::draw_Tile(Mat& pic, Point2f shift)
	{
		draw_tileEdges(pic, shift);
		draw_tileConts(pic, shift);
	}

	void Tile::draw_slot(Mat& pic, Point2f shift, string edge_type, double zoom_scale, int length_scale, int types)
	{
		if (length_scale == 0) types = 2; //ֻ����ϸ�߱��hook����
		Point2f start, end;
		string edge_name;
		//edge_type: 0-left, 1-right, 2-top, 3-bottom
		if (edge_type == "left")
		{
			start = Left.boundp2;
			end = Left.boundp1;
		}
		else if (edge_type == "right")
		{
			start = Right.boundp1;
			end = Right.boundp2;
		}
		else if (edge_type == "top")
		{
			start = Top.boundp1;
			end = Top.boundp2;
		}
		else if (edge_type == "bottom")
		{
			start = Bottom.boundp2;
			end = Bottom.boundp1;
		}
		vector<double> length_multi = { 2, 6, 9 };//{ 1.5, 4.5, 9 };
		vector<Point2f> tile_slot;
		double length = length_two_point2f(start, end);
		if (length_scale == 2) length = 0.8*length; //������ߣ������ʵ�Сһ��
		Point2f mid = 0.5 * (start + end);
		Point2f vec = unit_vec(end - start);
		Point2f ver_vec = vertical_vec(vec);
		//cout << vec << " " << ver_vec << endl;
		vector<Point2f> bulge;
		vector<Point2f> sinus;
		if (types == 0) //rectangle
		{
			double height_bulge = 0.25*length;
			Point2f bulge1 = mid - length*vec;
			Point2f mid1 = mid - 0.5*vec;
			bulge.push_back(bulge1);
			bulge.push_back(mid1);
			bulge.push_back(mid1 + height_bulge*ver_vec);
			bulge.push_back(bulge1 + height_bulge*ver_vec);
			//cout << bulge[0] << "  " << bulge[1] << "  " << bulge[2] << "  " << bulge[3] << endl;
			Point2f sinus1 = mid + length*vec;
			Point2f mid2 = mid + 0.5*vec;
			sinus.push_back(mid2);
			sinus.push_back(mid2 - height_bulge*ver_vec); 
			sinus.push_back(sinus1 - height_bulge*ver_vec);
			sinus.push_back(sinus1);
			//cout << sinus[0] << "  " << sinus[1] << "  " << sinus[2] << "  " << sinus[3] << endl;
		}
		else if (types == 1) //spoon
		{
			Point2f margin_s = 0.006*length*vec;
			//cout << "start end points:"<<start << "  " << end << "  " << mid << " " << start + (half_edge + 0.5*length)*vec - 1.2*length*ver_vec << endl;
			vector<Point2f> contour = readTxt("D:\\VisualStudioProjects\\freeBoundary\\freeBoundary\\spoon.txt");
			vector<Point2f> bbxp = b_box(contour);//���صĵ��Ǵ����Ϸ���ʱ��
			vector<Point2f> c1;
			c1.push_back(0.5*(bbxp[1] + bbxp[2]));
			c1.push_back(bbxp[0]);
			c1.push_back(bbxp[3]);
			//cout <<"boundingbox:"<< bbxp[0] << "  " << bbxp[1] << "  " << bbxp[2] << " " << bbxp[3]<<endl;
			
			double height_bulge = 0.36*length;
			vector<Point2f> bulge_c;
			Point2f mid1 = mid - margin_s;
			bulge_c.push_back(mid1 - 0.15*length*vec + height_bulge*ver_vec);
			bulge_c.push_back(mid1 - 0.3*length*vec);
			bulge_c.push_back(mid1);
			//cout << bulge_c[0] << "  " << bulge_c[1] << "  " << bulge_c[2] << endl;
			vector<Point2f> sinus_c;
			
			Point2f mid2 = mid + margin_s;
			sinus_c.push_back(mid2 + 0.15*length*vec - height_bulge*ver_vec);
			sinus_c.push_back(mid2 + 0.3*length*vec + margin_s);
			//Point2f mid2 = start + (half_edge + 0.5)*vec;
			sinus_c.push_back(mid2 - margin_s);
			//cout << c1[0] << "   " << bulge_c[0] << "  " << sinus_c[0] << endl;
			//c2.push_back(Point2f(500, 800));
			Mat M_seg1 = getAffineTransform(c1, bulge_c);
			Mat M_seg2 = getAffineTransform(c1, sinus_c);
			//cout << "M_seg1: " << M_seg1 << endl;
			c1.push_back(Point2f(300, 400));
			cv::transform(contour, bulge, M_seg1);
			cv::transform(contour, sinus, M_seg2);
			//cout << "Over!" << endl;
		}
		else if (types == 2) //hook
		{
			double scale_ratio = 0.99;
			double l_ratio = 0.3; //0.375
			double height_bulge = l_ratio*length;
			double width_bulge = l_ratio*length;
			Point2f bulge1 = start + width_bulge*vec;
			//Point2f mid1 = start + (half_edge - 0.5)*vec;
			Point2f sinus1 = start + scale_ratio*(length - width_bulge)*vec;
			Point2f shiftt = 0.01*length*vec;
			//Point2f mid2 = start + (half_edge + 0.5)*vec;
			bulge.push_back(start);
			bulge.push_back(sinus1);
			bulge.push_back(sinus1 + scale_ratio*height_bulge*ver_vec);
			bulge.push_back(start + scale_ratio*height_bulge*ver_vec - shiftt);

			sinus.push_back(bulge1);
			sinus.push_back(bulge1 - height_bulge*ver_vec);
			sinus.push_back(end - height_bulge*ver_vec + vec);
			sinus.push_back(end + 4*shiftt);
		}
		else if (types == 3) //semicir_hook
		{
			double scale_ratio = 0.96;
			double height_bulge = 0.4*length;
			double width_bulge = 0.5*length;
			double shift_bulge = 0.1*length;
			Point2f bulge1 = start + width_bulge*vec;
			//Point2f mid1 = start + (half_edge - 0.5)*vec;
			Point2f sinus1 = start + scale_ratio*width_bulge*vec;
			Point2f shiftt = 0.01*length*vec;

			vector<Point2f> s_circle = semicir_gen(sinus1, sinus1 + height_bulge*ver_vec, sinus1 + 0.5*height_bulge*ver_vec);
			vector<Point2f> sc_M = { s_circle[0], s_circle[s_circle.size() - 1], s_circle[(s_circle.size() - 1) / 2] };

			vector<Point2f> b_M = { sinus1, sinus1 + scale_ratio*height_bulge*ver_vec, sinus1 + 0.5*scale_ratio*height_bulge*ver_vec + scale_ratio*shift_bulge*vec };
			vector<Point2f> s_M = { bulge1, bulge1 - height_bulge*ver_vec, bulge1 - 0.5*height_bulge*ver_vec - shift_bulge*vec };
			
			Mat M_seg1 = getAffineTransform(sc_M, b_M);
			Mat M_seg2 = getAffineTransform(sc_M, s_M);
			cv::transform(s_circle, b_M, M_seg1);
			cv::transform(s_circle, s_M, M_seg2);

			bulge.push_back(start);
			append(bulge, b_M);
			//bulge.push_back(sinus1);
			//bulge.push_back(sinus1 + 0.95*height_bulge*ver_vec);
			//append(bulge, semicir_gen(sinus1, sinus1 + scale_ratio*height_bulge*ver_vec, sinus1 + 0.5*scale_ratio*height_bulge*ver_vec));
			bulge.push_back(start + scale_ratio*height_bulge*ver_vec - shiftt);

			//sinus.push_back(bulge1);
			//sinus.push_back(bulge1 - height_bulge*ver_vec);
			//append(sinus, semicir_gen(bulge1, bulge1 - height_bulge*ver_vec, bulge1 - 0.5*height_bulge*ver_vec));
			append(sinus, s_M);
			sinus.push_back(end - height_bulge*ver_vec + vec);
			sinus.push_back(end + 4 * shiftt);
		}
		else //semicircle
		{
			int arc_line_num = 20;
			Point2f midmid = mid - 0.5*length*vec;
			Point2f Vs_c = mid - midmid;
			for (int i = 0; i <= arc_line_num; i++)
			{
				double new_angle = i * PI / arc_line_num; //ÿ�������ĽǶȼ��
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = Vs_c.x * cos(new_angle) - Vs_c.y * sin(new_angle);
				double new_y = Vs_c.x * sin(new_angle) + Vs_c.y * cos(new_angle);
				Point2f new_point = Point2f(new_x, new_y) + midmid;
				bulge.push_back(new_point);
			}
			midmid = mid + 0.5*length*vec;
			Vs_c = mid - midmid;
			for (int i = 0; i <= arc_line_num; i++)
			{
				double new_angle = i * PI / arc_line_num; //ÿ�������ĽǶȼ��
				//Rotation matrix: M(a)={(cosa, -sina)(sina cosa)}
				double new_x = Vs_c.x * cos(new_angle) - Vs_c.y * sin(new_angle);
				double new_y = Vs_c.x * sin(new_angle) + Vs_c.y * cos(new_angle);
				Point2f new_point = Point2f(new_x, new_y) + midmid;
				sinus.push_back(new_point);
			}
		}
		//draw_poly(pic, bulge, shift, Scalar(0, 255, 0), zoom_scale);
		//draw_poly(pic, sinus, shift, Scalar(255, 0, 0), zoom_scale);
		draw_poly(pic, bulge, shift, Scalar(0, 0, 0), zoom_scale);
		draw_poly(pic, sinus, shift, Scalar(255, 255, 255), zoom_scale);

		save_tile_svg(patch_svg_name, bulge, Scalar(0, 0, 0), shift, zoom_scale);
		save_tile_svg(patch_svg_name, sinus, Scalar(255, 255, 255), shift, zoom_scale);
		Point2f shift_obj = 1.0 / zoom_scale* shift;
		write_obj(obj_path + edge_type + "_b.obj", bulge, shift_obj, 4);
		write_obj(obj_path + edge_type + "_s.obj", sinus, shift_obj, 4);

	}

	void Tile::show_Edge_curva()
	{
		cout << "Left: boundp1: " << Left.deriv_curva1[0] << " " << Left.deriv_curva1[1]
			<< "  boundp2: " << Left.deriv_curva2[0] << " " << Left.deriv_curva2[1] << endl
			<< "Bottom: boundp1: " << Bottom.deriv_curva1[0] << " " << Bottom.deriv_curva1[1]
			<< "  boundp2: " << Bottom.deriv_curva2[0] << " " << Bottom.deriv_curva2[1] << endl
			<< "Right: boundp1: " << Right.deriv_curva1[0] << " " << Right.deriv_curva1[1]
			<< "  boundp2: " << Right.deriv_curva2[0] << " " << Right.deriv_curva2[1] << endl
			<< "Top: boundp1: " << Top.deriv_curva1[0] << " " << Top.deriv_curva1[1]
			<< "  boundp2: " << Top.deriv_curva2[0] << " " << Top.deriv_curva2[1] << endl;
	}

	/*double Tile::diff_2edges(R_Edge me, R_Edge matched)
	{
		return compare_edge(me.edge_colorScheme.Colors);
	}*/

	vector<Tile> Tile::match_tile(vector<Tile>& allTiles, int flag) //��Ϊ��һ��tile��������һ��Ҫƴ�ӵ�tile
	{
		vector<Tile> candidate;
		int sizeall = allTiles.size();
		if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ < 0.01) candidate.push_back(allTiles[i]); 
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge(allTiles[i].Top);
				if (error_ <0.01) candidate.push_back(allTiles[i]);
			}
		}
		cout << "candidate number:  " << candidate.size() << endl;
		return candidate;
	}

	vector<int> Tile::match_tile(vector<Tile>& allTiles, double threshold, int flag)
	{
		vector<int> chosen;
		int sizeall = allTiles.size();
		if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ < threshold) chosen.push_back(i);
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge(allTiles[i].Top);
				if (error_ < threshold) chosen.push_back(i);
			}
		}
		cout << "chosen num:  " << chosen.size() << endl;
		return chosen;
	}

	Tile Tile::match_tile(vector<Tile>& allTiles, int & index, int flag) //flagָʾ��ǰtileƴ�ӵıߺ�Ҫƥ��ı�
	{
		double threshold = 0.01;
		vector<int> chosen;
		vector <double> chosen_v;
		double min_error = 100000;
		int min_index = -1;
		int sizeall = allTiles.size();
		//cout << "all_Tile:" << allTiles.size() << endl;
		if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ <= min_error)
				{
					min_error = error_;
					min_index = i;
					if (error_ < threshold)//0.01
					{
						chosen.push_back(min_index);
						chosen_v.push_back(min_error);
					}
				}
				//if (min_error < 5000) break;
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge(allTiles[i].Top);
				if (error_ <= min_error)
				{
					min_error = error_;
					min_index = i;
					if (error_ <threshold)
					{
						chosen.push_back(min_index);
						chosen_v.push_back(min_error);
					}
				}
			}
		}
		/*for (int g = 0; g < chosen.size(); g++)
		{
		cout << chosen[g] << "   " << chosen_v[g] << endl;
		}*/
		int itt = rand();
		int iii = itt%chosen.size();
		cout << "chosen:  " << chosen.size() << "  itt: " << itt << "  iii: " << iii << endl;
		cout << "min_error: " << min_error << "  min_index:  " << min_index << endl;
		//return allTiles[min_index];
		index = chosen[iii];
		cout << "index: " << index << endl;
		return allTiles[chosen[iii]];
	}


	Tile Tile::match_tile_with_constrain(vector<Tile>& allTiles, int & index, int flag)
	{
		vector<int> chosen;
		double min_error = 100000;
		//int min_index = -1;
		int sizeall = allTiles.size();
		cout << "all_Tile:" << allTiles.size() << endl;
		if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge_with(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<int>());
						min_error = error_;
						//min_index = i;
						chosen.push_back(i);
					}
					else
					{
						chosen.push_back(i);
					}
				}
				//if (min_error < 5000) break;
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge_with(allTiles[i].Top);
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<int>());
						min_error = error_;
						//min_index = i;
						chosen.push_back(i);
					}
					else
					{
						chosen.push_back(i);
					}				
				}
			}
		}

		int itt = rand() % chosen.size();
		index = chosen[itt];
		cout << "-----------------------------------------------------------------" << endl<<endl;
		cout << "min_error:" << min_error << "   chosen:" << chosen.size() << "   random:"<< itt << "   index:" << index << endl << endl;
		cout << "-----------------------------------------------------------------" << endl << endl;
		
		/*Mat showt = Mat(300, 1200, CV_8UC3, Scalar(255, 255, 255));
		for (int t = 0; t < 8; t++)
		{
			Tile show_tile2 = allTiles[chosen[t]];
			show_tile2.change_position(Point2f(t * 110 + 130, 120));
			show_tile2.draw_Tile(showt);
		}
		imshow("candidate: ", showt);*/
		//return allTiles[min_index];
		//index = chosen[min_index];
		//cout << "index: " << index << endl;
		return allTiles[index];
	}

	vector<int> Tile::match_tile_with_constrain(vector<Tile>& allTiles, double threshold, int flag)
	{
		vector<int> chosen;
		int sizeall = allTiles.size();
		if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge_with(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ < threshold) chosen.push_back(i);
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge_with(allTiles[i].Top);
				if (error_ < threshold) chosen.push_back(i);
			}
		}
		cout << "-----------------------------------------------------------------" << endl << endl;
		cout << "chosen num:  " << chosen.size() << endl;
		cout << "-----------------------------------------------------------------" << endl << endl;
		return chosen;
	}


	bool Tile::equal_tile(Tile &sec, int type) //�Ƚ�����tile�ı߽��Ƿ�һ��, type�����Ƚ���һ��,0,1,2,3�ֱ�Ϊ�������ϣ�4Ϊȫ��
	{
		double offset = 0.001;
		switch (type)
		{
		case 0:
		{
			if (Left.compare_edge(sec.Left) < offset) return true;
			break;
		}
		case 1:
		{
			if (Bottom.compare_edge(sec.Bottom) < offset) return true;
			break;
		}
		case 2:
		{
			if (Right.compare_edge(sec.Right) < offset) return true;
			break;
		}
		case 3:
		{
			if (Top.compare_edge(sec.Top) < offset) return true;
			break;
		}
		case 4:
		{
			if (Left.compare_edge(sec.Left) < offset && Bottom.compare_edge(sec.Bottom) < offset)
				if (Right.compare_edge(sec.Right) < offset && Top.compare_edge(sec.Top) < offset)
					return true;
		}
		}
		return false;
	}

	void Tile::content_gen_rules(int flag)
	{
		int isB_spline = 0; //ѡ�����ߵ�����,0-b_spline, 1-circle, 2-hermite 
		content_patterns.swap(vector<vector<Point2f>>());
		all_C.clear();
		content_type = flag;
		vector<double> deriv_curvas;
		bool isFirst = true;
		vector<Point2f> (*arc_fun)(Point2f, Point2f, Point2f, Point2f, vector<double>&);//��������
		if (isB_spline == 0)
		{
			arc_fun = &arc_gen_b;
		}
		else if (isB_spline==1)
		{
			arc_fun = &arc_gen;
		}
		else arc_fun = &arc_gen_h;

		switch (flag)
		{
		case sequenceConnect: //0
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_br = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> arc_rt = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_br);
			append(arc_lb, arc_rt);
			append(arc_lb, arc_tl);
			content_patterns.push_back(arc_lb);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case  ltrbConnect:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			/*cout << arc_br2.size() << endl;
			
			cout << endl;
			cout << "rb1: " << Right.boundp1 << "  bb1:  " << Bottom.boundp1 << "  bb2: " << Bottom.boundp2 << "  rb2: " << Right.boundp2 << endl;
			for (int dd = 0; dd < arc_br.size(); dd++)
			{
				cout << arc_br[dd] << "  ";
			}*/
			content_patterns.push_back(arc_br);
			
			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case tlrbMidS: //5
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> Sline_lr = { Left.boundp1, Left.boundp2, Right.boundp2, Right.boundp1 };
			Left.deriv_curva2 = { (Right.boundp2.y - Left.boundp2.y) / (Right.boundp2.x - Left.boundp2.x), 0 };
			Right.deriv_curva1 = { (Right.boundp1.y - Left.boundp1.y) / (Right.boundp1.x - Left.boundp1.x), 0 };
			content_patterns.push_back(Sline_lr);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);
			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case trlbMidS:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> Sline_lr = { Left.boundp1, Left.boundp2, Right.boundp2, Right.boundp1 };
			Right.deriv_curva2 = { (Right.boundp2.y - Left.boundp2.y) / (Right.boundp2.x - Left.boundp2.x), 0 };
			Left.deriv_curva1 = { (Right.boundp1.y - Left.boundp1.y) / (Right.boundp1.x - Left.boundp1.x), 0 };
			content_patterns.push_back(Sline_lr);

			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case rbltConnect:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case trblConnect:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case bltrConnect: //4
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case ltbrMidS:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> Sline_tb = { Bottom.boundp1, Bottom.boundp2, Top.boundp2, Top.boundp1 };
			if (abs(Bottom.boundp1.x - Top.boundp1.x) < 0.01) Bottom.deriv_curva1 = { 10000, 0 };
			else Bottom.deriv_curva1 = { (Top.boundp1.y - Bottom.boundp1.y) / (Top.boundp1.x - Bottom.boundp1.x), 0 };
			if (abs(Bottom.boundp2.x - Top.boundp2.x) < 0.01) Top.deriv_curva2 = { 10000, 0 };
			else Top.deriv_curva2 = { (Top.boundp2.y - Bottom.boundp2.y) / (Top.boundp2.x - Bottom.boundp2.x), 0 };
			content_patterns.push_back(Sline_tb);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);
			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case lbtrMidS: //8
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> Sline_tb = { Bottom.boundp1, Bottom.boundp2, Top.boundp2, Top.boundp1 };
			if (abs(Bottom.boundp1.x - Top.boundp1.x) < 0.01) Top.deriv_curva1 = { 10000, 0 };
			else Top.deriv_curva1 = { (Top.boundp1.y - Bottom.boundp1.y) / (Top.boundp1.x - Bottom.boundp1.x), 0 };
			if (abs(Bottom.boundp2.x - Top.boundp2.x) < 0.01) Bottom.deriv_curva2 = { 10000, 0 };
			else Bottom.deriv_curva2 = { (Top.boundp2.y - Bottom.boundp2.y) / (Top.boundp2.x - Bottom.boundp2.x), 0 };
			content_patterns.push_back(Sline_tb);

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			//3 in 1
			/*vector<Point2f> contour3 = mix_contour(content_patterns);
			content_patterns.swap(vector<vector<Point2f>>());
			content_patterns.push_back(contour3);*/

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
        case allSelf:
		{
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> left_c = arc_fun(Left.boundp2, Left.boundp1, 0.5*(Left.boundp1 + Left.boundp2), center, deriv_curvas);
			content_patterns.push_back(left_c);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> bottom_c = arc_fun(Bottom.boundp2, Bottom.boundp1, 0.5*(Bottom.boundp1 + Bottom.boundp2), center, deriv_curvas);
			content_patterns.push_back(bottom_c);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> right_c = arc_fun(Right.boundp1, Right.boundp2, 0.5*(Right.boundp1 + Right.boundp2), center, deriv_curvas);
			content_patterns.push_back(right_c);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> top_c = arc_fun(Top.boundp1, Top.boundp2, 0.5*(Top.boundp1 + Top.boundp2), center, deriv_curvas);
			content_patterns.push_back(top_c);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			break;
		}
		case lefttopSelf:
		{
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> left_c = arc_fun(Left.boundp2, Left.boundp1, 0.5*(Left.boundp1 + Left.boundp2), center, deriv_curvas);
			content_patterns.push_back(left_c);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			//append(bottom_c, b_spline_gen(end_, start_);
			content_patterns.push_back(arc_br);

			vector<Point2f> top_c = arc_fun(Top.boundp1, Top.boundp2, 0.5*(Top.boundp1 + Top.boundp2), center, deriv_curvas);
			content_patterns.push_back(top_c);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			//Mat showtt = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
			break;
		}
		case leftbottomSelf:
		{
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> left_c = arc_fun(Left.boundp2, Left.boundp1, 0.5*(Left.boundp1 + Left.boundp2), center, deriv_curvas);
			content_patterns.push_back(left_c);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> bottom_c = arc_fun(Bottom.boundp2, Bottom.boundp1, 0.5*(Bottom.boundp1 + Bottom.boundp2), center, deriv_curvas);
			content_patterns.push_back(bottom_c);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			//append(bottom_c, b_spline_gen(end_, start_);
			content_patterns.push_back(arc_rt);
			break;
		}
		case righttopSelf:
		{
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> right_c = arc_fun(Right.boundp1, Right.boundp2, 0.5*(Right.boundp1 + Right.boundp2), center, deriv_curvas);
			content_patterns.push_back(right_c);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> top_c = arc_fun(Top.boundp1, Top.boundp2, 0.5*(Top.boundp1 + Top.boundp2), center, deriv_curvas);
			content_patterns.push_back(top_c);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			break;
		}
		case rightbottomSelf:  //4
		{
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> bottom_c = arc_fun(Bottom.boundp2, Bottom.boundp1, 0.5*(Bottom.boundp1 + Bottom.boundp2), center, deriv_curvas);
			content_patterns.push_back(bottom_c);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> right_c = arc_fun(Right.boundp1, Right.boundp2, 0.5*(Right.boundp1 + Right.boundp2), center, deriv_curvas);
			content_patterns.push_back(right_c);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			break;
		}
		case lefttopConnect: //5
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);			
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			//append(bottom_c, b_spline_gen(end_, start_);
			content_patterns.push_back(arc_br);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			bd1.C[1] = P1;
			bd1.C[2] = P1;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			P.clear();
			bd2.C[0] = P1;
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd2.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd2.C[2] = P;
			bd2.C[3] = P1;
			all_C.push_back(bd2);
			break;
		}
		case leftbottomConnect: //6
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}
			
			vector<double> deriv_curvas;
			bool isFirst = true;
			vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);

			vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
			Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);

			vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
			Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			//append(bottom_c, b_spline_gen(end_, start_);
			content_patterns.push_back(arc_rt);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			bd1.C[1] = P1;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			bd1.C[3] = P1;
			all_C.push_back(bd1);

			P.clear();
			bd2.C[0] = P1;
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd2.C[1] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd2.C[2] = P1;
			bd2.C[3] = P;
			all_C.push_back(bd2);
			break;
		}
		case sequenceConnect_v:  //16
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> Sline_lr = { Left.boundp1, Left.boundp2, Right.boundp2, Right.boundp1 };
			Left.deriv_curva2 = { (Right.boundp2.y - Left.boundp2.y) / (Right.boundp2.x - Left.boundp2.x), 0 };
			Right.deriv_curva1 = { (Right.boundp1.y - Left.boundp1.y) / (Right.boundp1.x - Left.boundp1.x), 0 };
			content_patterns.push_back(Sline_lr);

			vector<Point2f> Sline_tb = { Bottom.boundp1, Bottom.boundp2, Top.boundp2, Top.boundp1 };
			if (abs(Bottom.boundp1.x - Top.boundp1.x) < 0.01) Bottom.deriv_curva1 = { 10000, 0 };
			else Bottom.deriv_curva1 = { (Top.boundp1.y - Bottom.boundp1.y) / (Top.boundp1.x - Bottom.boundp1.x), 0 };
			if (abs(Bottom.boundp2.x - Top.boundp2.x) < 0.01) Top.deriv_curva2 = { 10000, 0 };
			else Top.deriv_curva2 = { (Top.boundp2.y - Bottom.boundp2.y) / (Top.boundp2.x - Bottom.boundp2.x), 0 };
			content_patterns.push_back(Sline_tb);


			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case  ltrbConnect_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = { Top.boundp1, Left.boundp1 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = { Left.boundp2, Top.boundp2 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> arc_rt = { Top.boundp1, Right.boundp2 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = { Right.boundp1, Top.boundp2 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> arc_br = { Right.boundp1, Bottom.boundp1 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = { Bottom.boundp2, Right.boundp2 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case rbltConnect_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_br = { Right.boundp1, Bottom.boundp1 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = { Bottom.boundp2, Right.boundp2 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			vector<Point2f> arc_lb = { Left.boundp2, Bottom.boundp1 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = { Bottom.boundp2, Left.boundp1 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> arc_tl = { Top.boundp1, Left.boundp1 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = { Left.boundp2, Top.boundp2 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case trblConnect_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_rt = { Top.boundp1, Right.boundp2 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = { Right.boundp1, Top.boundp2 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> arc_br = { Right.boundp1, Bottom.boundp1 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = { Bottom.boundp2, Right.boundp2 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			vector<Point2f> arc_lb = { Left.boundp2, Bottom.boundp1 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = { Bottom.boundp2, Left.boundp1 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);


			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case bltrConnect_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_lb = { Left.boundp2, Bottom.boundp1 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = { Bottom.boundp2, Left.boundp1 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> arc_tl = { Top.boundp1, Left.boundp1 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> arc_rt = { Top.boundp1, Right.boundp2 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = { Right.boundp1, Top.boundp2 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case tlrbMidS_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = { Top.boundp1, Left.boundp1 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> Sline_lr = { Left.boundp1, Left.boundp2, Right.boundp2, Right.boundp1 };
			Left.deriv_curva2 = { (Right.boundp2.y - Left.boundp2.y) / (Right.boundp2.x - Left.boundp2.x), 0 };
			Right.deriv_curva1 = { (Right.boundp1.y - Left.boundp1.y) / (Right.boundp1.x - Left.boundp1.x), 0 };
			content_patterns.push_back(Sline_lr);

			vector<Point2f> arc_br = { Right.boundp1, Bottom.boundp1 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = { Bottom.boundp2, Right.boundp2 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case ltbrMidS_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_tl = { Top.boundp1, Left.boundp1 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_tl, arc_tl2);
			content_patterns.push_back(arc_tl);

			vector<Point2f> Sline_tb = { Bottom.boundp1, Bottom.boundp2, Top.boundp2, Top.boundp1 };
			if (abs(Bottom.boundp1.x - Top.boundp1.x) < 0.01) Bottom.deriv_curva1 = { 10000, 0 };
			else Bottom.deriv_curva1 = { (Top.boundp1.y - Bottom.boundp1.y) / (Top.boundp1.x - Bottom.boundp1.x), 0 };
			if (abs(Bottom.boundp2.x - Top.boundp2.x) < 0.01) Top.deriv_curva2 = { 10000, 0 };
			else Top.deriv_curva2 = { (Top.boundp2.y - Bottom.boundp2.y) / (Top.boundp2.x - Bottom.boundp2.x), 0 };
			content_patterns.push_back(Sline_tb);

			vector<Point2f> arc_br = { Right.boundp1, Bottom.boundp1 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_br2 = { Bottom.boundp2, Right.boundp2 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			append(arc_br, arc_br2);
			content_patterns.push_back(arc_br);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case trlbMidS_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_rt = { Top.boundp1, Right.boundp2 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = { Right.boundp1, Top.boundp2 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			vector<Point2f> Sline_lr = { Left.boundp1, Left.boundp2, Right.boundp2, Right.boundp1 };
			Right.deriv_curva2 = { (Right.boundp2.y - Left.boundp2.y) / (Right.boundp2.x - Left.boundp2.x), 0 };
			Left.deriv_curva1 = { (Right.boundp1.y - Left.boundp1.y) / (Right.boundp1.x - Left.boundp1.x), 0 };
			content_patterns.push_back(Sline_lr);

			vector<Point2f> arc_lb = { Left.boundp2, Bottom.boundp1 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = { Bottom.boundp2, Left.boundp1 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		case lbtrMidS_v:
		{
			vector<bou_descriptor> tile1, tile2, tile3;
			bou_descriptor bd1, bd2;
			vector<Point2f>P, P1;
			for (int i = 0; i < 4; i++)
			{
				bd1.C.push_back(P);
				bd2.C.push_back(P);
			}

			vector<Point2f> arc_lb = { Left.boundp2, Bottom.boundp1 };
			//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
			//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
			vector<Point2f> arc_lb2 = { Bottom.boundp2, Left.boundp1 };
			//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
			//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
			append(arc_lb, arc_lb2);
			content_patterns.push_back(arc_lb);

			vector<Point2f> Sline_tb = { Bottom.boundp1, Bottom.boundp2, Top.boundp2, Top.boundp1 };
			if (abs(Bottom.boundp1.x - Top.boundp1.x) < 0.01) Top.deriv_curva1 = { 10000, 0 };
			else Top.deriv_curva1 = { (Top.boundp1.y - Bottom.boundp1.y) / (Top.boundp1.x - Bottom.boundp1.x), 0 };
			if (abs(Bottom.boundp2.x - Top.boundp2.x) < 0.01) Bottom.deriv_curva2 = { 10000, 0 };
			else Bottom.deriv_curva2 = { (Top.boundp2.y - Bottom.boundp2.y) / (Top.boundp2.x - Bottom.boundp2.x), 0 };
			content_patterns.push_back(Sline_tb);

			vector<Point2f> arc_rt = { Top.boundp1, Right.boundp2 };
			//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
			//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
			vector<Point2f> arc_rt2 = { Right.boundp1, Top.boundp2 };
			//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
			//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
			append(arc_rt, arc_rt2);
			content_patterns.push_back(arc_rt);

			//--cr ��¼�߽�������Ϣ
			P.push_back(Left.boundp1);
			P.push_back(Left.boundp2);
			bd1.C[0] = P;
			P.clear();
			P.push_back(Right.boundp1);
			P.push_back(Right.boundp2);
			bd1.C[1] = P;
			P.clear();
			P.push_back(Bottom.boundp1);
			P.push_back(Bottom.boundp2);
			bd1.C[2] = P;
			P.clear();
			P.push_back(Top.boundp1);
			P.push_back(Top.boundp2);
			bd1.C[3] = P;
			all_C.push_back(bd1);

			break;
		}
		//case ltArbP:
		//{
		//	vector<bou_descriptor> tile1, tile2, tile3;
		//	bou_descriptor bd1, bd2;
		//	vector<Point2f>P, P1;
		//	for (int i = 0; i < 4; i++)
		//	{
		//		bd1.C.push_back(P);
		//		bd2.C.push_back(P);
		//	}

		//	vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_tl, arc_tl2);
		//	content_patterns.push_back(arc_tl);

		//	vector<Point2f> polyline_br = polyline_gen(Right.boundp1, Bottom.boundp1, bottomRight, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> polyline_br2 = polyline_gen(Bottom.boundp2, Right.boundp2, bottomRight, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	append(polyline_br, polyline_br2);
		//	content_patterns.push_back(polyline_br);

		//	//2 in 1
		//	/*vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);*/

		//	//--cr ��¼�߽�������Ϣ
		//	P.push_back(Left.boundp1);
		//	P.push_back(Left.boundp2);
		//	bd1.C[0] = P;
		//	P.clear();
		//	P.push_back(Right.boundp1);
		//	P.push_back(Right.boundp2);
		//	bd1.C[1] = P;
		//	P.clear();
		//	P.push_back(Bottom.boundp1);
		//	P.push_back(Bottom.boundp2);
		//	bd1.C[2] = P;
		//	P.clear();
		//	P.push_back(Top.boundp1);
		//	P.push_back(Top.boundp2);
		//	bd1.C[3] = P;
		//	all_C.push_back(bd1);

		//	break;
		//}
		//case trAblP:
		//{
		//	vector<bou_descriptor> tile1, tile2, tile3;
		//	bou_descriptor bd1, bd2;
		//	vector<Point2f>P, P1;
		//	for (int i = 0; i < 4; i++)
		//	{
		//		bd1.C.push_back(P);
		//		bd2.C.push_back(P);
		//	}

		//	vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_rt, arc_rt2);
		//	content_patterns.push_back(arc_rt);

		//	vector<Point2f> polyline_lb = polyline_gen(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> polyline_lb2 = polyline_gen(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	append(polyline_lb, polyline_lb2);
		//	content_patterns.push_back(polyline_lb);

		//	//2 in 1
		//	/*vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);*/

		//	//--cr ��¼�߽�������Ϣ
		//	P.push_back(Left.boundp1);
		//	P.push_back(Left.boundp2);
		//	bd1.C[0] = P;
		//	P.clear();
		//	P.push_back(Right.boundp1);
		//	P.push_back(Right.boundp2);
		//	bd1.C[1] = P;
		//	P.clear();
		//	P.push_back(Bottom.boundp1);
		//	P.push_back(Bottom.boundp2);
		//	bd1.C[2] = P;
		//	P.clear();
		//	P.push_back(Top.boundp1);
		//	P.push_back(Top.boundp2);
		//	bd1.C[3] = P;
		//	all_C.push_back(bd1);

		//	break;
		//}
		//case blAtrP:
		//{
		//	vector<bou_descriptor> tile1, tile2, tile3;
		//	bou_descriptor bd1, bd2;
		//	vector<Point2f>P, P1;
		//	for (int i = 0; i < 4; i++)
		//	{
		//		bd1.C.push_back(P);
		//		bd2.C.push_back(P);
		//	}

		//	vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	append(arc_lb, arc_lb2);
		//	content_patterns.push_back(arc_lb);

		//	vector<Point2f> polyline_rt = polyline_gen(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	vector<Point2f> polyline_rt2 = polyline_gen(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(polyline_rt, polyline_rt2);
		//	content_patterns.push_back(polyline_rt);

		//	//2 in 1
		//	/*vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);*/

		//	//--cr ��¼�߽�������Ϣ
		//	P.push_back(Left.boundp1);
		//	P.push_back(Left.boundp2);
		//	bd1.C[0] = P;
		//	P.clear();
		//	P.push_back(Right.boundp1);
		//	P.push_back(Right.boundp2);
		//	bd1.C[1] = P;
		//	P.clear();
		//	P.push_back(Bottom.boundp1);
		//	P.push_back(Bottom.boundp2);
		//	bd1.C[2] = P;
		//	P.clear();
		//	P.push_back(Top.boundp1);
		//	P.push_back(Top.boundp2);
		//	bd1.C[3] = P;
		//	all_C.push_back(bd1);

		//	break;
		//}
		//case rbAltP: //15
		//{
		//	vector<bou_descriptor> tile1, tile2, tile3;
		//	bou_descriptor bd1, bd2;
		//	vector<Point2f>P, P1;
		//	for (int i = 0; i < 4; i++)
		//	{
		//		bd1.C.push_back(P);
		//		bd2.C.push_back(P);
		//	}

		//	vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	append(arc_br, arc_br2);
		//	content_patterns.push_back(arc_br);

		//	vector<Point2f> polyline_tl = polyline_gen(Top.boundp1, Left.boundp1, topLeft, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> polyline_tl2 = polyline_gen(Left.boundp2, Top.boundp2, topLeft, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(polyline_tl, polyline_tl2);
		//	content_patterns.push_back(polyline_tl);

		//	//2 in 1
		//	/*vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);*/

		//	//--cr ��¼�߽�������Ϣ
		//	P.push_back(Left.boundp1);
		//	P.push_back(Left.boundp2);
		//	bd1.C[0] = P;
		//	P.clear();
		//	P.push_back(Right.boundp1);
		//	P.push_back(Right.boundp2);
		//	bd1.C[1] = P;
		//	P.clear();
		//	P.push_back(Bottom.boundp1);
		//	P.push_back(Bottom.boundp2);
		//	bd1.C[2] = P;
		//	P.clear();
		//	P.push_back(Top.boundp1);
		//	P.push_back(Top.boundp2);
		//	bd1.C[3] = P;
		//	all_C.push_back(bd1);

		//	break;
		//}
		//case topVacancy:
		//{
		//	vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	//Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	append(arc_br, arc_br2);
		//	content_patterns.push_back(arc_br);

		//	vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	//Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	append(arc_lb, arc_lb2);
		//	content_patterns.push_back(arc_lb);

		//	vector<double> deriv_curvas_ = { 0,0,0,0 };
		//	Top.input_curva(Top.boundp1, deriv_curvas_, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas_, -isFirst);
		//	//2 in 1
		//	vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);
		//	break;
		//}
		//case rightVacancy:
		//{
		//	vector<Point2f> arc_lb = arc_fun(Left.boundp2, Bottom.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_lb2 = arc_fun(Bottom.boundp2, Left.boundp1, Point2f(topLeft.x, topLeft.y - height), center, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	//Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	append(arc_lb, arc_lb2);
		//	content_patterns.push_back(arc_lb);

		//	vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
		//	//Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_tl, arc_tl2);
		//	content_patterns.push_back(arc_tl);

		//	vector<double> deriv_curvas_ = { 0, 0, 0, 0 };
		//	Right.input_curva(Right.boundp1, deriv_curvas_, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas_, -isFirst);
		//	//2 in 1
		//	vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);
		//	break;
		//}
		//case leftVacancy:
		//{
		//	vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	//Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_rt, arc_rt2);
		//	content_patterns.push_back(arc_rt);

		//	vector<Point2f> arc_br = arc_fun(Right.boundp1, Bottom.boundp1, bottomRight, center, deriv_curvas);
		//	//Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_br2 = arc_fun(Bottom.boundp2, Right.boundp2, bottomRight, center, deriv_curvas);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	append(arc_br, arc_br2);
		//	content_patterns.push_back(arc_br);

		//	vector<double> deriv_curvas_ = { 0, 0, 0, 0 };
		//	Left.input_curva(Left.boundp1, deriv_curvas_, isFirst);
		//	Left.input_curva(Left.boundp2, deriv_curvas_, -isFirst);
		//	//2 in 1
		//	vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);
		//	break;
		//}
		//case bottomVacancy:
		//{
		//	vector<Point2f> arc_tl = arc_fun(Top.boundp1, Left.boundp1, topLeft, center, deriv_curvas);
		//	Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Left.input_curva(Left.boundp1, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_tl2 = arc_fun(Left.boundp2, Top.boundp2, topLeft, center, deriv_curvas);
		//	Left.input_curva(Left.boundp2, deriv_curvas, isFirst);
		//	//Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_tl, arc_tl2);
		//	content_patterns.push_back(arc_tl);

		//	vector<Point2f> arc_rt = arc_fun(Top.boundp1, Right.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	//Top.input_curva(Top.boundp1, deriv_curvas, isFirst);
		//	Right.input_curva(Right.boundp2, deriv_curvas, -isFirst);
		//	vector<Point2f> arc_rt2 = arc_fun(Right.boundp1, Top.boundp2, Point2f(bottomRight.x, bottomRight.y + height), center, deriv_curvas);
		//	Right.input_curva(Right.boundp1, deriv_curvas, isFirst);
		//	Top.input_curva(Top.boundp2, deriv_curvas, -isFirst);
		//	append(arc_rt, arc_rt2);
		//	content_patterns.push_back(arc_rt);

		//	vector<double> deriv_curvas_ = { 0, 0, 0, 0 };
		//	Bottom.input_curva(Bottom.boundp1, deriv_curvas_, isFirst);
		//	Bottom.input_curva(Bottom.boundp2, deriv_curvas_, -isFirst);
		//	//2 in 1
		//	vector<Point2f> contour2 = mix_contour(content_patterns);
		//	content_patterns.swap(vector<vector<Point2f>>());
		//	content_patterns.push_back(contour2);
		//	break;
		//}
		}
	}

	//--------------------------Tile------------------------------------------

	//--------------------------TilingScheme------------------------------------------

	TilingScheme::TilingScheme()
	{
		tile_edge_l = 200;
	}

	TilingScheme::TilingScheme(double length_edge)
	{
		tile_edge_l = length_edge;
	}

	TilingScheme::~TilingScheme(){}

	vector<Tile> TilingScheme::com_all_tiles(vector<double> sigma, vector<double> mu, vector<Scalar> color_rgb)
	{
		vector<CS> Color_;
		int size_sig = sigma.size();
		int size_mu = mu.size();
		for (int i = 0; i < size_mu; i++)
		{
			for (int j = 0; j < size_sig; j++)
			{
				CS newone(mu[i], sigma[j], 230, color_rgb[i]);
				Color_.push_back(newone);//������ɫģʽ25
			}
		}
		int size_color = Color_.size();
		cout << "All color types:" << size_color << endl;
		all_Tile.swap(vector<Tile>());
		for (int i = 0; i < size_color; i++)
		{
			for (int j = 0; j < size_color; j++)
			{
				for (int n = 0; n < size_color; n++)
				{
					for (int m = 0; m < size_color; m++)
					{
						Tile newtile(Point2f(20, 20 + tile_edge_length), Point2f(20 + tile_edge_length, 20));
						newtile.set_colors(Color_[i], Color_[j], Color_[n], Color_[m]);
						all_Tile.push_back(newtile);
					}
				}
			}
		}
		return all_Tile;
	}

	vector<Tile> TilingScheme::com_all_tiles(vector<CS> Color_)
	{
		int size_color = Color_.size();
		cout << "All color types:" << size_color << endl;
		vector<Tile> all_Tile;
		for (int i = 0; i < size_color; i++)
		{
			for (int j = 0; j < size_color; j++)
			{
				for (int n = 0; n < size_color; n++)
				{
					for (int m = 0; m < size_color; m++)
					{
						Tile newtile(Point2f(20, 20 + tile_edge_length), Point2f(20 + tile_edge_length, 20));
						newtile.set_colors(Color_[i], Color_[j], Color_[n], Color_[m]);
						all_Tile.push_back(newtile);
					}
				}
			}
		}
		return all_Tile;
	}

	//ֱ�Ӽ�����ڲ�����ͼ����ȫ��tiles
	vector<Tile> TilingScheme::com_total_tiles(vector<CS> Color_)
	{
		int size_color = Color_.size();
		cout << "The number of boundary conditions: " << size_color << endl;
		vector<Tile> total_Tiles;
		//vector<Tile> all_Tile;
		//Mat showt = Mat(8000, 8000, CV_8UC3, Scalar(255, 255, 255));
		
		for (int i = 0; i < size_color; i++)
		{
			for (int j = 0; j < size_color; j++)
			{
				for (int n = 0; n < size_color; n++)
				{
					for (int m = 0; m < size_color; m++)
					{
						//�������еı߽����
						Tile newtile(Point2f(20, 20 + tile_edge_length), Point2f(20 + tile_edge_length, 20));
						newtile.set_colors(Color_[i], Color_[j], Color_[n], Color_[m]);
						//����ͬһ�߽��µ����п�������
						for (int connect_rule = 0; connect_rule < 9; connect_rule++)
						//for (int connect_rule = 16; connect_rule < 25; connect_rule++)
						{
							Tile new_cont_tile = newtile;
							new_cont_tile.content_gen_rules(connect_rule);
							//�ж��Ƿ����ص�
							all_num++;
							total_Tiles.push_back(new_cont_tile);
							//if ((connect_rule < 8 && !poly_group(new_cont_tile.content_patterns))
							//	|| (connect_rule > 7 && poly_group(new_cont_tile.content_patterns))) //û���ص�
							//{
							//	all_num++;
							//	total_Tiles.push_back(new_cont_tile);
							//	//int jj = all_num / 10;
							//	//int dd = all_num % 10;
							//	//Tile show_tile2 = new_cont_tile;// show_tile.match_tile(all_Tile, st, RightLeft); //
							//	//show_tile2.change_position(Point2f(20 + dd * 110, 1880 - jj * 110));
							//	//show_tile2.draw_Tile(showt);
							//}
						}						
					}
				}
			}
		}
		//imshow("D:\\5*5.png ", showt);
		//imwrite("all_tiles.png", showt);
		cout << "Total number of tiles:" << total_Tiles.size() <<  endl;
		return total_Tiles;
	}
	//--------------------------TilingScheme------------------------------------------

}