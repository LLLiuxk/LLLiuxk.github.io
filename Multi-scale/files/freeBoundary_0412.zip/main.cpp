
#include "freeBoundary.h"

using namespace FreeBound;
using namespace std;

//parameters in load_para.txt
int scale_nums = 3;
int iter_num = 3;
double match_threshold = 0.005;
double dynamic_mt = 0.15;
double re_dynamic_mt = dynamic_mt;///*1.5*dynamic_mt*/0.08;
int topNum_clus = 20;
double Target_max = 0.9;
double Target_min = 0.1;
double local_coef = 0.6;
double average_coef = 0.2;
double gradient_coef = 0.2;
string Image_name = "sky.jpg";  //circle_ramp8, moun4, 2dmat_blur_2
string data_path = "C:/Users/liuxk/OneDrive/Recent/WangTile/data/person/";
string Input_Path = data_path + Image_name;
string result_path = "result/";
string result_num = "result/result_num.txt";
bool error_diffusion = false;
bool error_diffusion_11 = true;
bool box_flags = false;
bool load_tileset = true;

//parameters just for global use
int Image_Width = 100;
int Image_Height = 100;
int image_pixel_w = (Image_Width + 10)*tile_edge_length;
int image_pixel_h = (Image_Height + 10)*tile_edge_length;
int big_error = 0;
int thres_over[5] = { 0, 0, 0, 0, 0 };
string patch_svg_name;
string obj_path;
vector<vector<double>> para_group = /*{ { 0.6, 0.2, 0.2 }, { 0.2, 0.2, 0.6 }, { 0.1, 0.1, 0.8 } };*/{ { 0.6, 0.2, 0.2 }, { 0.4, 0.2, 0.4 }, { 0.2, 0.2, 0.6 } };


bool cmp1(CS a, CS b)
{
	return a.endPoints[1] - a.endPoints[0] < b.endPoints[1] - b.endPoints[0];
}
int main(int argc, char *argv[])
{
	srand((unsigned)time(NULL));
	cout << "------------Load All Parameters-----------" << endl;
	bool control_parameter = true;
	if (control_parameter)
	{/*
		iter_num = atoi(argv[1]);
		match_threshold = atof(argv[2]);
		dynamic_mt = atof(argv[3]);
		topNum_clus = atoi(argv[4]);
		Image_name = argv[5];
		Input_Path = data_path + Image_name;*/
		load_para("para.txt");

	}
	cout << "Image name: " << Image_name << endl
		<< "Image path: " << Input_Path << endl
		<< "Dynamic matching tolerance: " << dynamic_mt << endl
		<< "Iteration times: " << iter_num << endl
		<< "Scale level: " << scale_nums << endl
		<< "Target max density: " << Target_max << endl
		<< "Target min density: " << Target_min << endl
		<< "Coefficients: " << local_coef << "  " << average_coef << "  " << gradient_coef << "  "
		<< endl << endl;
	re_dynamic_mt = dynamic_mt;
	string folder = Image_name.substr(0, Image_name.length() - 4);
	if (error_diffusion)
		result_path = "result/" + folder + "_" + d2s_mant(dynamic_mt, 2) + "_" + to_string(scale_nums) + "(" + to_string(iter_num) + ")_(" + d2s_mant(Target_max, 2) + "," + d2s_mant(Target_min, 2)+")_diff/";
	else if (error_diffusion_11) 
		result_path = "result/" + folder + "_" + d2s_mant(dynamic_mt, 2) + "_" + to_string(scale_nums) + "(" + to_string(iter_num) + ")_(" + d2s_mant(Target_max, 2) + "," + d2s_mant(Target_min, 2) + ")_dif11/";
	else
		result_path = "result/" + folder + "_" + d2s_mant(dynamic_mt, 2) + "_" + to_string(scale_nums) + "(" + to_string(iter_num) + ")_(" + d2s_mant(Target_max, 2) + "," + d2s_mant(Target_min, 2) + ")_nodiff/";
	result_num = result_path + "result_num.txt";
	if (_access(result_path.c_str(), 0) != 0)
	{
		cout << "Creat new folder: " << result_path << endl << endl;
		_mkdir(result_path.c_str());
	}

	int choose = 10;
	//cout << choose << endl;
	//return 0;
	clock_t start, midtime, finish;
	start = clock();
	//vector<double> sigma_ = { 0.1 };// { 0.16, 0.13, 0.10, 0.07, 0.04 };
	//vector<double> mu_ = {0.25, 0.5,0.75 };//{ 0.1, 0.3, 0.5, 0.7, 0.9 };

	//vector<double> sigma_ = { 0.02, 0.09, 0.22 }; //0.02=0.04, 0.03=0.08, 0.04=0.1, 0.05=0.12, 0.09=0.24, 0.22=0.58
	//vector<double> sigma_cu = { 0.05, 0.09, 0.22 };
	vector<double> sigma_ = { 0.1, 0.26, 0.58 };
	vector<double> sigma_cu = { 0.15, 0.24, 0.58 };
	vector<double> sigma_2 = { 0.19,0.48,0.23 }; //{ 0.16, 0.13, 0.10, 0.07, 0.04 };
	
	//vector<double> sigma_ = { 0.02, 0.09, 0.22 }; //{0.02, 0.09, 0.22 }; //{ 0.16, 0.13, 0.10, 0.07, 0.04 };
	
	vector<double> mu_ = { /*0.35,0.65*/0.5 };//{ 0.1, 0.3, 0.5, 0.7, 0.9 };
	vector<double> mu_2 = { 0.6 };//{ 0.1, 0.3, 0.5, 0.7, 0.9 };

	/*sigma_ = sigma_2;
	mu_ = mu_2;*/

	enum color{ Reds, Blues, Greens, Yellows, Purples };
	vector<Scalar> color_rgb = { Scalar(0, 0, 255), Scalar(255, 0, 0), Scalar(0, 255, 0), Scalar(0, 255, 255), Scalar(255, 255, 0) };
	vector<vector<CS>> Color_CS;
	vector<CS> Color_, Color_cu;

	int edge_number = 5;//---cr���ָ������
	TilingScheme tilescheme(tile_edge_length);
	TilingScheme tilescheme_cu(tile_edge_length);

	double ellipse_a = -1;  //������������Բ������a����С��b,�����������ʵķ�Χ���й�һ��
	double ellipse_b = 9;
	for (int i = 0; i < mu_.size(); i++)   //�ܹ���mu_.size()*sigma_.size()�� ��ɫģʽ
	{
		vector<CS> Color;
		for (int j = 0; j < sigma_.size(); j++)
		{
			//CS newone(mu_[i], sigma_[j], 230, color_rgb[i], 0.4);
			CS newone(mu_[i], sigma_[j],color_rgb[i]);
			newone.id = Color_.size();//-----cr
			newone.edge_length = tile_edge_length;
			Color.push_back(newone);//һ����ɫ����ģʽ5
			Color_.push_back(newone);//������ɫģʽ25
			for (int nn = 0; nn < 2; nn++)
			{
				if (newone.endPoints[nn] > 0 && newone.endPoints[nn] < 1)
				{
					if (newone.endPoints[nn]>ellipse_a) ellipse_a = newone.endPoints[nn];
					if (newone.endPoints[nn]<ellipse_b) ellipse_b = newone.endPoints[nn];
				}
			}
		}
		Color_CS.push_back(Color);
	}

	for (int i = 0; i < mu_.size(); i++)   //�ܹ���mu_.size()*sigma_.size()�� ��ɫģʽ
	{
		vector<CS> Color;
		for (int j = 0; j < sigma_cu.size(); j++)
		{
			//CS newone(mu_[i], sigma_cu[j], 230, color_rgb[i], 0.4);
			CS newone(mu_[i], sigma_cu[j], color_rgb[i]);
			newone.id = Color_cu.size();//-----cr
			newone.edge_length = tile_edge_length;
			Color.push_back(newone);//һ����ɫ����ģʽ5
			Color_cu.push_back(newone);//������ɫģʽ25

		}
		Color_CS.push_back(Color);
	}
	//------�����--------------------------
	/*for (int i = 0; i < edge_number; i++)
	{
		CS edge(tile_edge_length);
		edge.set_P();
		edge.id = Color_.size() - 1;
		Color_.push_back(edge);
	}*/
	//--------------------------------------
	
	//max_curvature = ellipse_a / (ellipse_b*ellipse_b*tile_edge_length);
	//cout << "ellipse_a: " << ellipse_a << "  ellipse_b: " << ellipse_b << "  max_curvature: " << max_curvature<<endl;

	//Mat pic_set[5];
	//pic_set[0] = pic_set[1] = pic_set[2] = pic_set[3] = pic_set[4] = Mat(300, 1500, CV_8UC3, Scalar(255, 255, 255));

	//1.��ʾ��̬�ֲ� 2.��ʾ���б� 3.����all Tile,���չʾ 4.����match_tile���� 5.���߶�tiling����
	//6.��߶�ƽ�� 7.arc_gen �������� 8.�߽���ͬ�Ա�ʵ�� 9.patch������ 10.��߶�patchƽ��
	//-----------------------------10. ��߶�patch+tileƽ��------------------------------------------------------------------------
	if (choose == 10)
	{
		cout << endl << "-----------------------------------------" << endl
			<< "        Generate source tiles set!" << endl
			<< "-----------------------------------------" << endl;
		vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		vector<Tile> total_Tiles_cu = tilescheme_cu.com_total_tiles(Color_cu);
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			Tile tt = total_Tiles[i];
			Mat st = Mat(100, 100, CV_8UC3, Scalar(255, 255, 255));
			//tt.draw_Tile(st, Point2f(0, 0));
			tt.draw_tileConts(st, Point2f(0, 0));
			int all_pix = 0;
			for (int j = 0; j < tile_edge_length + 20; j++)
			{
				for (int k = 0; k < tile_edge_length + 20; k++)
				{
					cv::Vec3b vec_3 = st.at<cv::Vec3b>(j, k);
					int a = vec_3[0];
					int b = vec_3[1];
					int c = vec_3[2];
					if (!(a == 255 && b == 255 && c == 255))
						all_pix++;
				}
			}
			total_Tiles[i].black_pic = all_pix;
			//cout << "pic:" << all_pix << endl;
			//imwrite("tile.png", st);
		}
		sort(Color_.begin(), Color_.end(), cmp1);
		midtime = clock();
		cout << endl << "Time consumption for source tile set generation: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;
		Multi_Patch MP(scale_nums);
		if (box_flags)	
			system("chooseTileSize.exe"); // ����flag.txt
		MP.design_reign();
		MP.rotate_process(total_Tiles);//ȷ�����ӹ�ϵ
		midtime = clock();
		cout << endl << "Time consumption for loading image: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;
		string tileset_path = to_string(scale_nums) + "_scale_patch_data_" + d2s_mant(sigma_[0], 2) + "_" + d2s_mant(sigma_[1], 2) + "_" + d2s_mant(sigma_[2], 2) + ".txt";
		if (load_tileset)
		{
			MP.set_sort_density(2);
			MP.set_sort_density(3);
			MP.readPatch(tileset_path);
			cout << "patch_g[c].patch.size(): " << MP.patch_g[0].patch.size()<<"  "<<MP.patch_g[0].patch.size() << endl;
		}
		else
		{
			MP.set_Tms(total_Tiles, Color_);
			MP.writePatch(result_path + tileset_path);//�������ȡ����������patch
		}

		midtime = clock();
		cout << endl << "Time consumption for multi-scale tiles generation: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;
		//test
		//double d[7] = { 0.0, 0.2, 0.4, 0.6, 0.8, 0.3, 0.7 };
		//vector<double> dent = { d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1]};
		//vector<double> dent2 = { d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1], d[3], d[1], d[1], d[1]};
		//vector<double> dent3 = { d[4], d[3], d[2], d[1], d[4], d[3], d[2], d[1], d[4], d[3], d[2], d[1], d[4], d[3], d[2], d[1]};
		//vector<double> den_target = { 0.480645, 0.522581, 0.583871, 0.36129,  0.506452, 0.558065, 0.367742, 0.367742, 0.548387, 0.383871, 0.377419, 0.432258, 0.419355, 0.416129, 0.445161, 0.454839 };
		//vector<double> den_patch = {  0.394667, 0.394667, 0.578489, 0.621511, 0.447822, 0.405867, 0.406578, 0.415822, 0.548267, 0.301689, 0.368711, 0.368, 0.464711, 0.311111, 0.3728, 0.370133 };
		//vector<double> den_patch2 = { 0.500089, 0.500089, 0.500089, 0.500267, 0.499733, 0.499733, 0.499733, 0.503111, 0.498133, 0.498844, 0.498133, 0.497244, 0.503111, 0.499911, 0.585244, 0.4336 };
		////MP.test_show(total_Tiles, Color_, dent, MP.patch_g[2].patch);
		//
		//double patch_e = MP.match_error(den_target, den_patch, local_coef, average_coef, gradient_coef);
		//double pacch2_e = MP.match_error(den_target, den_patch2, local_coef, average_coef, gradient_coef);
		//cout << "patch_e: " << patch_e << " hahahah  " << endl << pacch2_e << endl;

		/*cout << "100: " << MP.match_error(dent, dent2, 1, 0, 0) << "   " << MP.match_error(dent2, dent3, 1, 0, 0) << endl;
		cout << "010: " << MP.match_error(dent, dent2, 0, 1, 0) << "   " << MP.match_error(dent2, dent3, 0, 1, 0) << endl;
		cout << "443: " << MP.match_error(dent, dent2, 0.4, 0.4, 0.3) << "   " << MP.match_error(dent2, dent3, 0.4, 0.4, 0.3) << endl;*/

		MP.draw_all_Patch(0, total_Tiles, Color_, result_path + "all_data.txt");//��������

		MP.tiling(total_Tiles, Color_);
		MP.draw_rest("den_fre.png");
		cout << endl << "-----------------------------------------" << endl
			<< "           Tiling dynamically!" << endl
			<< "-----------------------------------------" << endl;
	    //scale_nums = 1;
		for (int i = scale_nums; i > 1; i--)
		{
			MP.regeneration(total_Tiles, Color_, i);
			//MP.draw_tiling(total_Tiles, Color_, i);
			MP.draw_rest("rest_image_after_"+ to_string(i)+"_scale_tiling.png");
		}
		MP.tiling_supp(0, total_Tiles, Color_);
		//MP.draw_tiling(total_Tiles, Color_,0);
		//MP.draw_all_Patch(1, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���	
		//MP.draw_each_Patch(total_Tiles, Color_, result_path + "usedPatch/");

		for (int i = scale_nums; i > 2; i--)
		{
			MP.post_process(total_Tiles, Color_, i - 1);
		}
		midtime = clock();
		cout << endl << "Time consumption for calculate all: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;
		MP.draw_all_Patch(1, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���, ��������
		MP.draw_tiling(total_Tiles, Color_, 1, 0);
		//MP.draw_tiling(total_Tiles_cu, Color_cu, 0, 10);
		MP.draw_each_Patch(total_Tiles, Color_, result_path + "usedPatch2/");
		MP.draw_each_Patch(total_Tiles_cu, Color_cu, result_path + "usedPatch_cu/");
		MP.draw_all_Patch(3, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���, �ܶ�����
		//MP.draw_all_Patch(4, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���, ʹ�ô�������	
		MP.writePatch(result_path+ "patch_data.txt");//��������patch
		
		cout << "compute over!" << endl;

		int unit_piexl = tile_edge_length;
		Mat tt(image_pixel_h, image_pixel_w, CV_8UC3, Scalar::all(255));
		color_bar color1;
		int error_level = 100;
		vector<Scalar> colorbar = color1.setColorMode(0, error_level);
		vector<vector<double>> error_t;
		double min, max;
		int col = Image_Width;
		int row = Image_Height;
		//error_t = readError("D://error3.txt", 100,min ,max);
		error_t = readError(result_path + "error.txt", col, min, max);
		min = 0.0;
		max = 0.6;
		double each_e = (max - min) / error_level;

		cout << max << "  " << min << "  " << each_e << endl;
		Point offset(0, 0);
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				int e_level = (error_t[i][j] - min) / each_e;
				//cout << error_t[i][j]<<"   "<<e_level << endl;
				Point lt = Point(j*unit_piexl, i*unit_piexl) + offset;
				draw_error_map(tt, colorbar, lt, e_level, unit_piexl, 1);
			}
		}
		int num_value = 11; //num �꼸������,num-1�Ǽ����
		color1.DrawColorBar(tt, Point(unit_piexl * col + 60, image_pixel_h / 2), Point(unit_piexl * col + 120, 80), min, max, num_value);
		//imshow("", tt);
		imwrite(result_path +"error_map.png", tt);
		//image_histogram("D:\\lena.jpg",5,1);
		merge_two_maps(result_path + "divide_with_init_1.png", result_path + "error_map.png", result_path + "merge_map.png", 8);
		merge_two_maps(result_path + "divide_with_init_1.png", result_path + "tiling_result_black_with_init_1.png", result_path + "merge_map2.png", -20);
		cout << result_path<<endl<< MP.total_type_num << "  " << MP.total_type_times << endl;
		
		string new_path = result_path.substr(0, result_path.length() - 1) + "_" + to_string(MP.total_type_num) + "_" + to_string(MP.total_type_times);
		if (_access(result_path.c_str(), 0) == 0) rename(result_path.c_str(), new_path.c_str());

	}
	//------------------------------3.����all Tile, ���չʾ---------------------------------------------------------------------
	if (choose == 3)
	{
		vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		cout << "quantity:" << total_Tiles.size() << endl;
		Mat stfinal = Mat(5000, 5000, CV_8UC3, Scalar(255, 255, 255));
		patch_svg_name = "C:\\Users\\liuxk\\OneDrive\\Recent\\WangTile\\result\\RUS_65.svg";
		string png_name = "C:\\Users\\liuxk\\OneDrive\\Recent\\WangTile\\result\\RUS_65.png";
		create_svg(patch_svg_name);
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			Tile tt = total_Tiles[i];
			int ii = i % 40;
			int jj = i / 40;
			//tt.draw_Tile(st, Point2f(0, 0));
			Point2f shift_ = Point2f(ii * (45 + tile_edge_length) + 20, jj * (75 + tile_edge_length) + 20);
			tt.draw_tileConts(stfinal, shift_);


			Mat st = Mat(100, 100, CV_8UC3, Scalar(255, 255, 255));
			//tt.draw_Tile(st, Point2f(0, 0));
			tt.draw_tileConts(st, Point2f(0, 0), -1, 1);
			int all_pix = 0;
			for (int j = 0; j < tile_edge_length + 25; j++)
			{
				for (int k = 0; k < tile_edge_length + 25; k++)
				{
					cv::Vec3b vec_3 = st.at<cv::Vec3b>(j, k);
					int a = vec_3[0];
					int b = vec_3[1];
					int c = vec_3[2];
					if (!(a == 255 && b == 255 && c == 255))
						all_pix++;
				}
			}
			total_Tiles[i].black_pic = all_pix;
			//cout << "all_pix:" << all_pix << endl;
			stringstream ss;
			ss << setiosflags(ios::fixed) << setprecision(4) << all_pix / 75.0 / 75.0 << endl;
			string x_value_s;
			ss >> x_value_s;
			putText(stfinal, x_value_s, shift_ + Point2f(20, 120), FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 2);

			add_word_svg(patch_svg_name, x_value_s, Scalar(0, 0, 0), shift_ + Point2f(35, 110));
			cout << i << "  pic:" << all_pix << endl;
			//imwrite("tile.png", st);
		}
		//sort(Color_.begin(), Color_.end(), cmp1);
		imwrite(png_name, stfinal);
		end_svg(patch_svg_name);

	}
	//----------------------------11.����Ԥ���趨�õ�tile set
	if (choose == 11)
	{
		cout << endl << "-----------------------------------------" << endl
			<< "        Generate source tiles set!" << endl
			<< "-----------------------------------------" << endl;
		vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		vector<Tile> total_Tiles_cu = tilescheme_cu.com_total_tiles(Color_cu);
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			Tile tt = total_Tiles[i];
			Mat st = Mat(100, 100, CV_8UC3, Scalar(255, 255, 255));
			//tt.draw_Tile(st, Point2f(0, 0));
			tt.draw_tileConts(st, Point2f(0, 0));
			int all_pix = 0;
			for (int j = 0; j < tile_edge_length + 20; j++)
			{
				for (int k = 0; k < tile_edge_length + 20; k++)
				{
					cv::Vec3b vec_3 = st.at<cv::Vec3b>(j, k);
					int a = vec_3[0];
					int b = vec_3[1];
					int c = vec_3[2];
					if (!(a == 255 && b == 255 && c == 255))
						all_pix++;
				}
			}
			total_Tiles[i].black_pic = all_pix;
			//cout << "pic:" << all_pix << endl;
			//imwrite("tile.png", st);
		}
		sort(Color_.begin(), Color_.end(), cmp1);

		Multi_Patch MP(3, Color_.size());
		MP.design_reign();

		MP.rotate_process(total_Tiles);//ȷ�����ӹ�ϵ
		MP.readPatch(result_path + "patch_data.txt");
		MP.draw_all_Patch(0, total_Tiles, Color_, result_path + "all_data.txt");//��������

		MP.tiling(total_Tiles, Color_);
		cout << endl << "-----------------------------------------" << endl
			<< "           Tiling!" << endl
			<< "-----------------------------------------" << endl;
		for (int i = 3; i > 1; i--)
		{
			int patch_scale = i - 1;
			int p_index = patch_size[patch_scale] - 1;
			MP.tiling_each_scale(p_index, total_Tiles, Color_);
			MP.draw_tiling(total_Tiles, Color_, i);
			MP.draw_rest("rest_image.png");
		}
		MP.tiling_supp(0, total_Tiles, Color_);
		//MP.draw_tiling(total_Tiles, Color_,0);
		MP.draw_all_Patch(1, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���	
		MP.draw_each_Patch(total_Tiles, Color_, result_path + "usedPatch/");

		//MP.post_process(total_Tiles, Color_, 2);
		MP.draw_tiling(total_Tiles, Color_, 0, 1);
		MP.draw_all_Patch(1, total_Tiles, Color_, result_path + "selected_data.txt");//�����õ���, ��������
		//MP.draw_each_Patch(total_Tiles, Color_, result_path+ "usedPatch2/");
		//MP.draw_each_Patch(total_Tiles_cu, Color_cu, result_path+ "usedPatch_cu/");
		MP.draw_all_Patch(3, total_Tiles, Color_, result_path+ "selected_data.txt");//�����õ���, �ܶ�����
		MP.draw_all_Patch(4, total_Tiles, Color_, result_path+ "selected_data.txt");//�����õ���, ʹ�ô�������	


		cout << "compute over!" << endl;

		int unit_piexl = tile_edge_length;
		Mat tt(image_pixel_h, image_pixel_w, CV_8UC3, Scalar::all(255));
		color_bar color1;
		int error_level = 100;
		vector<Scalar> colorbar = color1.setColorMode(0, error_level);
		vector<vector<double>> error_t;
		double min, max;
		int col = Image_Width;
		int row = Image_Height;
		//error_t = readError("D://error3.txt", 100,min ,max);
		error_t = readError(result_path+ "error.txt", col, min, max);
		min = 0.0;
		max = 0.6;
		double each_e = (max - min) / error_level;

		cout << max << "  " << min << "  " << each_e << endl;
		Point offset(0, 0);
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				int e_level = (error_t[i][j] - min) / each_e;
				//cout << error_t[i][j]<<"   "<<e_level << endl;
				Point lt = Point(j*unit_piexl, i*unit_piexl) + offset;
				draw_error_map(tt, colorbar, lt, e_level, unit_piexl, 1);
			}
		}
		int num_value = 11; //num �꼸������,num-1�Ǽ����
		color1.DrawColorBar(tt, Point(unit_piexl * col + 60, image_pixel_h / 2), Point(unit_piexl * col + 120, 50), min, max, num_value);
		//imshow("", tt);
		imwrite(result_path+ "error_map.png", tt);
		//image_histogram("D:\\lena.jpg",5,1);
		merge_two_maps(result_path+ "divide0_1.png", result_path+ "error_map.png", result_path+ "merge_map.png", 8);
		merge_two_maps(result_path+ "divide0_1.png", result_path+ "tiling_result_0_1.png", result_path+ "merge_map2.png", -20);
	}
 	//------------------------1.��ʾ��̬�ֲ�------------------------------------------------------------------------------------
	if (choose == 1)
	{		
		for (int i = 0; i < mu_.size(); i++)
		{
			Mat pic(300, 1500, CV_8UC3, Scalar(255, 255, 255));
			for (int j = 0; j < sigma_.size(); j++)
			{
				Color_CS[i][j].show_fun(pic, j);
				cout << "endPoints: " << Color_CS[i][j].endPoints[0] << "  " << Color_CS[i][j].endPoints[1]<<endl;
			}
			imshow("GaussFunction " + to_string(i), pic);
			imwrite("GaussFunction " + to_string(i) + ".png", pic);//��̬�ֲ�ͼ
		}
	}
	//-------------------------2.��ʾ���б�------------------------------------------------------------------------------------
	if (choose == 2)
	{
		Mat show = Mat(1000, 1600, CV_8UC3, Scalar(255, 255, 255));
		R_Edge test[25];
		for (int i = 0; i < sigma_.size(); i++)
		{
			test[i].set_parameters(Point2f(i * 85 + 10, 10), Point2f(i * 85 + 85, 10), Color_CS[Reds][i]);
			test[i].draw_edge(show);
			/*test[i + 5].set_parameters(Point2f(i * 320 + 10, 210), Point2f(i * 320 + 310, 210), Color_CS[Blues][i]);
			test[i + 5].draw_edge(show);
			test[i + 10].set_parameters(Point2f(i * 320 + 10, 410), Point2f(i * 320 + 310, 410), Color_CS[Greens][i]);
			test[i + 10].draw_edge(show);*/
			/*test[i + 15].set_parameters(Point2f(i * 320 + 10, 610), Point2f(i * 320 + 310, 610), Color_CS[Yellows][i]);
			test[i + 15].draw_edge(show);
			test[i + 20].set_parameters(Point2f(i * 320 + 10, 810), Point2f(i * 320 + 310, 810), Color_CS[Purples][i]);
			test[i + 20].draw_edge(show);*/
		}
		imshow("the edge color ", show);
		imwrite("edge_color.png", show);
	}
	
	//-----------------------------------4.����match_tile����---------------------------------------------------------------
	if (choose == 4)
	{
		vector<Tile> all_Tile = tilescheme.com_total_tiles(Color_);
		cout << "all_Tile:" << all_Tile.size() << endl;
		Mat show3 = Mat(300, 1500, CV_8UC3, Scalar(255, 255, 255));
		////Tile show_tile(Point2f(20, 120), Point2f(120, 20));
		/////*show_tile.set_colors(Color_[2], Color_[2], Color_[2], Color_[2]);
		////show_tile.draw_tileEdges(show3);*/
		////show_tile = all_Tile[100];
		//////srand((unsigned)time(NULL));
		//////int iii = rand();
		//////cout << "iii: " << 55 << endl;

		Tile show_tile = all_Tile[0];
		show_tile.draw_Tile(show3);
		vector<Tile> all_Tile_ = { all_Tile[1595], all_Tile[5773] };
		for (int t = 0; t < 5; t++)
		{
			int st;
			Tile show_tile2 = show_tile.match_tile_with_constrain(all_Tile, st, RightLeft);// show_tile.match_tile(all_Tile, st, RightLeft); //
			show_tile2.change_position(show_tile.bottomRight + Point2f(10, tile_edge_length));
			show_tile2.draw_Tile(show3);
			show_tile = show_tile2;
			//cout << "Content Type: " << Connect_rules_string[show_tile2.content_type] << endl;

			/*Tile test = show_tile2;
			test*/

		}
		imshow("two tiles matching ", show3);

	}
	//---------------------------5.���߶�tiling ����--------------------------------------------------------

	if (choose == 5)
	{
		vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		midtime = clock();
		cout << endl << "midtime: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;

		Mat show4 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Mat show22 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Mat show222 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Tile tiles[6][6];
		int st = 100;
		int row = 6;
		int col = 6;
		int index_tiles[Array_num][Array_num];//��¼��ѡtile���
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				if (i == 0 && j == 0)
				{
					tiles[i][j] = total_Tiles[st];
					index_tiles[i][j] = st;
				}
				else if (i == 0 && j != 0)
				{
					//����ѡ��error��С��
					tiles[i][j] = tiles[i][j - 1].match_tile_with_constrain(total_Tiles, st, RightLeft);
					index_tiles[i][j] = st;
				}
				else if (i != 0 && j == 0)
				{
					tiles[i][j] = tiles[i - 1][j].match_tile_with_constrain(total_Tiles, st, BottomTop);
					index_tiles[i][j] = st;
				}
				else
				{
					//�����С�ڲ���ֵ�ĺ�ѡ���л���,������ܼ���Ϊ��,��������ֵ֪����Ϊ��,������ѡ��
					double min_e = 1000;
					vector<int> final_;
					for (int f_num = 0; f_num < total_Tiles.size(); f_num++)
					{
						double error_ = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[f_num].Top);
						error_ += tiles[i][j - 1].Right.compare_edge_with(total_Tiles[f_num].Left);
						if (error_ <= min_e)
						{
							if (min_e - error_ > 0.001)
							{
								final_.swap(vector<int>());
								min_e = error_;
								//min_index = i;
								final_.push_back(f_num);
							}
							else
							{
								final_.push_back(f_num);
							}
						}
					}
					

					int itt = rand() % final_.size();
					tiles[i][j] = total_Tiles[final_[itt]];
					index_tiles[i][j] = final_[itt];
					cout << "-----------------------------------------------------------------" << endl << endl;
					cout << "min_error:" << min_e << "  final:  " << final_.size() << "   itt: " << itt << "  final_[itt]: " << final_[itt] << endl;
					cout << "-----------------------------------------------------------------" << endl << endl;
					
					//double th = 0.1;
					//vector<int> top_cand = tiles[i - 1][j].match_tile_with_constrain(total_Tiles, th, BottomTop);
					//vector<int> left_cand = tiles[i][j - 1].match_tile_with_constrain(total_Tiles, th, RightLeft);
					//vector<int> final_ = intersect(top_cand, left_cand);
					//while (final_.size() == 0)
					//{
					//	th += 0.03;
					//	top_cand = tiles[i - 1][j].match_tile_with_constrain(total_Tiles, th, BottomTop);
					//	left_cand = tiles[i][j - 1].match_tile_with_constrain(total_Tiles, th, RightLeft);
					//	final_ = intersect(top_cand, left_cand);
					//	cout << "threshold: " << th << endl;
					//}
					//cout << "top_cand: " << top_cand.size() << "  left_cand: " << left_cand.size() << "  final:  " << final_.size() << endl;
					////int itt = rand() % final_.size();
					//double min_e = 1000;
					//int itt = 0;
					//for (int f_num = 0; f_num < final_.size(); f_num++)
					//{
					//	double error_ = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[final_[f_num]].Top);
					//	error_ += tiles[i][j - 1].Right.compare_edge_with(total_Tiles[final_[f_num]].Left);
					//	if (error_ < min_e)
					//	{
					//		min_e = error_;
					//		itt = f_num;
					//	}
					//}
					//tiles[i][j] = total_Tiles[final_[itt]];
					//index_tiles[i][j] = final_[itt];
				}
				//������ݱ߽�ƥ��ɹ�������������
				tiles[i][j].change_position(Point2f(20 + j * (10 + tile_edge_length), 980 - i * (10 + tile_edge_length)));
				tiles[i][j].draw_Tile(show22);
				Point2f shift = Point2f(-9 * j, 9 * i);
				tiles[i][j].draw_tileConts(show222, shift);
			}
		}
		imshow("5*5 tiles matching only content ", show222);
		imwrite("D://result_wt/Only conten.jpg", show222);
		imshow("5*5 tiles matching with content ", show22);
		imwrite("D://result_wt/With conten.jpg", show22);

		//fileout_array("D://result_wt/index_tiles.txt", index_tiles, row, col);
		fileout_array("index_tiles.txt", index_tiles, row, col);
		

	}
	//---------------------------------------6.��߶�ƽ��-----------------------------------------------------
	if (choose == 6)
	{
		vector<Tile> all_Tile = tilescheme.com_all_tiles(Color_);
		Mat show5 = Mat(600, 600, CV_8UC3, Scalar(255, 255, 255));
		Tile tiles_scale[10][8];
		int st;
		int _scale[10][8] =
		{
			1, -1, 0, -1, -1, -1, 1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			1, -1, -1, -1, -1, -1, 1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			1, -1, 0, -1, -1, -1, 1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			1, -1, -1, -1, -1, -1, 1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			1, -1, 1, -1, 1, -1, 1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1

		};//��¼��ǰλ��������һ�㼶 0��1��2С
		int edge_p[50][50], scale[50][50];
		memset(edge_p, -1, sizeof(edge_p));
		memset(scale, -1, sizeof(scale));

		//big
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (_scale[i][j] == 0)
				{
					//cout << endl;
					for (int k1 = 0; k1 < 4; k1++)
					{
						for (int k2 = 0; k2 < 4; k2++)
						{
							if (k1 == 0 && k2 == 0)
							{
								scale[i + k1][j + k2] = _scale[i + k1][j + k2];
								edge_p[i + k1][j + k2] = k1 * 4 + k2;
								if (i == 0 && j == 0)
								{
									//tiles_scale[i + k1][j + k2] = all_Tile[rand() % all_Tile.size()];
									tiles_scale[i + k1][j + k2] = all_Tile[400];
								}
								else if (i <= 3 && j != 0)
								{
									if (j - 4 >= 0 && _scale[i][j - 4] == 0)//���ڱ�
									{
										tiles_scale[i][j] = tiles_scale[i][j - 4].match_tile(all_Tile, st, RightLeft);
									}
									else
									{
										//tiles_scale[i + k1][j + k2] = all_Tile[rand() % all_Tile.size()];
										tiles_scale[i + k1][j + k2] = all_Tile[400];
									}
								}
								else if (i != 0 && j <= 3)
								{
									if (i - 4 >= 0 && _scale[i - 4][j] == 0)
									{
										tiles_scale[i][j] = tiles_scale[i - 4][j].match_tile(all_Tile, st, BottomTop);
									}
									else
									{
										tiles_scale[i + k1][j + k2] = all_Tile[rand() % all_Tile.size()];
									}
								}
								else
								{
									if (_scale[i][j - 4] == 0 && _scale[i][j - 4] != 0)
									{
										tiles_scale[i][j] = tiles_scale[i][j - 4].match_tile(all_Tile, st, RightLeft);
									}
									else if (_scale[i][j - 4] != 0 && _scale[i][j - 4] == 0)
									{
										tiles_scale[i][j] = tiles_scale[i - 4][j].match_tile(all_Tile, st, BottomTop);
									}
									else if (_scale[i][j - 4] == 0 && _scale[i][j - 4] == 0)
									{
										vector<int> top_cand = tiles_scale[i - 4][j].match_tile(all_Tile, 0.01, BottomTop);
										vector<int> left_cand = tiles_scale[i][j - 4].match_tile(all_Tile, 0.01, RightLeft);
										vector<int> final_ = intersect(top_cand, left_cand);
										//srand((unsigned)time(NULL));
										int itt = rand() % final_.size();
										tiles_scale[i][j] = all_Tile[final_[itt]];
									}
									else
									{
										tiles_scale[i + k1][j + k2] = all_Tile[rand() % all_Tile.size()];
									}
								}
								tiles_scale[i][j].change_position(Point2f(20 + j * 30, 120 + i * 30));
								tiles_scale[i][j].draw_tileEdges(show5);
								cout << "para1: " << tiles_scale[i][j].Left.edge_colorScheme.Mu << " " << tiles_scale[i][j].Left.edge_colorScheme.Sigma << endl;
								cout << "para2: " << tiles_scale[i][j].Right.edge_colorScheme.Mu << " " << tiles_scale[i][j].Right.edge_colorScheme.Sigma << endl;
								cout << "para3: " << tiles_scale[i][j].Top.edge_colorScheme.Mu << " " << tiles_scale[i][j].Top.edge_colorScheme.Sigma << endl;
								cout << "para4: " << tiles_scale[i][j].Bottom.edge_colorScheme.Mu << " " << tiles_scale[i][j].Bottom.edge_colorScheme.Sigma << endl;
							}
							else
							{
								tiles_scale[i + k1][j + k2] = tiles_scale[i][j];
								scale[i + k1][j + k2] = _scale[i][j];
								edge_p[i + k1][j + k2] = k1 * 4 + k2;
							}
						}
					}
				}
			}
		}
		//middle
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (_scale[i][j] == 1)
				{
					for (int k1 = 0; k1 < 2; k1++)
					{
						for (int k2 = 0; k2 < 2; k2++)
						{
							if (k1 == 0 && k2 == 0)
							{
								scale[i + k1][j + k2] = _scale[i][j];
								edge_p[i + k1][j + k2] = k1 * 2 + k2;
								map<int, int>m1, m2, m3, m4;
								vector<int> top, bottom, left, right;
								int f1 = 0, f2 = 0, f3 = 0, f4 = 0;
								//top
								if (i - 2 >= 0 && scale[i - 2][j] != -1)
								{
									f1 = 1;
									if (scale[i - 2][j] == 0)//big
										top = tiles_scale[i - 4][j].match_tile(all_Tile, 5500, 0, 0, edge_p[i - 2][j] % 4, m1);
									else if (scale[i - 2][j] == 1)//middle
										top = tiles_scale[i - 2][j].match_tile(all_Tile, 100, 0, 1, edge_p[i - 2][j] % 2, m1);
								}
								//bottom
								if (i + 2 < 10 && scale[i + 2][j] != -1)
								{
									f2 = 1;
									if (scale[i + 2][j] == 0)//big
										bottom = tiles_scale[i + 4][j].match_tile(all_Tile, 5500, 1, 0, edge_p[i + 2][j] % 4, m2);
									else if (scale[i + 2][j] == 1)//middle
										bottom = tiles_scale[i + 2][j].match_tile(all_Tile, 100, 1, 1, edge_p[i + 2][j] % 2, m2);
								}
								//left
								if (j - 2 >= 0 && scale[i][j - 2] != -1)
								{
									f3 = 1;
									if (scale[i][j - 2] == 0)//big
										left = tiles_scale[i][j - 4].match_tile(all_Tile, 5500, 2, 0, edge_p[i][j - 2] / 4 < 2 ? 2 : 0, m3);
									else if (scale[i][j - 2] == 1)//middle
										left = tiles_scale[i][j - 2].match_tile(all_Tile, 100, 2, 1, edge_p[i][j] / 2, m3);
								}
								//right
								if (j + 2 < 8 && scale[i][j + 2] != -1)
								{
									f4 = 1;
									if (scale[i][j + 2] == 0)//big
										right = tiles_scale[i][j + 4].match_tile(all_Tile, 5500, 3, 0, edge_p[i][j + 2] / 4 < 2 ? 3 : 0, m4);
									else if (scale[i][j + 2] == 1)//middle
										right = tiles_scale[i][j + 2].match_tile(all_Tile, 100, 3, 1, edge_p[i][j + 2] / 2, m4);
								}

								vector<int> final_;
								for (int i = 0; i < all_Tile.size(); i++)
								{
									final_.push_back(i);
								}
								if (f1)
									final_ = intersect(final_, top);
								if (f2)
									final_ = intersect(final_, bottom);
								if (f3)
									final_ = intersect(final_, left);
								if (f4)
									final_ = intersect(final_, right);

								srand((unsigned)time(NULL));
								int itt;
								if (final_.size() == 0)
								{
									tiles_scale[i][j] = all_Tile[0];
									cout << "error1" << i << " " << j << endl;
								}
								else
								{
									int minl = 10000000;
									for (int kk = 0; kk < final_.size(); kk++)
									{
										//cout << m1[final_[kk]] << " " << m2[final_[kk]] << " " << m3[final_[kk]] << " " << m4[final_[kk]] << endl;
										int temp = m1[final_[kk]] + m2[final_[kk]] + m3[final_[kk]] + m4[final_[kk]];
										if (temp < minl)
										{
											minl = temp;
											itt = kk;
										}
										ofstream out("D:\\b.txt", ios::app);
										out << i << " " << j << " " << endl;
										out << "error:" << temp << endl;
										out << "para1: " << all_Tile[final_[kk]].Left.edge_colorScheme.Mu << " " << all_Tile[final_[kk]].Left.edge_colorScheme.Sigma << endl;
										out << "para2: " << all_Tile[final_[kk]].Right.edge_colorScheme.Mu << " " << all_Tile[final_[kk]].Right.edge_colorScheme.Sigma << endl;
										out << "para3: " << all_Tile[final_[kk]].Top.edge_colorScheme.Mu << " " << all_Tile[final_[kk]].Top.edge_colorScheme.Sigma << endl;
										out << "para4: " << all_Tile[final_[kk]].Bottom.edge_colorScheme.Mu << " " << all_Tile[final_[kk]].Bottom.edge_colorScheme.Sigma << endl;

									}
									cout << "error:" << i << " " << j << " " << minl << endl;
									tiles_scale[i][j] = all_Tile[final_[itt]];
								}

								tiles_scale[i][j].change_position(Point2f(20 + j * 30, 20 + i * 30));//���Ͻ�
								tiles_scale[i][j].draw_tileEdges(show5, 1);
								cout << "para1: " << tiles_scale[i][j].Left.edge_colorScheme.Mu << " " << tiles_scale[i][j].Left.edge_colorScheme.Sigma << endl;
								cout << "para2: " << tiles_scale[i][j].Right.edge_colorScheme.Mu << " " << tiles_scale[i][j].Right.edge_colorScheme.Sigma << endl;
								cout << "para3: " << tiles_scale[i][j].Top.edge_colorScheme.Mu << " " << tiles_scale[i][j].Top.edge_colorScheme.Sigma << endl;
								cout << "para4: " << tiles_scale[i][j].Bottom.edge_colorScheme.Mu << " " << tiles_scale[i][j].Bottom.edge_colorScheme.Sigma << endl;
								imwrite("test.png", show5);
							}
							else
							{
								tiles_scale[i + k1][j + k2] = tiles_scale[i][j];
								scale[i + k1][j + k2] = _scale[i][j];
								edge_p[i + k1][j + k2] = k1 * 2 + k2;
							}
						}
					}
				}
			}
		}

		imshow("5*5 tiles matching ", show5);
		imwrite("result_66_scale_tt.png", show5);
	}
	//-----------------------------7. arc_gen ��������------------------------------------------------------------------------
	if (choose == 7)
	{
		//Mat show11 = Mat(600, 600, CV_8UC3, Scalar(255, 255, 255));
		////vector<Point2f> arc_points = arc_gen(Point2f(150, 150), Point2f(150, 250), Point2f(150, 150)); //, Point2f(250, 150)
		////cout << arc_points[0] << "  " << arc_points[arc_points.size() - 1] << endl;
		//vector<Point2f> arc_br = arc_gen(Point2f(300, 400), Point2f(100, 20), Point2f(300, 20), Point2f(100, 100));
		//vector<Point2f> arc_br2 = arc_gen(Point2f(300, 20), Point2f(300, 300), Point2f(300, 20), Point2f(100, 100));
		//append(arc_br, arc_br2);
		//cout << "arc_br: " << arc_br.size() << endl;
		//draw_poly(show11, arc_br);
		///*for (int i = 0; i < arc_points.size() - 1; i++)
		//{
		//	int thickness = 5;
		//	int lineType = 8;
		//	Scalar color;
		//	if (i<20) color = Scalar(255, 255, 0);
		//	else color = Scalar(255, 0, 0);
		//	line(show11, arc_points[i], arc_points[i + 1], color, thickness, lineType);
		//}*/
		//imshow("asdasd", show11);

		//vector<Point2f> arc_points2 = arc_gen(Point2f(-0.7071, 0.7071), Point2f(-0.7071, -0.7071), Point2f(0, 0));
	}
	if (choose == 8)
	{
		vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		int totalsize = total_Tiles.size();
		cout << "totalsize: "<<totalsize << endl;
		midtime = clock();
		cout << endl << "midtime: " << (double)(midtime - start) / CLOCKS_PER_SEC << " s " << endl;

		Mat show4 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Mat show22 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Mat show222 = Mat(1000, 1000, CV_8UC3, Scalar(255, 255, 255));
		Tile tiles[6][6];
		int st = 100;
		int row = 6;
		int col = 6;
		//vector<vector<int>> index_tiles = filein_array("D://result_wt/index_tiles.txt",col);
		vector<vector<int>> index_tiles = filein_array("index_tiles.txt", col);
		for (int b = 0; b < row; b++)
		{
			for (int d = 0; d < col; d++)
			{
				cout << index_tiles[b][d] << "  ";
			}
			cout << endl;
		}

		int chosen[Array_num][Array_num];
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				//tiles[i][j] = total_Tiles[index_tiles[i][j]]; //��������5�Ľ��
				if (i == 0 && j == 0)
				{
					tiles[i][j] = total_Tiles[index_tiles[i][j]];
					chosen[i][j] = index_tiles[i][j];
				}
				else if (i == 0 && j != 0)
				{
					int index_ = index_tiles[i][j];
					double mine = tiles[i][j - 1].Right.compare_edge_with(total_Tiles[index_].Left); //
					double min_err = mine;
					//cout << "index_: " << index_ << endl;
					vector<int> final_;
					for (int f_num = 0; f_num <totalsize; f_num++)
					{
						if (total_Tiles[index_].equal_tile(total_Tiles[f_num], AllE))//�ҵ���֮ǰ���Ǹ��߽���ͬ��tile
						{
							//candi_tiles.push_back(f_num);
							double error_ = tiles[i][j-1].Right.compare_edge_with(total_Tiles[f_num].Left);
							if (error_ <= min_err)
							{
								if (min_err - error_ > 0.001)
								{
									final_.swap(vector<int>());
									min_err = error_;
									//min_index = i;
									final_.push_back(f_num);
								}
								else
								{
									final_.push_back(f_num);
								}
							}
						}
					}
					cout << "-----------------------------------------------------------------" << endl << endl;
					if (min_err == mine) //�����ȡ������tile�Ѿ���ƥ�������С�Ŀ飬��������
					{
						tiles[i][j] = total_Tiles[index_];
						chosen[i][j] = index_;
						cout << "mine:" << mine << "  stay the same index: " << index_ << endl;
					}
					else
					{
						int itt = rand() % final_.size();
						tiles[i][j] = total_Tiles[final_[itt]];
						chosen[i][j] = final_[itt];
						cout << "min_err:" << min_err << "  final:  " << final_.size() << "   itt: " << itt << "  final_[itt]: " << final_[itt] << endl;

					}
					cout << "-----------------------------------------------------------------" << endl << endl;
				}
				else if (i != 0 && j == 0)
				{
					int index_ = index_tiles[i][j];
					double mine = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[index_].Top); //
					double min_err = mine;
					vector<int> final_;
					for (int f_num = 0; f_num < total_Tiles.size(); f_num++)
					{
						if (total_Tiles[index_].equal_tile(total_Tiles[f_num], AllE))
						{
							//candi_tiles.push_back(f_num);
							double error_ = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[f_num].Top);
							if (error_ <= min_err)
							{
								if (min_err - error_ > 0.001)
								{
									final_.swap(vector<int>());
									min_err = error_;
									//min_index = i;
									final_.push_back(f_num);
								}
								else
								{
									final_.push_back(f_num);
								}
							}
						}
					}
					cout << "-----------------------------------------------------------------" << endl << endl;
					if (min_err == mine)
					{
						tiles[i][j] = total_Tiles[index_];
						chosen[i][j] = index_;
						cout << "mine:" << mine << "  stay the same index: " << index_ << endl;
					}
					else
					{
						int itt = rand() % final_.size();
						tiles[i][j] = total_Tiles[final_[itt]];
						chosen[i][j] = final_[itt];
						cout << "min_err:" << min_err << "  final:  " << final_.size() << "   itt: " << itt << "  final_[itt]: " << final_[itt] << endl;

					}
					cout << "-----------------------------------------------------------------" << endl << endl;
				}
				else
				{
					int index_ = index_tiles[i][j];
					double mine = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[index_].Top) + tiles[i][j - 1].Right.compare_edge_with(total_Tiles[index_].Left); //
					double min_err = mine;

					vector<int> final_;
					for (int f_num = 0; f_num < total_Tiles.size(); f_num++)
					{
						if (total_Tiles[index_].equal_tile(total_Tiles[f_num], AllE))
						{
							//candi_tiles.push_back(f_num);
							double error_ = tiles[i - 1][j].Bottom.compare_edge_with(total_Tiles[f_num].Top);
							error_ += tiles[i][j - 1].Right.compare_edge_with(total_Tiles[f_num].Left);
							if (error_ <= min_err)
							{
								if (min_err - error_ > 0.001)
								{
									final_.swap(vector<int>());
									min_err = error_;
									//min_index = i;
									final_.push_back(f_num);
								}
								else
								{
									final_.push_back(f_num);
								}
							}
						}
					}
					cout << "-----------------------------------------------------------------" << endl << endl;
					if (min_err == mine)
					{
						tiles[i][j] = total_Tiles[index_];
						chosen[i][j] = index_;
						cout << "mine:" << mine << "  stay the same index: " << index_ << endl;
					}
					else
					{
						int itt = rand() % final_.size();
						tiles[i][j] = total_Tiles[final_[itt]];
						chosen[i][j] = final_[itt];
						cout << "min_err:" << min_err << "  final:  " << final_.size() << "   itt: " << itt << "  final_[itt]: " << final_[itt] << endl;

					}
					cout << "-----------------------------------------------------------------" << endl << endl;					
				}
				//������ݱ߽�ƥ��ɹ�������������
				tiles[i][j].change_position(Point2f(20 + j * (10 + tile_edge_length), 980 - i * (10 + tile_edge_length)));
				tiles[i][j].draw_Tile(show22);
				Point2f shift = Point2f(-9 * j, 9 * i);
				tiles[i][j].draw_tileConts(show222, shift);
			}
		}
		imshow("5*5 tiles matching only content ", show222);
		imwrite("D://result_wt/Only_conten_chosen.jpg", show222);
		imshow("5*5 tiles matching with content ", show22);
		imwrite("D://result_wt/With_conten_chosen.jpg", show22);

		fileout_array("D://result_wt/chosen_tiles.txt", chosen, row, col);
	}
	//-----------------------------9.����patch------------------------------------------------------------------------
	if (choose == 9)
	{
		/*vector<Tile> total_Tiles = tilescheme.com_total_tiles(Color_);
		PatchGenerator pg(2, 2, 3);
		pg.set_sequence(Color_.size());
		pg.set_patch(total_Tiles, Color_);
		pg.draw_patch(Color_, total_Tiles);

		pg.tiling(8, 6);
		pg.draw_result(Color_, total_Tiles, 8, 6);
		cout << endl;
		system("pause");*/
	}
	
	if (choose == 20)
	{
		string floder_path = "C://Users//DELL//Desktop//freeBoundary//freeBoundary//result//";
		//int unit_piexl = 75;
		//Mat tt(unit_piexl * 100 + 100, unit_piexl * 100 + 300, CV_8UC3, Scalar::all(255));
		//color_bar color1;
		//int error_level = 100;
		//vector<Scalar> colorbar = color1.setColorMode(0, error_level);
		//vector<vector<double>> error_t;
		//double min, max;
		////error_t = readError("D://error3.txt", 100,min ,max);
		//error_t = readError(floder_path + "error.txt", 100, min, max);
		//min = 0.0;
		//max = 0.8;
		//double each_e = (max - min) / error_level;

		//cout << max << "  " << min << "  " << each_e << endl;
		//Point offset(0, 0);
		//for (int i = 0; i < 100; i++)
		//{
		//	for (int j = 0; j < 100; j++)
		//	{
		//		int e_level = (error_t[i][j] - min) / each_e;
		//		//cout << error_t[i][j]<<"   "<<e_level << endl;
		//		Point lt = Point(j*unit_piexl, i*unit_piexl) + offset;
		//		draw_error_map(tt, colorbar, lt, e_level, unit_piexl, 1);
		//	}
		//}
		//int num_value = 11; //num �꼸������,num-1�Ǽ����
		//color1.DrawColorBar(tt, Point(unit_piexl * 100 + 60, 2850), Point(unit_piexl * 100 + 120, 50), min, max, num_value);
		//imshow("", tt);
		//imwrite(floder_path + "error_map.png", tt);
		////image_histogram("D:\\lena.jpg",5,1);
		merge_two_maps(floder_path + "divide0_1.png", floder_path + "error_map.png", floder_path + "merge_map.png");
		merge_two_maps(floder_path + "divide0_1.png", floder_path + "tiling_result_0_1.png", floder_path + "merge_map3.png", -20);
	}
	if (choose == 21)
	{
		//cv::Mat image = cv::imread(Input_Path);
		//if (image.empty())
		//{
		//	std::cout << "read image failure" << std::endl;
		//	return -1;
		//}

		//// rgb
		//cv::Mat resultRgb;
		//if (!resultRgb.empty())
		//{
		//	resultRgb.release();
		//}
		//// gray
		//cv::Mat gray;
		//cv::cvtColor(image, gray, CV_BGR2GRAY);
		//cv::imwrite(result_path+ "gray.jpg", gray);
		//std::vector<cv::Mat> rgb;

		//if (gray.channels() == 3)        // rgb image
		//{
		//	cv::split(gray, rgb);
		//}
		//else if (gray.channels() == 1)  // gray image
		//{
		//	rgb.push_back(gray);
		//}

		//// �ֱ��R��G��B����ͨ�����б�Ե��ǿ
		//for (size_t i = 0; i < rgb.size(); i++)
		//{
		//	cv::Mat sharpMat8U;
		//	cv::Mat sharpMat;
		//	cv::Mat blurMat;

		//	// ��˹ƽ��
		//	cv::GaussianBlur(rgb[i], blurMat, cv::Size(3, 3), 0, 0);

		//	// ����������˹
		//	cv::Laplacian(blurMat, sharpMat, CV_16S);

		//	// ת������
		//	sharpMat.convertTo(sharpMat8U, CV_8U);
		//	cv::add(rgb[i], sharpMat8U, rgb[i]);
		//}


		//cv::merge(rgb, resultRgb);

		//cv::imwrite(result_path+ "outRgb.jpg", resultRgb);


		//Mat image = imread(Input_Path, 1);
		//if (image.empty())
		//{
		//	std::cout << "��ͼƬʧ��,����" << std::endl;
		//	return -1;
		//}
		//imshow("ԭͼ��", image);
		//Mat imageEnhance;
		//Mat kernel = (Mat_<float>(3, 3) << 0, -1, 0, 0, 5, 0, 0, -1, 0);
		//filter2D(image, imageEnhance, CV_8UC3, kernel);
		//imshow("������˹����ͼ����ǿЧ��", imageEnhance);
		//std::vector<cv::Mat> rgb;

		//if (imageEnhance.channels() == 3)        // rgb image
		//{
		//	cv::split(imageEnhance, rgb);
		//}
		//else if (imageEnhance.channels() == 1)  // gray image
		//{
		//	rgb.push_back(imageEnhance);
		//}
		//cv::merge(rgb, image);

		//cv::imshow(result_path+ "outRgb.jpg", image);


		Mat src, dst;
		int kernel_size = 3;
		int scale = 1;
		int delta = 0;
		int ddepth = CV_16S;


		src = imread(Input_Path, IMREAD_GRAYSCALE); // Load an image

		// Check if image is loaded fine
		if (src.empty()){
			printf(" Error opening image\n");
			printf(" Program Arguments: [image_name -- default ../data/lena.jpg] \n");
			return -1;
		}

		Mat imageEnhance;
		Mat kernel = (Mat_<float>(3, 3) << 0, 1, 0, 1, -4, 1, 0, 1, 0);
		filter2D(src, imageEnhance, CV_8UC3, kernel);
		imshow("filter2D", imageEnhance);

		//    GaussianBlur( src, src, Size(3, 3), 0, 0, BORDER_DEFAULT );
		//    cvtColor( src, src_gray, COLOR_BGR2GRAY ); // Convert the image to grayscale

		Mat abs_dst;
		Laplacian(src, dst, ddepth, kernel_size, scale, delta, BORDER_DEFAULT);

		// converting back to CV_8U
		convertScaleAbs(dst, abs_dst);

		imshow("Laplace Demo", abs_dst);

		Mat sub;
		cv::subtract(imageEnhance, abs_dst, sub);

		// ����ͼ��������Сֵ
		double pixMin, pixMax;
		cv::minMaxLoc(sub, &pixMin, &pixMax);
		std::cout << "min_a=" << pixMin << " max_b=" << pixMax << std::endl;

	}
	if (choose == 22)
	{
		Multi_Patch MP(3);
		int start_i = 0;
		int start_j = 0;
		vector<double> den;
		for (int i = start_i; i < start_i + 4; i++)
		{
			for (int j = start_j; j < start_j + 4; j++)
			{
				den.push_back(MP.density_d[i][j]);
				cout << MP.density_d[i][j] << endl;
			}
		}
		double err = measure_high_frequency(den);
		cout << "err: " << err << endl;
	}
	finish = clock();
	cout << endl << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
	ofstream outfile(result_num, ios::app);
	outfile << "times: " << (double)(finish - start) / CLOCKS_PER_SEC << endl;
	outfile.close();
	waitKey(0);
	system("pause");
	return 0;
	
}