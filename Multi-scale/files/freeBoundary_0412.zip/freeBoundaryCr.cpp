#define  _CRT_SECURE_NO_WARNINGS
#include "freeBoundary.h"

map<int, int>rotate_pattern_link;

namespace FreeBound{

	//--------------------------CS------------------------------------------
	vector<Scalar> colourScheme::com_fun(double interval)  //--cr
	{
		//double interval = 1.0 / interval_num;
		interval = 1.0 / interval;
		vector<Scalar> colors;
		vector<double> values;
		for (double i = 0.0; i < 1.001; i = i + interval)
		{
			Points.push_back(i);
			double length = pow((i - Mu), 2);
			double k_value = k_max * pow(e, (-length / (2 * pow(Sigma, 2))));
			values.push_back(k_value);
		}
		int max_s = max(max(color.val[0], color.val[1]), color.val[2]);
		int num = values.size();
		//int gray_trunc = truncation*gary_scale;
		//int gray_base = 255 - gray_trunc;
		for (int i = 0; i < num; i++)
		{
			int gray[3];
			for (int j = 0; j < 3; j++)
			{
				int gray_other = (1 - values[i]) * gary_scale;
				if (color.val[j] == max_s) gray[j] = values[i] * color.val[j] + gray_other;
				else gray[j] = gray_other;
			}
			colors.push_back(Scalar(gray[0], gray[1], gray[2]));
		}
		Mat test1 = Mat(300, 300, CV_8UC3, Scalar(255, 255, 255));
		//show_fun(test1, 0, values);
		return colors;
	}

	void colourScheme::show_fun(Mat pic, int it_num, vector<double>values) //�����̬�ֲ�   --cr
	{
		//Mat show1 = Mat(300, 300, CV_8UC3, Scalar(255, 255, 255));
		int num = values.size();
		int offset = 220 * it_num;
		for (int i = 20; i < 220; i = i + 20) //i�Ǻ�����
		{
			circle(pic, Point(i + offset, 210), 2, Scalar(0, 0, 0), -1);
			line(pic, Point(i + offset, 210), Point(i + offset + 20, 210), Scalar(20, 20, 20));
			//circle(drawing5,a,6,Scalar(0,255,0),-1);
		}
		for (int i = 0; i < num - 1; i++)
		{
			Point first = Point(Points[i] * 200 + 20 + offset, 200 - values[i] * 100);
			Point second = Point(Points[i + 1] * 200 + 20 + offset, 200 - values[i + 1] * 100);
			circle(pic, first, 1, Scalar(0, 0, 255), -1);
			//line(show1, first, second, Scalar(20, 120, 20));
		}
		imwrite("GaussFunction.png", pic);
	}

	double colourScheme::f(double x)
	{
		return x / 10;
	}

	//----------multi-pro------------------------------
	void colourScheme::set_P()
	{
		do
		{
			for (int i = 0; i < point_number; i++)
			{
				pro_value[i] = f(rand() % MAXN);
			}
		} while (not_single_Peak());
		int flag = 0;
		for (int i = 0; i < point_number; i++)
		{
			if (pro_value[i] > truncation&&flag == 0)
			{
				flag = 1;
				bd1 = i;
				bd2 = i;
			}
			else if (pro_value[i] > truncation&&flag == 1)
			{
				//flag = 0;
				bd2 = i;
			}
			else
			{
				flag = 0;
			}
		}
	}
	void colourScheme::set_P(vector<double>data)
	{
		for (int i = 0; i < point_number; i++)
		{
			pro_value[i] = data[i];
		}
		int flag = 0;
		for (int i = 0; i < point_number; i++)
		{
			if (pro_value[i] > threshold&&flag == 0)
			{
				flag = 1;
				bd1 = i;
				bd2 = i;
			}
			else if (pro_value[i] > threshold&&flag == 1)
			{
				//flag = 0;
				bd2 = i;
			}
			else
			{
				flag = 0;
			}
		}
	}
	bool colourScheme::not_single_Peak()
	{
		int flag = 0;
		int cnt = 0;
		for (int i = 0; i < point_number; i++)
		{
			if (pro_value[i] > truncation)
			{
				if (flag == 0)
				{
					flag = 1;
					cnt++;
				}
			}
			else if (pro_value[i] <= truncation)
			{
				if (flag == 1)
				{
					flag = 0;
				}
			}
		}
		if (cnt == 1)
			return false;
		else
			return true;
	}
	void colourScheme::draw_edge(Mat &pic, Point2f shift, int flag)
	{
		if (flag == 0)//left
		{
			for (int i = 0; i < point_number; i++)
			{
				Scalar color(255, 0, 0);
				int gray[3];
				for (int j = 0; j < 3; j++)
				{
					int gray_other = (1 - pro_value[i]) * 255;
					if (color.val[j] == 255) gray[j] = pro_value[i] * color.val[j] + gray_other;
					else gray[j] = gray_other;

					color.val[j] = gray[j];
				}

				int thickness = 3;
				int lineType = 8;
				line(pic, shift + Point2f(0, edge_length*1.0 / point_number*i), shift + Point2f(0, edge_length*1.0 / point_number*(i + 1)), color, thickness, lineType);
			}
		}
		else if (flag == 1)//bottom
		{
			for (int i = 0; i < point_number - 1; i++)
			{
				Scalar color(255, 0, 0);
				int gray[3];
				for (int j = 0; j < 3; j++)
				{
					int gray_other = (1 - pro_value[i]) * 255;
					if (color.val[j] == 255) gray[j] = pro_value[i] * color.val[j] + gray_other;
					else gray[j] = gray_other;

					color.val[j] = gray[j];
				}

				int thickness = 3;
				int lineType = 8;
				line(pic, shift + Point2f(edge_length*1.0 / point_number*i, 0), shift + Point2f(edge_length*1.0 / point_number*(i + 1), 0), color, thickness, lineType);
			}
		}
		else if (flag == 2)//right
		{
			for (int i = 0; i < point_number - 1; i++)
			{
				Scalar color(255, 0, 0);
				int gray[3];
				for (int j = 0; j < 3; j++)
				{
					int gray_other = (1 - pro_value[i]) * 255;
					if (color.val[j] == 255) gray[j] = pro_value[i] * color.val[j] + gray_other;
					else gray[j] = gray_other;

					color.val[j] = gray[j];
				}

				int thickness = 3;
				int lineType = 8;
				line(pic, shift + Point2f(0, edge_length*1.0 / point_number*i), shift + Point2f(0, edge_length*1.0 / point_number*(i + 1)), color, thickness, lineType);
			}
		}
		else if (flag == 3)//top
		{
			for (int i = 0; i < point_number - 1; i++)
			{
				Scalar color(255, 0, 0);
				int gray[3];
				for (int j = 0; j < 3; j++)
				{
					int gray_other = (1 - pro_value[i]) * 255;
					if (color.val[j] == 255) gray[j] = pro_value[i] * color.val[j] + gray_other;
					else gray[j] = gray_other;

					color.val[j] = gray[j];
				}

				int thickness = 3;
				int lineType = 8;
				line(pic, shift + Point2f(edge_length*1.0 / point_number*i, 0), shift + Point2f(edge_length*1.0 / point_number*(i + 1), 0), color, thickness, lineType);
			}
		}
	}

	//--------------------------R_Edge------------------------------------------
	void R_Edge::draw_edge(Mat pic, int flag, int d, double ss, double ee)  //--cr
	{
		if (flag == 1)
		{
			if (d == 0)//left
			{
				CS temp = edge_colorScheme;
				vector<Scalar> colors = temp.com_fun(50);
				for (int i = 0; i < colors.size(); i++)
				{
					int thickness = 3;
					int lineType = 8;
					Scalar color = colors[i];
					/*color[0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0]) / 2;
					color[1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1]) / 2;
					color[2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2]) / 2;*/
					line(pic, Point(start.x, start.y + 49 - i), Point(start.x, start.y + 49 - i + 1), color, thickness, lineType);
				}
			}
			else if (d == 3)//bottom��
			{
				CS temp = edge_colorScheme;
				vector<Scalar> colors = temp.com_fun(50);
				for (int i = 0; i < colors.size(); i++)
				{
					int thickness = 3;
					int lineType = 8;
					Scalar color = colors[i];
					/*color[0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0]) / 2;
					color[1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1]) / 2;
					color[2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2]) / 2;*/
					line(pic, Point(ss + i, ee + 50), Point(ss + i + 1, ee + 50), color, thickness, lineType);
				}
			}
			else if (d == 2)//right
			{
				CS temp = edge_colorScheme;
				vector<Scalar> colors = temp.com_fun(50);
				for (int i = 0; i < colors.size(); i++)
				{
					int thickness = 3;
					int lineType = 8;
					Scalar color = colors[i];
					/*color[0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0]) / 2;
					color[1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1]) / 2;
					color[2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2]) / 2;*/
					line(pic, Point(ss + 50, ee + 49 - i), Point(ss + 50, ee + 49 - i + 1), color, thickness, lineType);
				}
			}
			else if (d == 1)//top��
			{
				CS temp = edge_colorScheme;
				vector<Scalar> colors = temp.com_fun(50);
				for (int i = 0; i < colors.size(); i++)
				{
					int thickness = 3;
					int lineType = 8;
					Scalar color = colors[i];
					/*color[0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0]) / 2;
					color[1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1]) / 2;
					color[2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2]) / 2;*/
					line(pic, Point(ss + i, ee), Point(ss + i + 1, ee), color, thickness, lineType);
				}
			}
		}
		else if (flag == 2)//???
		{
			for (int i = 0; i < edge_points.size() - 1; i += 4)
			{
				int thickness = 5;
				int lineType = 8;
				Scalar color = edge_colorScheme.Colors[i];
				color[0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0] + edge_colorScheme.Colors[i + 2][0] + edge_colorScheme.Colors[i + 3][0]) / 4;
				color[1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1] + edge_colorScheme.Colors[i + 2][1] + edge_colorScheme.Colors[i + 3][1]) / 4;
				color[2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2] + edge_colorScheme.Colors[i + 2][2] + edge_colorScheme.Colors[i + 3][2]) / 4;
				line(pic, edge_points[i / 4], edge_points[i / 4 + 1], color, thickness, lineType);
			}
		}
	}


	double R_Edge::compare_edge_scale(R_Edge opposite, int flag, int edge) //�������ߵĲ�ֵ������Ҫע��λ�û�Ҫע����ɫ  --cr
	{
		//ֻ��Ҫ�Ƚ�����edge_colorScheme��洢�ĻҶ�ֵ
		int sizecs = edge_colorScheme.Colors.size();
		if (sizecs != opposite.edge_colorScheme.Colors.size()) cout << "Different size!" << endl;
		double all_dif = 0;
		//ͬ��Ϊ���ߣ��Ͳ���Ҫ����
		vector<Scalar> colors1, colors2;
		colors1 = edge_colorScheme.Colors;
		//colors2 = opposite.edge_colorScheme.Colors;
		if (flag == 0)//4-2
		{
			if (edge < 2)//qianbanbu
			{
				for (int i = 0; i < edge_colorScheme.Colors.size() / 2; i++)
				{
					colors1[i] = edge_colorScheme.Colors[i];
				}
			}
			else//houbanbu
			{
				for (int i = edge_colorScheme.Colors.size() / 2, j = 0; i < edge_colorScheme.Colors.size(); i++, j++)
				{
					colors1[j] = edge_colorScheme.Colors[i];
				}
			}
			CS temp = opposite.edge_colorScheme;
			colors2 = temp.com_fun(50);
			/*for (int i = 0, j = 0; i < opposite.edge_colorScheme.Colors.size()-1; i += 2, j++)
			{
			colors2[j][0] = (opposite.edge_colorScheme.Colors[i][0] + opposite.edge_colorScheme.Colors[i + 1][0]) / 2;
			colors2[j][1] = (opposite.edge_colorScheme.Colors[i][1] + opposite.edge_colorScheme.Colors[i + 1][1]) / 2;
			colors2[j][2] = (opposite.edge_colorScheme.Colors[i][2] + opposite.edge_colorScheme.Colors[i + 1][2]) / 2;
			}*/
			for (int i = 0; i < sizecs / 2; i++)
			{
				all_dif += diff_color(colors1[i], colors2[i]);
			}
		}
		else if (flag == 1)//2-2
		{
			/*for (int i = 0, j = 0; i < edge_colorScheme.Colors.size()-1; i += 2, j++)
			{
			colors1[j][0] = (edge_colorScheme.Colors[i][0] + edge_colorScheme.Colors[i + 1][0]) / 2;
			colors1[j][1] = (edge_colorScheme.Colors[i][1] + edge_colorScheme.Colors[i + 1][1]) / 2;
			colors1[j][2] = (edge_colorScheme.Colors[i][2] + edge_colorScheme.Colors[i + 1][2]) / 2;
			}
			for (int i = 0, j = 0; i < opposite.edge_colorScheme.Colors.size()-1; i += 2, j++)
			{
			colors2[j][0] = (opposite.edge_colorScheme.Colors[i][0] + opposite.edge_colorScheme.Colors[i + 1][0]) / 2;
			colors2[j][1] = (opposite.edge_colorScheme.Colors[i][1] + opposite.edge_colorScheme.Colors[i + 1][1]) / 2;
			colors2[j][2] = (opposite.edge_colorScheme.Colors[i][2] + opposite.edge_colorScheme.Colors[i + 1][2]) / 2;
			}*/
			colors2 = opposite.edge_colorScheme.Colors;
			for (int i = 0; i < sizecs; i++)
			{
				all_dif += diff_color(colors1[i], colors2[i]);
			}
		}
		/*Mat show6 = Mat(300, 1200, CV_8UC3, Scalar(255, 255, 255));
		for (int i = 0; i <100; i += 2)
		{
		int thickness = 3;
		int lineType = 8;
		line(show6, Point(20, 20 + i / 2), Point(20, 20 + i / 2 + 1), colors1[i / 2], thickness, lineType);
		line(show6, Point(40, 20 + i / 2), Point(40, 20 + i / 2 + 1), colors2[i / 2], thickness, lineType);
		line(show6, Point(60, 20 + i), Point(60, 20 + i + 1), edge_colorScheme.Colors[i], thickness, lineType);
		line(show6, Point(80, 20 + i + 1), Point(80, 20 + i + 2), opposite.edge_colorScheme.Colors[i + 1], thickness, lineType);
		}
		imwrite("color.png", show6);*/
		return all_dif;
	}

	//--------------------------R_Edge------------------------------------------

	//--------------------------Tile------------------------------------------
	void Tile::draw_tileEdges(Mat pic, int flag) //--cr : draw_tile()
	{
		Left.draw_edge(pic, flag, 0, Left.start.x, Left.start.y);
		Bottom.draw_edge(pic, flag, 1, Left.start.x, Left.start.y);
		Right.draw_edge(pic, flag, 2, Left.start.x, Left.start.y);
		Top.draw_edge(pic, flag, 3, Left.start.x, Left.start.y);
	}

	vector<int> Tile::match_tile(vector<Tile>& allTiles, double threshold, int d, int flag, int edge, map<int, int> &m) //--cr
	{
		vector<int> chosen;
		int sizeall = allTiles.size();
		double minl = 100000;

		if (d == 0)//top
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Top.compare_edge_scale(allTiles[i].Bottom, flag, edge); //���㵱ǰ�ı��������ıߵĲ�ֵ
				m[i] = error_;
				if (error_ < threshold) chosen.push_back(i);
				minl = min(minl, error_);
			}
		}
		else if (d == 1)//bottom
		{
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Bottom.compare_edge_scale(allTiles[i].Top, flag, edge); //���㵱ǰ�ı��������ıߵĲ�ֵ
				m[i] = error_;
				if (error_ < threshold) chosen.push_back(i);
				minl = min(minl, error_);
			}
		}
		else if (d == 2)//left
		{
			double test = 0;
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Right.compare_edge_scale(allTiles[i].Left, flag, edge); //���㵱ǰ�ı��������ıߵĲ�ֵ
				m[i] = error_;
				if (error_ < threshold) chosen.push_back(i);
				minl = min(minl, error_);
			}
		}
		else if (d == 3)
		{
			double test = 100000;
			for (int i = 0; i < sizeall; i++)
			{
				double error_ = Left.compare_edge_scale(allTiles[i].Right, flag, edge); //���㵱ǰ�ı��������ıߵĲ�ֵ
				m[i] = error_;
				if (i == 0)
					test = error_;
				if (test != error_)
				{
					test = error_;
					//cout << endl;
				}
				if (error_ < threshold) chosen.push_back(i);
				minl = min(minl, error_);
			}
		}

		cout << "chosen num:  " << chosen.size() << endl;
		if (chosen.size() == 0)
			cout << "min :" << minl << endl;
		return chosen;
	}

	int Tile::match_tile_with_constrain(vector<Tile>& allTiles, int & index, int flag, int ww, int ee, int nn, int ss, double sig1, double sig2, double density)
	{
		vector<pair<int, vector<double> > > chosen;
		double min_error = 100000;
		//int min_index = -1;
		int sizeall = allTiles.size();
		//cout << "all_Tile:" << allTiles.size() << endl;
		if (flag == -1)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}

				if (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;
				if (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;

				vector<double>tt;
				tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
				tt.push_back(density);
				chosen.push_back(make_pair(i, tt));
			}
		}
		else if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}

				if (allTiles[i].Left.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Left.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;
				if (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;
				if (ee == -1 && (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1, sig2)))
					continue;

				double error_ = Right.compare_edge_with(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<pair<int, vector<double> > >());
						min_error = error_;
						//min_index = i;
						vector<double>tt;
						tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
						tt.push_back(density);
						chosen.push_back(make_pair(i, tt));
					}
					else
					{
						vector<double>tt;
						tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
						tt.push_back(density);
						chosen.push_back(make_pair(i, tt));
					}
				}
				//if (min_error < 5000) break;
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}

				if (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;
				if (allTiles[i].Bottom.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Bottom.edge_colorScheme.Sigma>max(sig1, sig2))
					continue;
				if (ss == -1 && (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2)))
					continue;

				double error_ = Top.compare_edge_with(allTiles[i].Bottom);
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<pair<int, vector<double> > >());
						min_error = error_;
						//min_index = i;
						vector<double>tt;
						tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
						tt.push_back(density);
						chosen.push_back(make_pair(i, tt));
					}
					else
					{
						vector<double>tt;
						tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
						tt.push_back(density);
						chosen.push_back(make_pair(i, tt));
					}
				}
			}
		}
		//srand((unsigned)time(NULL)+rand());
		sort(chosen.begin(), chosen.end(), cmp_error);
		//int itt = rand() % chosen.size();
		index = chosen[0].first; //ѡ�������С��һ��tile���patch
		if (abs(chosen[0].second[0] - chosen[0].second[1]) > inter_error_threshold) big_error++;
		/*cout << "-----------------------------------------------------------------" << endl << endl;
		cout << "min_error:" << min_error << "   chosen:" << chosen.size() << "   random:" << itt << "   index:" << index << endl << endl;
		cout << "-----------------------------------------------------------------" << endl << endl;*/

		return index;
	}

	vector<int> Tile::match_tile_with_constrain_vector(vector<Tile>& allTiles, int & index, int flag, int ww, int ee, int nn, int ss, double sig1, double sig2)
	{
		vector<int> chosen;
		double min_error = 100000;
		//int min_index = -1;
		int sizeall = allTiles.size();
		cout << "all_Tile:" << allTiles.size() << endl;
		if (flag == -1)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}
				/*
				if (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1,sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1,sig2))
				continue;
				if (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2))
				continue;
				*/
				chosen.push_back(i);
			}
		}
		else if (flag == RightLeft)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}
				/*
				if (allTiles[i].Left.edge_colorScheme.Sigma<min(sig1,sig2) || allTiles[i].Left.edge_colorScheme.Sigma>max(sig1,sig2))
				continue;
				if (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2))
				continue;
				if (ee == -1 && (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1, sig2)))
				continue;
				*/
				double error_ = Right.compare_edge_with(allTiles[i].Left); //���㵱ǰ�ı��������ıߵĲ�ֵ
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<int>());
						min_error = error_;
						//min_index = i;
						chosen.push_back(i);
					}
					else
					{
						chosen.push_back(i);
					}
				}
				//if (min_error < 5000) break;
			}
		}
		else if (flag == BottomTop)
		{
			for (int i = 0; i < sizeall; i++)
			{
				if (ww != -1)
				{
					if (allTiles[i].Left.edge_colorScheme.id != ww)
						continue;
				}
				if (ee != -1)
				{
					if (allTiles[i].Right.edge_colorScheme.id != ee)
						continue;
				}
				if (ss != -1)
				{
					if (allTiles[i].Top.edge_colorScheme.id != ss)
						continue;
				}
				if (nn != -1)
				{
					if (allTiles[i].Bottom.edge_colorScheme.id != nn)
						continue;
				}
				/*
				if (allTiles[i].Right.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Right.edge_colorScheme.Sigma>max(sig1, sig2))
				continue;
				if (allTiles[i].Bottom.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Bottom.edge_colorScheme.Sigma>max(sig1, sig2))
				continue;
				if (ss == -1 && (allTiles[i].Top.edge_colorScheme.Sigma<min(sig1, sig2) || allTiles[i].Top.edge_colorScheme.Sigma>max(sig1, sig2)))
				continue;
				*/
				double error_ = Top.compare_edge_with(allTiles[i].Bottom);
				if (error_ <= min_error)
				{
					if (error_ < min_error)
					{
						chosen.swap(vector<int>());
						min_error = error_;
						//min_index = i;
						chosen.push_back(i);
					}
					else
					{
						chosen.push_back(i);
					}
				}
			}
		}

		return chosen;
	}
	//--------------------------Tile------------------------------------------

	//--------------------------PatchGenerator------------------------------------------


	PatchGenerator::PatchGenerator()
	{
	}

	PatchGenerator::PatchGenerator(int x, int y, int z)
	{
		x_num = x;
		y_num = y;
		size = z;
		patch.clear();
		sq.clear();
		sq_number.clear();
	}

	void PatchGenerator::set_sequence(int number)
	{
		vector<int>a(size);
		add_seq(0, a, number);
		/*for (int i = 0; i < sq.size(); i++)
		{
		for (int j = 0; j < sq[i].size(); j++)
		cout << sq[i][j] << " ";
		cout << endl;
		}*/
	}

	void PatchGenerator::add_seq(int scale, vector<int>& a, int number)
	{
		if (scale == size)
		{
			sq.push_back(a);
			sq_number[a] = sq.size() - 1;
			return;
		}
		for (int i = 0; i < number; i++)
		{
			a[scale] = i;
			add_seq(scale + 1, a, number);
		}
	}

	void PatchGenerator::set_boundary(vector<int> A, vector<CS> Color_, vector<Tile> total_Tiles)
	{
		int scale = size2scale[size] - 1;
		bool dn = discard_nonadjacent;
		bool dr = discard_rotation;
		if (scale == 0)
		{
			dn = false;
			dr = true;
		}
		cout << "Candidate number of each edge: " << A.size() << endl;
		for (int m = 0; m < A.size(); m++)
			cout << A[m] << "   ";
		cout << endl;
		Patch pt1(size, size); //81
		Patch pt2(size, size); //27
		Patch pt3(size, size); //18
		vector<Patch> patch1;
		vector<Patch> patch2;
		vector<Patch> patch3;
		//ȷ����߽�
		for (int i = 0; i < x_num; i++)//ȷ��w
		{
			pt1.wn = A[i];
			pt2.wn = A[i];
			pt3.wn = A[i];
			for (int j = 0; j < y_num; j++)
			{
				pt1.nn = A[j];
				pt2.nn = A[j];
				pt3.nn = A[j];
				for (int k = 0; k < x_num; k++)
				{
					pt1.en = A[k];
					for (int t = 0; t < y_num; t++)
					{
						pt1.sn = A[t];
						pt1.class_id = patch1.size();//��ʼÿ��patch��һ������ת��
						patch1.push_back(pt1);

					}
					pt2.en = A[k];
					pt2.sn = A[rand() % y_num];
					pt2.class_id = patch2.size();//��ʼÿ��patch��һ������ת��
					patch2.push_back(pt2);
				}
				int rand_index = rand() % x_num;
				for (int k = 0; k < 2; k++)
				{
					pt3.en = A[(rand_index + k) % x_num];
					pt3.sn = A[rand() % y_num];
					pt3.class_id = patch3.size();//��ʼÿ��patch��һ������ת��
					patch3.push_back(pt3);
				}
			}
		}
		if (PatchNum == 81) patch = patch1;
		else if (PatchNum == 27) patch = patch2;
		else if (PatchNum == 18) patch = patch3;

		if (SupPatchNum == 81) patch_bound = patch1;
		else if (SupPatchNum == 27) patch_bound = patch2;
		else if (SupPatchNum == 18) patch_bound = patch3;

		Mat show2 = Mat(10500, 3800, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(10500, 3800, CV_8UC3, Scalar(255, 255, 255));
		draw_patch_Edge(0, 0, Color_, total_Tiles, show1, patch);

		//Discard nonadjacent boundaries
		if (dn)
		{
			vector<Patch>temp_patch;
			map<int, int>sq_to_pos;
			for (int i = 0; i < A.size(); i++)
			{
				sq_to_pos[A[i]] = i;
			}
			if (size) //size == 1 || size == 2 || size == 4
			{
				for (int i = 0; i < patch.size(); i++)
				{
					if (is_adjacent(patch[i], sq_to_pos))
					{
						patch[i].class_id = temp_patch.size();
						temp_patch.push_back(patch[i]);
						//cout << patch[i].wn << " " << patch[i].en << " " << patch[i].sn << " " << patch[i].nn << endl;
					}
				}
				//cout << temp_patch.size() << endl;
				patch = temp_patch;
				patch_bound = temp_patch;
			}
			draw_patch_Edge(0, 0, Color_, total_Tiles, show2, patch);
			//imwrite("before_patch.png", show1);
			//imwrite("after_patch.png", show2);
		}

		//Discard rotate tile!!!only for 1*1 tiles
		if (dr)
		{
			set<string> ops;
			vector<Patch> patch_temp;
			for (int i = 0; i < patch.size(); i++)
			{
				Patch pt = patch[i];
				//string s1 = "", s2 = "", s3 = "", s4 = "";
				string bb = to_string(pt.nn);
				string rr = to_string(pt.en); 
				string tt = to_string(pt.sn); 
				string ll = to_string(pt.wn); 

				string s1 = bb + rr + tt + ll;
				string s2 = ll + bb + rr + tt;
				string s3 = tt + ll + bb + rr;
				string s4 = rr + tt + ll + bb;
				//cout << "s1: " << s1 << endl;
				if (ops.count(s1) != 0)
					continue;
				if (ops.count(s2) != 0)
					continue;
				if (ops.count(s3) != 0)
					continue;
				if (ops.count(s4) != 0)
					continue;
				ops.insert(s1);
				patch_temp.push_back(patch[i]);
			}
			sort(patch_temp, cmp_patch_boundary);
			patch = patch_temp;
			patch_bound = patch_temp;
		}
	}

	void PatchGenerator::set_patch(vector<Tile> total_Tiles, vector<CS> Color_)
	{
		cout << "Generate" << size << "*" << size << " patches !" << endl;
		//srand((unsigned)time(NULL));
		Patch pt1, pt2;
		//ȷ����߽�
		//for (int i = 0; i < x_num; i++)//ȷ��w
		//{
		//	pt1.wn = i;
		//	pt2.wn = i;
		//	for (int j = 0; j < y_num; j++)
		//	{
		//		pt1.nn = j;
		//		pt2.nn = j;

		//		pt1.en = rand() % x_num;
		//		pt1.sn = rand() % y_num;
		//		patch.push_back(pt1);
		//		while (1)
		//		{
		//			pt2.en = rand() % x_num;
		//			pt2.sn = rand() % y_num;
		//			if (pt1.en != pt2.en || pt1.sn != pt2.sn)
		//			{
		//				patch.push_back(pt2);
		//				break;
		//			}
		//		}
		//	}
		//}

		//�̶�ѡ��
		int A[20];
		set_A(A, Color_);
		int xx_num = 7;
		int yy_num = 1;
		for (int i = 0; i < xx_num - 1; i++)//ȷ��w
		{
			pt1.wn = A[i];
			pt2.wn = A[i];
			for (int j = 0; j < yy_num; j++)
			{
				pt1.nn = A[i / 2 * 2];
				pt2.nn = A[i / 2 * 2];

				pt1.en = A[(i + 1) % xx_num];
				pt1.sn = A[i / 2 * 2];
				patch.push_back(pt1);
				while (1)
				{
					pt2.en = A[(i + 1) % xx_num];
					pt2.sn = A[i / 2 * 2];
					if (/*pt1.en != pt2.en || pt1.sn != pt2.sn*/1)
					{
						patch.push_back(pt2);
						break;
					}
				}
			}
		}
		//for (int i = xx_num-1; i > 0; i--)//ȷ��w
		//{
		//	pt1.wn = A[i];
		//	pt2.wn = A[i];
		//	for (int j = 0; j < yy_num; j++)
		//	{
		//		pt1.nn = A[i / 2 * 2];
		//		pt2.nn = A[i / 2 * 2];
		//		pt1.en = A[(i - 1) % xx_num];
		//		pt1.sn = A[i / 2 * 2];
		//		patch.push_back(pt1);
		//		while (1)
		//		{
		//			pt2.en = A[(i - 1) % xx_num];
		//			pt2.sn = A[i / 2 * 2];
		//			if (/*pt1.en != pt2.en || pt1.sn != pt2.sn*/1)
		//			{
		//				patch.push_back(pt2);
		//				break;
		//			}
		//		}
		//	}
		//}
		//ȷ��ÿ��tile
		for (int k = 0; k < patch.size(); k++)
		{
			pt1 = patch[k];
			cout << "patch" << k << endl;
			//internal_tiling(pt1, total_Tiles, Color_[sq[pt1.wn][0]].Sigma, Color_[sq[pt1.en][1]].Sigma);
			/*pt1.wg[0][0] = 4;
			pt1.wg[0][1] = 56;
			pt1.wg[0][2] = 1352;
			pt1.wg[1][0] = 144;
			pt1.wg[1][1] = 619;
			pt1.wg[1][2] = 390;
			pt1.wg[2][0] = 189;
			pt1.wg[2][1] = 190;
			pt1.wg[2][2] = 71;*/
			//cout << "connnect number:" << Single_connnect_num(pt1, total_Tiles) << endl;
			if (Single_connnect_num(pt1, total_Tiles) > 1)
				k--;
			else
				patch[k] = pt1;
		}
	}

	void PatchGenerator::set_patch(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density)
	{
		cout << "Generate " << size << "*" << size<<" patches !" << endl;
		vector<Patch> new_patch;
		vector<int> used_density(sort_density.size(), 0);
		Patch pt1, pt2;
		//ȷ����߽�
		for (int i = 0; i < x_num; i++)//ȷ��w
		{
			pt1.wn = A[i];
			pt2.wn = A[i];
			for (int j = 0; j < y_num; j++)
			{
				pt1.nn = A[j];
				pt2.nn = A[j];

				if (i == 0 && j == 0 || i == x_num - 1 && j == y_num - 1)
				{
					pt1.en = A[rand() % x_num];
					pt1.sn = A[rand() % y_num];
					/*pt1.en = A[rand() % 2 > 0 ? i : j];
					pt1.sn = A[rand() % 2 > 0 ? i : j];*/
					patch.push_back(pt1);
					while (1)
					{
						pt2.en = A[rand() % x_num];
						pt2.sn = A[rand() % y_num];
						/*pt2.en = A[rand() % 2 > 0 ? i : j];
						pt2.sn = A[rand() % 2 > 0 ? i : j];*/
						if (1/*pt1.en != pt2.en || pt1.sn != pt2.sn*/)
						{
							patch.push_back(pt2);
							break;
						}
					}
				}
				else
				{
					for (int k1 = 0; k1 < x_num; k1++)
					{
						pt1.en = A[k1];
						pt1.sn = A[rand() % y_num];
						patch.push_back(pt1);
					}
				}
			}
		}
		vector<Patch> patch_class;
		//ȷ��ÿ��tile
		for (int k = 0; k < patch.size(); k++)
		{
			patch_class.clear();
			pt1 = patch[k];
			if (pt1.used_time != 0)
				continue;
			cout << "Determine interior of patch " << k<<endl;
			/*if (k == 0 || k == patch.size() - 1)
			internal_tiling(pt1, total_Tiles, Color_[sq[pt1.wn][0]].Sigma, Color_[sq[pt1.en][1]].Sigma, sort_density);
			else*/
			int minpos = internal_tiling(pt1, total_Tiles, 0, 1, sort_density);
			used_density[minpos]++;
			//internal_tiling_class(0, patch_class, pt1, total_Tiles, 0, 1);
			pt1.density = pt1.density / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
			//cout << " with connnect number:" << Single_connnect_num(pt1, total_Tiles) << endl;
			/*if (Single_connnect_num(pt1, total_Tiles) > 1)
			k--;
			else
			patch[k] = pt1;*/

			int pf = 1;
			if (pf == 0)
				k--;
			else
				patch[k] = pt1;
			//����
			/*int pos_min = -1, pos_max = -1;
			double min_d = 10, max_d = -1;
			int density_td[15];
			memset(density_td, 0, sizeof(density_td));
			for (int kk = 0; kk < patch_class.size(); kk++)
			{
			patch_class[kk].density /= (size*size * 75 * 75);
			if (patch_class[kk].density < min_d)
			{
			min_d = patch_class[kk].density;
			pos_min = kk;
			}
			if (patch_class[kk].density > max_d)
			{
			max_d = patch_class[kk].density;
			pos_max = kk;
			}
			int pp = patch_class[kk].density * 10;
			if (pp >= 0 && pp <= 10)
			density_td[pp]++;
			else
			cout << "error density" << pp << endl;
			}
			new_patch.push_back(patch_class[pos_min]);
			new_patch.push_back(patch_class[pos_max]);
			for (int i = 0; i < 10; i++)
			{
			cout << density_td[i] << " ";
			}
			cout << endl;*/
		}
		int num_zero = 0;
		for (int g = 0; g < used_density.size(); g++)
		{
			cout << used_density[g] << "   ";
			if (used_density[g] == 0) num_zero++;
		}
		cout << "total num: " << used_density.size() << "    num_zero: " << num_zero << endl;
		//patch = new_patch;
	}

	void PatchGenerator::set_patch_spec_11(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density)
	{
		cout << "Specifically Generate " << size << "*" << size << " patches !" << endl;
		vector<Patch> new_patch;
		vector<int> used_density(sort_density.size(), 0);
		cout << "used_density.size(): " << used_density.size() << endl;
		cout << "sort_density.size(): " << sort_density.size() << endl;
		vector<int> used_patch(patch.size(), 0);

		//generate every patch
		vector<vector<double>> error_map(patch.size(), vector<double>(patch.size(), 0));
		vector<Patch> patch_temp = patch;
		vector<Patch> patch_final;
		int num_density = 8; // num_density�仯, den_assign����ĿҲ��Ҫ�仯
		//int den_assign[8] = { 3, 3, 3, 3, 3, 3, 3, 3 }; //den_assign ����, step��ֵҲ����
		int den_assign[12] = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 }; //den_assign ����, step��ֵҲ����
		map<int, int>step;
		vector<vector<int> > rec_patterns(patch.size(), vector<int>(sort_density.size(), -1));
		vector<int> rec_pattern(patch.size(), -1);
		for (int i = 0; i < patch.size(); i++)
		{
			vector<int> difpattern;
			find_sameBoun_tile(patch[i], difpattern, total_Tiles);
			//record every density's minmimal error 
			vector<int> den_min_pattern = define_tilePattern(difpattern, sort_density, total_Tiles);
			rec_patterns[i] = den_min_pattern;
			/*for (int j = 0; j < den_min_pattern.size(); j++)
			cout << den_min_pattern[j] << " ";
			cout << endl;*/
			int posa = 0;
			for (int j = 0; j < num_density; j++)
			{
				double error = abs(total_Tiles[den_min_pattern[j]].black_pic*1.0 / (tile_edge_length*tile_edge_length) - sort_density[j].first[0]);
				int mul = 0;
				while (mul < den_assign[j])
				{
					if (mul > 0)
						error_map[i][posa + mul] = error_map[i][posa];
					else
						error_map[i][posa + mul] = error;
					step[posa + mul] = j;
					mul++;
				}
				posa += den_assign[j];
			}
		}
		/*for (int i = 0; i < rec_patterns.size(); i++)
		{
		for (int j = 0; j < rec_patterns[i].size(); j++)
		{
		cout << rec_patterns[i][j] << " ";
		}
		cout << endl;
		}*/
		vector<int> bound_den = stable_matching(error_map);
		for (int i = 0; i < bound_den.size(); i++)
			cout << bound_den[i] << endl;
		cout << endl;
		for (int i = 0; i < patch.size(); i++)
		{
			cout << rec_patterns[i][step[bound_den[i]]] << endl;
			patch[i].wg[0][0] = rec_patterns[i][step[bound_den[i]]];
			patch[i].class_id = i;
			patch[i].density = total_Tiles[rec_patterns[i][step[bound_den[i]]]].black_pic*1.0 / (tile_edge_length*tile_edge_length);
		}
		total_classes_num = patch.size();
	}
	void PatchGenerator::find_sameBoun_tile(Patch pt, vector<int> &difpattern, vector<Tile> total_Tiles)
	{
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			Tile tt = total_Tiles[i];
			if (tt.Bottom.id == pt.nn&&tt.Left.id == pt.wn&&tt.Right.id == pt.en&&tt.Top.id == pt.sn)
				difpattern.push_back(i);
		}
	}
	vector<int> PatchGenerator::define_tilePattern(vector<int> difpattern, vector<PAIR> sort_density, vector<Tile> total_Tiles)
	{
		vector<int> ans;
		for (int i = 0; i < sort_density.size(); i++)
		{
			int pos = -1;
			double error = 10;
			//cout << sort_density[i].first[0] << endl;
			for (int j = 0; j < difpattern.size(); j++)
			{
				//cout << total_Tiles[difpattern[j]].black_pic*1.0 / (tile_edge_length*tile_edge_length) << endl;
				double error_t = abs(total_Tiles[difpattern[j]].black_pic*1.0 / (tile_edge_length*tile_edge_length) - sort_density[i].first[0]);
				//cout << error_t << endl;
				if (error_t < error)
				{
					error = error_t;
					pos = j;
				}
			}
			//cout << endl;
			ans.push_back(difpattern[pos]);
		}
		return ans;
	}
	void PatchGenerator::set_patch_spec(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density)
	{
		int patch_density = patch_gen_type; //0: 1 v random 1  1: 1 v all   2: lcr--density first
		//if (size != 4) patch_density = 4;
		cout << "Specifically Generate " << size << "*" << size << " patches !" << endl;
		vector<Patch> new_patch;
		vector<int> used_density(sort_density.size(), 0);
		cout << "used_density.size(): " << used_density.size() << endl;
		cout << "sort_density.size(): " << sort_density.size() << endl;

		vector<int> used_patch(patch.size(), 0);
		//ȷ��ÿ��tile
		if(patch_density == 0)
		{
			int max_den_num = patch.size() / sort_density.size() + (patch.size() % sort_density.size() == 0 ? 0 : 1) + 1;
			int computed_num = 0;
			for (int k = 0; k < max_den_num*sort_density.size(); k++)
			{
				int kk = k%sort_density.size();
				vector<double> den1 = sort_density[kk].first;
				cout << "Determine interior with density " << kk << endl;
				/*if (k == 0 || k == patch.size() - 1)
				internal_tiling(pt1, total_Tiles, Color_[sq[pt1.wn][0]].Sigma, Color_[sq[pt1.en][1]].Sigma, sort_density);
				else*/

				int minpos = internal_with_density(total_Tiles, 0, 1, den1, used_patch);
				//int minpos = internal_with_density(total_Tiles, 0, 1, den1, used_patch, Color_);
				if (minpos == -1)
					continue;
				cout << "minpos: " << minpos << endl;
				used_patch[minpos]++;
				used_density[kk]++;
				computed_num++;
				if (computed_num >= patch.size()) break;
			}

			int num_zero = 0;
			cout << "used_patch.size(): " << used_patch.size() << endl;
			vector<Patch>temp_patch;
			for (int g = 0; g < used_patch.size(); g++)
			{
				cout << used_patch[g] << "   ";
				if (used_patch[g] == 0) num_zero++;
				else
				{
					patch[g].class_id = temp_patch.size();
					temp_patch.push_back(patch[g]);
					//cout << patch[i].wn << " " << patch[i].en << " " << patch[i].sn << " " << patch[i].nn << endl;
					//cout << temp_patch.size() << endl;
				}
			}
			patch = temp_patch;
			total_classes_num = patch.size();
			cout << "total num: " << total_classes_num << "    num_zero: " << num_zero << endl;

			cout << "used_density.size(): " << used_density.size() << endl;
			for (int g = 0; g < used_density.size(); g++)
			{
				cout << used_density[g] << "   ";
			}
		}
		else if (patch_density == 1)
		{
			vector<Patch> patch_tem;
			for (int k = 0; k < sort_density.size(); k++)
			{
				vector<double> den1 = sort_density[k].first; 
				cout << "Determine interior with density " << k << endl;
				for (int kk = 0; kk < patch.size(); kk++)
				{
					Patch pt = patch[kk];
					pt.class_id = k*patch.size() + kk;
					double patch_e = 0;
					int num_bigerror = matched_degree_p_d(pt, total_Tiles, 0, 1, den1, patch_e);
					patch_tem.push_back(pt);
					patch_error.push_back(make_pair(k, patch_e));
					used_patch[kk]++;
					used_density[k]++;
					/*if (k == 0 || k == 108)
					{
						cout << endl<<kk << " patch has gen_e: " << patch_e << endl;
						for (int m = 0; m < size; m++)
							for (int n = 0; n < size; n++)
								cout << total_Tiles[pt.wg[m][n]].black_pic / pow(tile_edge_length, 2) << " ";
						if (num_bigerror != 0) cout << patch_tem.size() - 1 << " ILLEGAL PATCH WITH " << num_bigerror << " BIG_ERROR TILES! ";
					}*/					
				}
			}
			patch = patch_tem;
			int num_zero = 0;
			cout << "used_patch.size(): " << used_patch.size() << endl;
			for (int g = 0; g < used_patch.size(); g++)
			{
				cout << used_patch[g] << "   ";
				if (used_patch[g] == 0) num_zero++;
			}
			total_classes_num = patch.size();
			cout << endl<< "total num: " << total_classes_num << "    num_zero: " << num_zero << endl;

			cout << "used_density.size(): " << used_density.size() << endl;
			for (int g = 0; g < used_density.size(); g++)
			{
				cout << used_density[g] << "   ";
			}
			cout << endl << endl;
		}
		else if (patch_density == 2)    //--lcr: density first patch generation
		{
			//ǰ��8��
			vector<vector<double>> error_map(patch.size(), vector<double>(patch.size(), 0));
			vector<Patch> patch_temp = patch;
			vector<Patch> patch_final;
			int num_density = 8; // num_density�仯, den_assign����ĿҲ��Ҫ�仯
			int den_assign[8] = { 3, 3, 4, 4, 5, 4, 4, 4 }; //den_assign ����, step��ֵҲ����
			map<int, int>step;
			vector<double> weights = { 0.1, 0, 0.9 };
			if (size == 2) weights = { 1, 0, 0 };
			cout << size << "  " << weights[0] << "  " << weights[1] << "  " << weights[2] << endl;
			for (int i = 0; i < patch.size(); i++)
			{
				Patch pt = patch[i];
				int posa = 0;
				vector<Patch>patch_show;
				for (int j = 0; j < num_density; j++)
				{
					double error = 0;
					vector<double> image_density;
					matched_degree_density_first(pt, total_Tiles, 0, 1, sort_density[j].first, error, Color_, image_density);
					patch_show.push_back(pt);
					//cout << error << " ";
					int mul = 0;
					while (mul < den_assign[j])
					{
						//error_map[i][posa + mul] = error / (size*size);
						if (mul > 0)
							error_map[i][posa + mul] = error_map[i][posa];
						else
							error_map[i][posa + mul] = match_error(sort_density[j].first, image_density, weights[0], weights[1], weights[2]);
						step[posa + mul] = j;
						mul++;
					}
					posa += den_assign[j];
				}
				string name = "patch_front";
				name += ('0' + patch[i].wn / 30);
				name += ('0' + patch[i].nn / 30);
				name += ('0' + patch[i].en / 30);
				name += ('0' + patch[i].sn / 30);

				//show_patch(patch_show, Color_, total_Tiles, name);
				//cout << endl;
			}
			for (int i = 0; i < error_map.size(); i++)
			{
				for (int j = 0; j < error_map[i].size(); j++)
					cout << error_map[i][j] << " ";
				cout << endl;
			}
			vector<int> bound_den = stable_matching(error_map);

			for (int i = 0; i < patch.size(); i++)
			{
				double error = 0;
				matched_degree_density_first(patch[i], total_Tiles, 0, 1, sort_density[step[bound_den[i]]].first, error, Color_);
				patch[i].class_id = patch_final.size();
				patch_final.push_back(patch[i]);
			}
			cout << "The last eight densities..." << endl;
			//����8��
			if (num_density == (sort_density.size() - num_density))
			{
				patch = patch_temp;
				error_map.swap(vector<vector<double>>(patch.size(), vector<double>(patch.size(), 0)));
				
				for (int i = 0; i < patch.size(); i++)
				{
					Patch pt = patch[i];
					int posa = 0;
					vector<Patch>patch_show;
					for (int j = num_density; j < sort_density.size(); j++)
					{
						double error = 0;
						vector<double> image_density;
						matched_degree_density_first(pt, total_Tiles, 0, 1, sort_density[j].first, error, Color_, image_density);

						patch_show.push_back(pt);
						//cout << error << " ";

						int mul = 0;
						while (mul < den_assign[j - num_density])
						{
							//error_map[i][posa + mul] = error / (size*size);
							if (mul > 0)
								error_map[i][posa + mul] = error_map[i][posa];
							else
								error_map[i][posa + mul] = match_error(sort_density[j].first, image_density, weights[0], weights[1], weights[2]);
							step[posa + mul] = j;
							mul++;
						}
						posa += den_assign[j - num_density];
					}
					string name = "patch";
					name += ('0' + patch[i].wn / 30);
					name += ('0' + patch[i].nn / 30);
					name += ('0' + patch[i].en / 30);
					name += ('0' + patch[i].sn / 30);

					//show_patch(patch_show, Color_, total_Tiles, name);
					//cout << endl;
				}
				/*for (int i = 0; i < error_map.size(); i++)
				{
					for (int j = 0; j < error_map[i].size(); j++)
						cout << error_map[i][j] << " ";
					cout << endl;
				}*/
				bound_den = stable_matching(error_map);

				for (int i = 0; i < patch.size(); i++)
				{
					double error = 0;
					matched_degree_density_first(patch[i], total_Tiles, 0, 1, sort_density[step[bound_den[i]]].first, error, Color_);
					patch[i].class_id = patch_final.size();
					patch_final.push_back(patch[i]);
				}

			}
			else cout << "sort_density size < 16!" << endl;
			
			patch = patch_final;
			total_classes_num = patch.size();
			cout << "total num: " << total_classes_num << endl;
		}
		else if (patch_density == 3)  //stable matching + iterative + random search
		{
			//24�ֱ߽磬16���ܶ�
			//ǰ��8��
			bool using_km = true;
			vector<vector<double>> error_map(patch.size(), vector<double>(patch.size(), 0));
			vector<Patch> patch_temp = patch;
			vector<Patch> patch_final;
			vector<vector<Patch>> all_patches;
			int num_density = 8; // num_density�仯, den_assign����ĿҲ��Ҫ�仯
			int den_assign[8] = { 2, 2, 2, 4, 4, 4, 3, 3 }; //den_assign ����, step��ֵҲ����
			//int den_assign[8] = { 3, 3, 3, 3, 3, 3, 3, 3 }; //den_assign ����, step��ֵҲ����

			map<int, int>step;
			vector<double> weights = { 0.1, 0, 0.9 };
			if (size == 2) weights = { 1, 0, 0 };
			cout << size << "  " << weights[0] << "  " << weights[1] << "  " << weights[2] << endl;
			for (int i = 0; i < patch.size(); i++)
			{
				Patch pt = patch[i];
				int posa = 0;
				vector<Patch> patch_den;
				vector<double> patch_e;
				for (int j = 0; j < num_density; j++)
				{			
					for (int to_ = 0; to_ < 5; to_++)
						thres_over[to_] = 0;
					vector<double> image_density;
					double min_error = 1000;
					Patch pt_min;
					//int min_degree = 0;
					cout << "patch: "<<i << "  " << j << endl;
					for (int iter_ = 0; iter_ < 4; iter_++)
					{
						double error = 0;
						Patch pt_temp = rotate_patch_boundary(pt, iter_ * 90);
						int illegal_num = match_iter_random(pt_temp, total_Tiles, 0, 1, sort_density[j].first, error, Color_, image_density);
						//patch_den.push_back(pt_temp);
						//patch_e.push_back(error);
						if (error < min_error)
						{
							min_error = error;
							pt_min = pt_temp;
							//min_degree = iter_ * 90;
						}
					}
					//cout << "thres over num: " << thres_over[0] << "  " << thres_over[1] << "  " << thres_over[2] << endl;
					double adjust_w = pow(abs(i / 3 - j) / 7.0, 2) + 1; //abs(i - 3 * j) / 23.0 + 1;//pow(abs(i / 3 - j) / 7.0, 2) + 1;//
					min_error = adjust_w*min_error;
					patch_den.push_back(pt_min);
					patch_e.push_back(min_error);
					//cout << error << " ";
					int mul = 0;
					while (mul < den_assign[j])
					{
						//error_map[i][posa + mul] = error / (size*size);
						if (mul > 0)
							error_map[i][posa + mul] = error_map[i][posa];
						else
							error_map[i][posa + mul] = min_error;// match_error(sort_density[j].first, image_density, weights[0], weights[1], weights[2]);
						step[posa + mul] = j;
						mul++;
					}
					posa += den_assign[j];
				}
				all_patches.push_back(patch_den);
				string name = "patch_front";
				name += ('0' + patch[i].wn / 30);
				name += ('0' + patch[i].nn / 30);
				name += ('0' + patch[i].en / 30);
				name += ('0' + patch[i].sn / 30);

				show_patch(patch_den, patch_e, Color_, total_Tiles, name);
				//cout << endl;
			}
			/*for (int i = 0; i < error_map.size(); i++)
			{
			for (int j = 0; j < error_map[i].size(); j++)
			cout << error_map[i][j] << " ";
			cout << endl;
			}*/
			cout <<"all_patches: "<< all_patches.size() << endl;

			vector<int> bound_den;
			if (using_km)
			{
				//KM 
				KM km_e(error_map, false);
				km_e.km();
				for (int g = 1; g <= km_e.n; g++) //km�ж��Ǵ�1��ʼ
				{
					bound_den.push_back(km_e.link[g] - 1);
					cout << g << "  " << km_e.link[g] << endl;
				}
			}
			else
			{
				// stable matching
				bound_den = stable_matching(error_map);
			}
					
			//���ݼ�¼����patch, �����滻
			for (int i = 0; i < patch.size(); i++)
			{
				//matched_degree_density_first(patch[i], total_Tiles, 0, 1, sort_density[step[bound_den[i]]].first, error, Color_);
				cout << "all i: " << all_patches[i].size() << " bound_den i: " << bound_den[i] << endl;
				patch[i] = all_patches[i][step[bound_den[i]]];
				patch[i].class_id = patch_final.size();
				patch_final.push_back(patch[i]);
			}
			cout << "patch_final size: " << patch_final.size() << endl;

			//����8��
			if (num_density == (sort_density.size() - num_density))
			{
				int den_assign2[8] = { 3, 3, 3, 3, 3, 3, 3, 3 }; //den_assign ����, step��ֵҲ����
				//int den_assign2[8] = { 2, 2, 2, 4, 4, 4, 3, 3 }; //den_assign ����, step��ֵҲ����
				patch = patch_temp;
				error_map.swap(vector<vector<double>>(patch.size(), vector<double>(patch.size(), 0)));
				all_patches.swap(vector<vector<Patch>>());
				for (int i = 0; i < patch.size(); i++)
				{
					Patch pt = patch[i];
					int posa = 0;
					vector<Patch> patch_den;
					vector<double> patch_e;
					for (int j = num_density; j < sort_density.size(); j++)
					{
						vector<double> image_density;
						double min_error = 1000;
						Patch pt_min;
						//int min_degree = 0;
						for (int iter_ = 0; iter_ < 4; iter_++)
						{
							double error = 0;
							Patch pt_temp = rotate_patch_boundary(pt, iter_ * 90);
							int illegal_num = match_iter_random(pt_temp, total_Tiles, 0, 1, sort_density[j].first, error, Color_, image_density);
							//patch_den.push_back(pt_temp);
							//patch_e.push_back(error);
							if (error < min_error)
							{
								min_error = error;
								pt_min = pt_temp;
								//min_degree = iter_ * 90;
							}
						}
						//double adjust_w = abs(i - 3 * j + 24) / 23.0 + 1;//pow(abs(i / 3 - j) / 7.0, 2) + 1;//
						//min_error = adjust_w*min_error;
						patch_den.push_back(pt_min);
						patch_e.push_back(min_error);

						int mul = 0;
						while (mul < den_assign2[j - num_density])
						{
							//error_map[i][posa + mul] = error / (size*size);
							if (mul > 0)
								error_map[i][posa + mul] = error_map[i][posa];
							else
								error_map[i][posa + mul] = min_error;// match_error(sort_density[j].first, image_density, weights[0], weights[1], weights[2]);
							step[posa + mul] = j;
							mul++;
						}
						posa += den_assign2[j - num_density];
					}
					all_patches.push_back(patch_den);
					string name = "patch";
					name += ('0' + patch[i].wn / 30);
					name += ('0' + patch[i].nn / 30);
					name += ('0' + patch[i].en / 30);
					name += ('0' + patch[i].sn / 30);

					show_patch(patch_den, patch_e, Color_, total_Tiles, name);
					//cout << endl;
				}
				/*for (int i = 0; i < error_map.size(); i++)
				{
				for (int j = 0; j < error_map[i].size(); j++)
				cout << error_map[i][j] << " ";
				cout << endl;
				}*/
				cout << "all_patches: " << all_patches.size() << endl;

				bound_den.swap(vector<int>());
				if (using_km)
				{
					//KM 
					KM km_e2(error_map, false);
					km_e2.km();
					for (int g = 1; g <= km_e2.n; g++) //km�ж��Ǵ�1��ʼ
					{
						bound_den.push_back(km_e2.link[g] - 1);
						cout << g << "  " << km_e2.link[g] << endl;
					}
				}
				else
				{   //stable matching
					bound_den = stable_matching(error_map);
				}
				for (int i = 0; i < patch.size(); i++)
				{
					//matched_degree_density_first(patch[i], total_Tiles, 0, 1, sort_density[step[bound_den[i]]].first, error, Color_);
					//cout << "all i: " << all_patches[i].size() << " bound_den i: " << bound_den[i] << "   step[bound_den[i]]: " << step[bound_den[i]]<<endl;
					patch[i] = all_patches[i][step[bound_den[i]] - num_density];
					patch[i].class_id = patch_final.size();
					patch_final.push_back(patch[i]);
				}
				cout << "patch_final size: " << patch_final.size() << endl;

			}
			else cout << "sort_density size < 16!" << endl;

			patch = patch_final;
			total_classes_num = patch.size();
			cout << "total num: " << total_classes_num << endl;
		}

		//patch = new_patch;
	}

	vector<pair<Patch, int>> PatchGenerator::set_unused_patch(vector<Tile> total_Tiles, vector<CS> Color_, vector<PAIR> sort_density)
	{
		int set_type = new_patch_gen_type; //0: ���1��1���, 1: 1��all  2: 18 types 1 vs all
		Patch pt1;
		Patch pt2;
		int begin_pos = patch.size();//��ʼclass ID
		//cout << "sort_density.size:  " << sort_density.size() << endl;
		vector<pair<Patch, int>> sup_patch;
		if (set_type == 0)  //���1��1���ֱ����֮ǰ��patch�������, ���ؿյ�sup_patch
		{
			//ȷ��ÿ��tile
			for (int k = 0; k < patch.size(); k++)
			{
				pt1 = patch[k];
				if (pt1.used_time != 0)
					continue;
				cout << "patch " << k << " is not used!" << endl;
				/*if (k == 0 || k == patch.size() - 1)
				internal_tiling(pt1, total_Tiles, Color_[sq[pt1.wn][0]].Sigma, Color_[sq[pt1.en][1]].Sigma, sort_density);
				else*/
				internal_tiling(pt1, total_Tiles, 0, 1, sort_density);
				//internal_tiling_class(0, patch_class, pt1, total_Tiles, 0, 1);
				//pt1.density = pt1.density / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
				//cout << "Regenerate patch has connnect number:" << Single_connnect_num(pt1, total_Tiles) << endl;
				/*if (Single_connnect_num(pt1, total_Tiles) > 1)
				k--;
				else
				patch[k] = pt1;*/

				int pf = 1;
				if (pf == 0)
					k--;
				else
					patch[k] = pt1;

				//add rotate patch
				Patch pt = pt1;
				for (int i = 0; i < 3; i++)
				{
					pt = add_rotate_patch(pt, i);
					patch.push_back(pt);
				}
			}
		}
		else if (set_type == 1) //1��all�������ɵ�patch���ӵ�sup_patch�ﲢ����
		{
			for(int k = 0; k < patch.size(); k++)
			{
				pt1 = patch[k];
				if (pt1.used_time != 0)
					continue;
				cout << "patch " << k << " is not used!" << endl;
				cout << "density size " << sort_density.size()<< endl;
				for (int t = 0; t < sort_density.size(); t++)
				{
					Patch pt = pt1;
					vector<double> density_in = sort_density[t].first;
					double patch_e = 0;
					int num_bigerror = matched_degree_p_d(pt, total_Tiles, 0, 1, density_in, patch_e);
					//pt.density = pt.density / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
					int final_pos = begin_pos + k*sort_density.size() + t;
					while (class_id_set.count(final_pos) != 0)
					{
						final_pos++;
					}
					class_id_set.insert(final_pos);
					pt.class_id = final_pos;
					sup_patch.push_back(make_pair(pt, k));

					//add rotate patch
					Patch ptt = sup_patch[sup_patch.size() - 1].first;
					for (int i = 0; i < 3; i++)
					{
						ptt = add_rotate_patch(ptt, 0);
						ptt.class_id = final_pos;
						sup_patch.push_back(make_pair(ptt, k));
					}
				}
			}
			cout << "Generate " << sup_patch.size() << " new patches!" << endl;
		}
		else if (set_type == 2) //1��all�������ɵ�patch���ӵ�sup_patch�ﲢ����
		{
			cout << "Compute " << patch_bound.size() << " patch_bounds!" << endl;
			for (int k = 0; k < patch_bound.size(); k++)
			{
				pt2 = patch_bound[k];
				/*if (pt2.used_time != 0)
				continue;*/
				for (int t = 0; t < sort_density.size(); t++)
				{
					Patch pt = pt2;
					vector<double> density_in = sort_density[t].first;
					double patch_e = 0;
					int num_bigerror = matched_degree_p_d(pt, total_Tiles, 0, 1, density_in, patch_e);
					//pt.density = pt.density / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
					pt.used_time = 0;
					int final_pos = begin_pos + k*sort_density.size() + t;
					while (class_id_set.count(final_pos) != 0)
					{
						final_pos++;
					}
					class_id_set.insert(final_pos);
					pt.class_id = final_pos;
					sup_patch.push_back(make_pair(pt, k));

					//0927����ܶ�
					//if (pt.class_id >= 476 && pt.class_id <= 479)
					//{
					//	for (int ii = 0; ii < size; ii++)
					//	{
					//		for (int jj = 0; jj < size; jj++)
					//		{
					//			cout << total_Tiles[pt.wg[ii][jj]].black_pic*1.0 / (75 * 75) << " ";
					//		}
					//		cout << endl;
					//	}
					//}
					//
					//cout << pt.class_id << " " << t << endl;
					//0927

					//add rotate patch
					//PatchGenerator patches(3, 3, 4);
					Patch ptt = sup_patch[sup_patch.size() - 1].first;
					//patches.patch.push_back(ptt);
					for (int i = 0; i < 3; i++)
					{
						ptt = add_rotate_patch(ptt, 0);
						ptt.class_id = final_pos;
						sup_patch.push_back(make_pair(ptt, k));
						//patches.patch.push_back(ptt);
					}
					/*Mat show = Mat(1050, 3800, CV_8UC3, Scalar(255, 255, 255));
					Mat show1 = Mat(1050, 3800, CV_8UC3, Scalar(255, 255, 255));
					int _0x = 0, _0y = 0;
					vector<pair<double, int> >txt;
					patches.draw_patch(1, 10, 10, Color_, total_Tiles, show, show1, txt);
					imwrite("rotate.jpg", show);*/
				}
			}
			cout << "Generate " << sup_patch.size() << " new patches!" << endl;
		}
		return sup_patch;
	}

	void PatchGenerator::set_patch_density(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, int scale)
	{
		if (scale == 0)//��С ȫ��
		{
			pair<double, int> Pair;
			vector<vector<pair<double, int> > > nw(9);
			for (int i = 0; i < total_Tiles.size(); i++)
			{
				Tile tt = total_Tiles[i];
				int pos = tt.Left.id * 3 + tt.Bottom.id;
				nw[pos].push_back(make_pair(tt.black_pic*1.0 / (tile_edge_length*tile_edge_length), i));
			}

			int flag[5][5];
			//cout << nw.size() << endl;
			for (int i = 0; i < nw.size(); i++)
			{
				//cout << nw[i].size() << endl;
				vector<pair<double, int> > nw_pt = nw[i];
				memset(flag, 0, sizeof(flag));
				sort(nw_pt.begin(), nw_pt.end(), cmp_pair);
				double den = 0;
				
				//step 1: first search
				Tile tt = total_Tiles[nw_pt[0].second];
				if (flag[tt.Right.id][tt.Top.id] == 0)
				{
					flag[tt.Right.id][tt.Top.id] = 1;
					Patch pt(1, 1, tt.Bottom.id, tt.Left.id, tt.Top.id, tt.Right.id);
					pt.wg[0][0] = nw_pt[0].second;
					pt.density = tt.black_pic*1.0 / pow(Color_[0].edge_length, 2);
					pt.class_id = patch.size();//��������ת��ID
					patch.push_back(pt);
				}
				tt = total_Tiles[nw_pt[nw_pt.size() - 1].second];
				if (flag[tt.Right.id][tt.Top.id] == 0)
				{
					flag[tt.Right.id][tt.Top.id] = 1;
					Patch pt(1, 1, tt.Bottom.id, tt.Left.id, tt.Top.id, tt.Right.id);
					pt.wg[0][0] = nw_pt[nw_pt.size() - 1].second;
					pt.density = tt.black_pic*1.0 / pow(Color_[0].edge_length, 2);
					pt.class_id = patch.size();//��������ת��ID
					patch.push_back(pt);
				}

				for (int j = 0; j < nw_pt.size(); j++)
				{
					if (nw_pt[j].first < den)
						continue;
					tt = total_Tiles[nw_pt[j].second];
					if (flag[tt.Right .id][tt.Top.id]==0)
					{
						flag[tt.Right.id][tt.Top.id] = 1;
						Patch pt(1, 1, tt.Bottom.id, tt.Left.id, tt.Top.id, tt.Right.id);
						pt.wg[0][0] = nw_pt[j].second;
						pt.density = tt.black_pic*1.0 / pow(Color_[0].edge_length, 2);
			            pt.class_id = patch.size();//��������ת��ID
						patch.push_back(pt);
						den += 0.1;
					}	
				}
				/*for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 3; j++)
						cout << flag[i][j] << " ";
					cout << endl;
				}*/
				//cout << "1st patch size: " << patch.size() << endl;
				//step 2: research
				for (int k1 = 0; k1 < 3; k1++)
				{
					for (int k2 = 0; k2 < 3; k2++)
					{
						if (flag[k1][k2] == 0)
						{
							for (int t = 0; t < nw_pt.size(); t++)
							{
								Tile tt = total_Tiles[nw_pt[t].second];
								if (tt.Right.id == k1&&tt.Top.id == k2)
								{
									flag[tt.Right.id][tt.Top.id] = 1;
									Patch pt(1, 1, tt.Bottom.id, tt.Left.id, tt.Top.id, tt.Right.id);
									pt.wg[0][0] = nw_pt[t].second;
									pt.density = tt.black_pic*1.0 / pow(Color_[0].edge_length, 2);
									pt.class_id = patch.size();//��������ת��ID
									patch.push_back(pt);
									break;
								}
							}
						}
					}
				}
				/*for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 3; j++)
						cout << flag[i][j] << " ";
					cout << endl;
				}*/
				cout << "1st patch size: " << patch.size() << endl;
			}
			cout << "The final 1st patch size: " << patch.size() << endl;
			sort(patch.begin(), patch.end(), cmp_patch);
			for (int i = 0; i < patch.size(); i++)
				patch[i].class_id = i;
			//cout << patch.size() << endl;

			//discard rotate tile
			vector<int>class_flag(patch.size(), 1);
			vector<Patch> patch_temp;
			for (int i = 0; i < patch.size(); i++)
			{
				if (class_flag[i] == 0)
					continue;
				patch_temp.push_back(patch[i]);
				set<int>rr;
				int j1 = patch[i].wg[0][0];
				int j2 = rotate_link[patch[i].wg[0][0]];
				rr.insert(j1);
				while (j1 != j2)
				{
					rr.insert(j2);
					j2 = rotate_link[j2];
				}
				if (i < patch.size() - 1)
				{
					for (int j = i + 1; j < patch.size(); j++)
					{
						if (class_flag[j] == 0)
							continue;
						if (rr.count(patch[j].wg[0][0]) != 0)
							class_flag[j] = 0;
					}
				}	
			}
			patch.clear();
			patch = patch_temp;
			for (int i = 0; i < patch.size(); i++)
				patch[i].class_id = i;
			total_classes_num = patch.size();
			cout << "After reducing, final 1st patch size: " << total_classes_num << endl;
			//for (int i = 0; i < total_Tiles.size(); i++)
			//{
			//	Tile tt = total_Tiles[i];
			//	Patch pt(1, 1, tt.Bottom.id, tt.Left.id, tt.Top.id, tt.Right.id);
			//	pt.wg[0][0] = i;
			//	pt.density = tt.black_pic*1.0 / pow(Color_[0].edge_length, 2);
			//	pt.class_id = patch.size();//��������ת��ID
			//	patch.push_back(pt);
			//}
		}
		else //2*n*n
		{

		}
	}
	void PatchGenerator::set_A(int A[], vector<CS> Color_)
	{
		//double TT[5][2] = { 0.04,0.04,0.04,0.09,0.09,0.09,0.09,0.13,0.13,0.13 };
		double TT[7][3] = { /*0.04,0.04,0.04/**/0.04, 0.04, 0.04/**/, 0.04, 0.04, 0.09/**//*,0.04,0.04,0.09/**/, 0.04, 0.09, 0.09/**//*,0.04,0.09,0.09/**/, 0.09, 0.09, 0.09/**//*,0.09,0.09,0.09/**/, 0.09, 0.09, 0.13/**//*,0.09,0.09,0.13/**/, 0.09, 0.13, 0.13/**//*,0.09,0.13,0.13/**/, 0.13, 0.13, 0.13 };
		for (int i = 0; i < 7; i++)
		{
			double sig1 = TT[i][0];
			double sig2 = TT[i][1];

			for (int j = 0; j < sq.size(); j++)
			{
				int flg = 0;
				for (int k = 0; k < 3; k++)
				{
					if (Color_[sq[j][k]].Sigma != TT[i][k])
					{
						flg = 1;
						break;
					}

				}
				if (flg == 0)
				{
					A[i] = j;
					break;
				}
				/*if (Color_[sq[j][0]].Sigma == sig1&&Color_[sq[j][1]].Sigma == sig2)
				{
				A[i] = j;
				break;
				}*/
			}
		}

	}

	void PatchGenerator::find_A(vector<int>& A)
	{
		for (int i = 0; i < choose_sq.size(); i++)
		{
			vector<int> t1 = choose_sq[i];
			int flag = 1;
			for (int j = 0; j < sq.size(); j++)
			{
				vector<int> t2 = sq[j];
				flag = 1;
				for (int k = 0; k < t2.size(); k++)
				{
					if (t1[k] != t2[k])
					{
						flag = 0;
						break;
					}
				}
				if (flag == 1)
				{
					A.push_back(j);
					break;
				}
			}
		}
	}

	Patch PatchGenerator::add_rotate_patch(Patch pt1, int c)
	{
		Patch pt = pt1;
		if (c == 0)//nsz90
		{
			for (int i = 0; i < pt1.M; i++)
			{
				for (int j = 0; j < pt1.N; j++)
				{
					pt.wg[pt1.M - 1 - j][i] = pt1.wg[i][j];
				}
			}
			for (int i = 0; i < pt1.M; i++)
			{
				for (int j = 0; j < pt1.N; j++)
				{
					pt.wg[i][j] = rotate_link[pt.wg[i][j]];
				}
			}
			int tmp = pt.nn;
			pt.nn = pt.en;
			pt.en = pt.sn;
			pt.sn = pt.wn;
			pt.wn = tmp;
		}
		else if (c == 1)//nsz180
		{

		}
		else if (c == 2)//nsz270
		{

		}
		return pt;
	}

	Patch PatchGenerator::rotate_patch_boundary(Patch pt1, int degree)//rotate patch boundary
	{
		Patch pt = pt1;
		if (degree == 90)//nsz90
		{
			int tmp = pt.nn;
			pt.nn = pt.en;
			pt.en = pt.sn;
			pt.sn = pt.wn;
			pt.wn = tmp;
			//cout << "rotate " << degree << endl;
		}
		else if (degree == 180)
		{
			int tmp = pt.nn;
			pt.nn = pt.sn;
			pt.sn = tmp;
			tmp = pt.en;
			pt.en = pt.wn;
			pt.wn = tmp;
		}
		else if (degree == 270)
		{
			int tmp = pt.nn;
			pt.nn = pt.wn;
			pt.wn = pt.sn;
			pt.sn = pt.en;
			pt.en = tmp;
		}
		return pt;
	}

	int PatchGenerator::internal_tiling(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<PAIR> sort_density)
	{
		Patch pt = pt_in;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		if (sort_density.empty()) return 0;
		//cout << "sort_density size: " << sort_density.size() << endl;
		int min_bigerror = 100;
		int min_pos = 0;
		int tt = 0;// rand() % sort_density.size();
		for (int index = tt, add = 0; add < sort_density.size(); index++, add++)
		{
			int choose_density_patch = index%sort_density.size();
			vector<double> density_in = sort_density[choose_density_patch].first;
			double patch_e = 0;
			int num_bigerror = matched_degree_p_d(pt, total_Tiles, sig1, sig2, density_in, patch_e);

			if (num_bigerror < min_bigerror)
			{
				pt_in = pt;
				min_bigerror = num_bigerror;
				min_pos = choose_density_patch;
			}
			if (big_error == 0) break;

		}
		if (min_bigerror != 0) cout << "ILLEGAL PATCH WITH " << min_bigerror << " BIG_ERROR TILES " << endl;
		return min_pos;		
	}

	int PatchGenerator::internal_tiling(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<PAIR> sort_density, vector<int> &used_density) //-----lxk
	{
		Patch pt = pt_in;
		int max_den_num = patch.size() / sort_density.size() + (patch.size() % sort_density.size() == 0 ? 0 : 1);
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		if (sort_density.empty()) return 0;
		//cout << "sort_density size: " << sort_density.size() << endl;
		int min_bigerror = 100;
		int min_pos = 0;
		int tt = 0;// rand() % sort_density.size();
		for (int index = tt, add = 0; add < sort_density.size(); index++, add++)
		{
			int choose_density_patch = index%sort_density.size();
			if (used_density[choose_density_patch] >= max_den_num) continue;
			vector<double> density_in = sort_density[choose_density_patch].first;
			double patch_e = 0;
			int num_bigerror = matched_degree_p_d(pt, total_Tiles, sig1, sig2, density_in, patch_e);

			if (num_bigerror < min_bigerror)
			{
				pt_in = pt;
				min_bigerror = num_bigerror;
				min_pos = choose_density_patch;
			}
			if (big_error == 0) break;

		}
		if (min_bigerror != 0) cout << "ILLEGAL PATCH WITH " << min_bigerror << " BIG_ERROR TILES " << endl;
		return min_pos;
	}

	int PatchGenerator::internal_with_density(vector<Patch> & patch_tem , vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in) //-----lxk
	{
		int psize = patch.size();
		int tt = rand() % psize;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		int min_bigerror = 100;
		int min_pos = 0;
		Patch pt_final;

		for (int index = tt, add = 0; add < psize; index++, add++)
		{
			int choose_density_patch = index%psize; 
			Patch pt = patch[choose_density_patch];
			double patch_e = 0;
			int num_bigerror = matched_degree_p_d(pt, total_Tiles, sig1, sig2, density_in, patch_e);

			if (num_bigerror < min_bigerror)
			{
				pt_final = pt;
				min_bigerror = num_bigerror;
				min_pos = choose_density_patch;
			}
			if (big_error == 0) break;
		}
		patch_tem.push_back(pt_final);
		if (min_bigerror != 0) cout << "ILLEGAL PATCH WITH " << min_bigerror << " BIG_ERROR TILES " << endl;
		return min_pos;
	}

	int PatchGenerator::internal_with_density(vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, vector<int>& used_patch, vector<CS> Color_) //-----lxk
	{
		int psize = patch.size();
		int tt = 0;// rand() % psize;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		int min_bigerror = 100;
		int min_pos = 0;
		Patch pt_final;

		for (int index = tt, add = 0; add < psize; index++, add++)
		{
			int choose_density_patch = index%psize;
			if (used_patch[choose_density_patch] != 0) continue;
			Patch pt = patch[choose_density_patch];
			double patch_e = 0;
			//int num_bigerror = matched_degree_p_d(pt, total_Tiles, sig1, sig2, density_in, patch_e);
			int num_bigerror = matched_degree_density_first(pt, total_Tiles, sig1, sig2, density_in, patch_e, Color_);

			if (num_bigerror <= min_bigerror)
			{
				pt_final = pt;
				min_bigerror = num_bigerror;
				min_pos = choose_density_patch;
			}
			if (big_error == 0) break;
		}
		cout << "wrong wrong wrong" << endl;
		for (int i = 0; i < pt_final.M; i++)
		{
			for (int j = 0; j < pt_final.N; j++)
			{
				cout << pt_final.wg[i][j] << " ";
				if (pt_final.wg[i][j] < 0 || pt_final.wg[i][j] >= total_Tiles.size())
					cout << 1 << endl;
			}
			cout << endl;
		}
		if (is_redundant(pt_final, used_patch, total_Tiles))
		{
			patch[min_pos] = pt_final;
			if (min_bigerror != 0) cout << "ILLEGAL PATCH WITH " << min_bigerror << " BIG_ERROR TILES " << endl;
			return min_pos;
		}
		else
		{
			return -1;
		}
	}

	int PatchGenerator::internal_with_density(vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, vector<int>& used_patch) //-----lxk
	{
		int psize = patch.size();
		int tt = 0;// rand() % psize;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		int min_bigerror = 100;
		int min_pos = 0;
		Patch pt_final;

		for (int index = tt, add = 0; add < psize; index++, add++)
		{
			int choose_density_patch = index%psize;
			if (used_patch[choose_density_patch] != 0) continue;
			Patch pt = patch[choose_density_patch];
			double patch_e = 0;
			int num_bigerror = matched_degree_p_d(pt, total_Tiles, sig1, sig2, density_in, patch_e);
			if (num_bigerror < min_bigerror)
			{
				pt_final = pt;
				min_bigerror = num_bigerror;
				min_pos = choose_density_patch;
			}
			if (big_error == 0) break;
		}
		if (is_redundant(pt_final, used_patch, total_Tiles))
		{
			patch[min_pos] = pt_final;
			if (min_bigerror != 0) cout << "ILLEGAL PATCH WITH " << min_bigerror << " BIG_ERROR TILES " << endl;
			return min_pos;
		}
		else
		{
			return -1;
		}
	}

	int PatchGenerator::internal_bound_density(vector<Tile> total_Tiles, vector<double> density_in, Patch pt_in)     //--lxk: fixed bound 
	{
		int psize = patch.size();
		int tt = 0;// rand() % psize;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		int min_bigerror = 100;
		int min_pos = 0;
		Patch pt_final;
		double min_patch_error = 0;
		Point2f start;

		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				Patch pt = pt_in;
				double patch_e = 0;
				int num_bigerror = matched_degree_p_d(pt, total_Tiles, density_in, patch_e, Point2f(j, i));
				cout << "start(" << i << ", " << j << ") has error: " << patch_e << endl;
				if (patch_e < min_patch_error)
				{
					pt_final = pt;
					min_bigerror = num_bigerror;
					min_patch_error = patch_e;
					start = Point2f(j, i);
				}
			}
		}
		cout << start << "  has error: " << min_patch_error << endl;
		return min_bigerror;
	}

	bool PatchGenerator::is_redundant(Patch pt, vector<int> used_patch, vector<Tile> total_Tiles)
	{
		double thres = 0.04;
		for (int i = 0; i < patch.size(); i++)
		{
			if (used_patch[i] == 0)
				continue;
			Patch ptt = pt;
			for (int j = 0; j < 4; j++)
			{
				if (ptt.wn == patch[i].wn&&ptt.nn == patch[i].nn&&ptt.en == patch[i].en&&ptt.sn == patch[i].sn)
				{
					//whether be the same
					/*for (int i = 0; i < size; i++)
					{
						for (int j = 0; j < size; j++)
						{
							cout << ptt.wg[i][j] << " " << patch[i].wg[i][j] << endl;
						}
					}*/

					double temp_error = cal_patch_error(total_Tiles, ptt, patch[i], size);
					if (temp_error < thres)
					{
						return false;
					}
				}
				ptt = add_rotate_patch(ptt, 0);
			}
		}
		return true;
	}

	int PatchGenerator::matched_degree_p_d(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e) //-----lxk
	{
		Patch pt = pt_in;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		big_error = 0;
		
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				ww = ss = nn = ee = -1;
				if (i == 0)//����
				{
					nn = sq[pt.nn][j];
				}
				if (i == size - 1)
				{
					ss = sq[pt.sn][j];
				}
				if (j == 0)
				{
					ww = sq[pt.wn][i];
				}
				if (j == size - 1)
				{
					ee = sq[pt.en][i];
				}
				if (i == 0 && j == 0)
				{
					pt.wg[i][j] = total_Tiles[0].match_tile_with_constrain(total_Tiles, st, -1, ww, ee, nn, ss, sig1, sig2, density_in[i*size + j]);
					black_n += total_Tiles[pt.wg[i][j]].black_pic;
					double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic / pow(tile_edge_length, 2) - density_in[i*size + j]);
					patch_e += density_e;
				}
				else if (i == 0 && j != 0)
				{
					//����ѡ��error��С��
					pt.wg[i][j] = total_Tiles[pt.wg[i][j - 1]].match_tile_with_constrain(total_Tiles, st, RightLeft, ww, ee, nn, ss, sig1, sig2, density_in[i*size + j]);
					//cout << total_Tiles[pt.wg[i][j]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[i][j - 1]].Right.edge_colorScheme.id << endl;
					black_n += total_Tiles[pt.wg[i][j]].black_pic;
					double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic / pow(tile_edge_length, 2) - density_in[i*size + j]);
					patch_e += density_e;
				}
				else if (i != 0 && j == 0)
				{
					pt.wg[i][j] = total_Tiles[pt.wg[i - 1][j]].match_tile_with_constrain(total_Tiles, st, BottomTop, ww, ee, nn, ss, sig1, sig2, density_in[i*size + j]);
					//cout << total_Tiles[pt.wg[i][j]].Bottom.edge_colorScheme.id << " " << total_Tiles[pt.wg[i - 1][j]].Top.edge_colorScheme.id << endl;
					black_n += total_Tiles[pt.wg[i][j]].black_pic;
					double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic / pow(tile_edge_length, 2) - density_in[i*size + j]);
					patch_e += density_e;
				}
				else
				{
					//�����С�ڲ���ֵ�ĺ�ѡ���л���,������ܼ���Ϊ��,��������ֱֵ����Ϊ��,������ѡ��
					double min_e = 10000;
					vector<pair<int, vector<double> > > final_;
					for (int f_num = 0; f_num < total_Tiles.size(); f_num++)
					{
						if (ww != -1)
						{
							if (total_Tiles[f_num].Left.edge_colorScheme.id != ww)
								continue;
						}
						if (ee != -1)
						{
							if (total_Tiles[f_num].Right.edge_colorScheme.id != ee)
								continue;
						}
						if (ss != -1)
						{
							if (total_Tiles[f_num].Top.edge_colorScheme.id != ss)
								continue;
						}
						if (nn != -1)
						{
							if (total_Tiles[f_num].Bottom.edge_colorScheme.id != nn)
								continue;
						}


						if (total_Tiles[f_num].Left.edge_colorScheme.Sigma<min(sig1, sig2) || total_Tiles[f_num].Left.edge_colorScheme.Sigma>max(sig1, sig2))
							continue;
						if (total_Tiles[f_num].Bottom.edge_colorScheme.Sigma<min(sig1, sig2) || total_Tiles[f_num].Bottom.edge_colorScheme.Sigma>max(sig1, sig2))
							continue;
						if (ee == -1 && (total_Tiles[f_num].Right.edge_colorScheme.Sigma<min(sig1, sig2) - 0.01 || total_Tiles[f_num].Right.edge_colorScheme.Sigma>max(sig1, sig2) + 0.01))
							continue;
						if (ss == -1 && (total_Tiles[f_num].Top.edge_colorScheme.Sigma<min(sig1, sig2) - 0.01 || total_Tiles[f_num].Top.edge_colorScheme.Sigma>max(sig1, sig2) + 0.01))
							continue;

						double error_ = total_Tiles[pt.wg[i - 1][j]].Top.compare_edge_with(total_Tiles[f_num].Bottom);
						error_ += total_Tiles[pt.wg[i][j - 1]].Right.compare_edge_with(total_Tiles[f_num].Left);
						//cout << "sort_density : " << sort_density.size() << "  " << f_num << " choose_density_patch:" << choose_density_patch << endl;
						if (error_ <= min_e)
						{
							if (min_e - error_ > 0.001)
							{
								final_.swap(vector<pair<int, vector<double> > >());
								min_e = error_;
								//min_index = i;
								vector<double>tt;
								tt.push_back(total_Tiles[f_num].black_pic / pow(tile_edge_length, 2));
								tt.push_back(density_in[i*size + j]);
								final_.push_back(make_pair(f_num, tt));
							}
							else
							{
								vector<double>tt;
								tt.push_back(total_Tiles[f_num].black_pic / pow(tile_edge_length, 2));
								tt.push_back(density_in[i*size + j]);
								final_.push_back(make_pair(f_num, tt));
							}
						}
					}
					//srand((unsigned)time(NULL));
					sort(final_.begin(), final_.end(), cmp_error);
					int itt = rand() % final_.size();
					pt.wg[i][j] = final_[0].first;
					black_n += total_Tiles[pt.wg[i][j]].black_pic;
					double density_e = abs(final_[0].second[0] - final_[0].second[1]);
					patch_e += density_e;
					if (density_e> inter_error_threshold) big_error++;
					//cout << "error " << min_e << endl;
					//cout << total_Tiles[pt.wg[i][j]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[i][j - 1]].Right.edge_colorScheme.id << endl;
					//cout << total_Tiles[pt.wg[i][j]].Bottom.edge_colorScheme.id << " " << total_Tiles[pt.wg[i - 1][j]].Top.edge_colorScheme.id << endl;
				}
			}
		}
		patch_e = patch_e / pow(size, 2);
		pt.density = black_n*1.0 / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
		pt_in = pt;
		return big_error;
	}

	int PatchGenerator::matched_degree_p_d(Patch &pt_in, vector<Tile> total_Tiles, vector<double> density_in, double & patch_e, Point2f start) //-----lxk
	{
		Patch pt = pt_in;
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		big_error = 0;
		int start_i = start.y;
		int start_j = start.x;
		vector<vector<int>> flag_(size, vector<int>(size, -1));

		for (int i = start_i; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				if (i == start_i&&j == 0) j = start_j;
				ww = ss = nn = ee = -1;
				if (i == 0)//����
				{
					nn = sq[pt.nn][j];
				}
				if (i == size - 1)
				{
					ss = sq[pt.sn][j];
				}
				if (j == 0)
				{
					ww = sq[pt.wn][i];
				}
				if (j == size - 1)
				{
					ee = sq[pt.en][i];
				}
				if (j > 0 && j < size - 1)
				{
					if (flag_[i][j - 1] != -1)
					{
						ww = total_Tiles[pt.wg[i][j - 1]].Right.edge_colorScheme.id;
					}
					if (flag_[i][j + 1] != -1)
					{
						ee = total_Tiles[pt.wg[i][j + 1]].Left.edge_colorScheme.id;
					}
					//����ѡ��error��С��
					//pt.wg[i][j] = total_Tiles[pt.wg[i][j - 1]].match_tile_with_constrain(total_Tiles, st, RightLeft, ww, ee, nn, ss, sig1, sig2, density_in[i*size + j]);
					
				}
				if (i > 0 && i < size - 1)
				{
					if (flag_[i - 1][j] != -1)
					{
						nn = total_Tiles[pt.wg[i - 1][j]].Top.edge_colorScheme.id;
					}
					if (flag_[i + 1][j] != -1)
					{
						ss = total_Tiles[pt.wg[i + 1][j]].Bottom.edge_colorScheme.id;
					}			
				}

				flag_[i][j] = 1;
				pt.wg[i][j] = match_tile_bound_constrain(total_Tiles, st, ww, ee, nn, ss, density_in[i*size + j]);
				black_n += total_Tiles[pt.wg[i][j]].black_pic;
				double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic / pow(tile_edge_length, 2) - density_in[i*size + j]);
				patch_e += density_e;
			}
		}
		//reverse direction
		for (int i = start_i; i >= 0; i--)
		{
			for (int j = size - 1; j >= 0; j--)
			{
				if (i == start_i&&j == size - 1) j = start_j - 1;
				if (j < 0) continue;
				ww = ss = nn = ee = -1;
				if (i == 0)//����
				{
					nn = sq[pt.nn][j];
				}
				if (i == size - 1)
				{
					ss = sq[pt.sn][j];
				}
				if (j == 0)
				{
					ww = sq[pt.wn][i];
				}
				if (j == size - 1)
				{
					ee = sq[pt.en][i];
				}
				if (j > 0 && j < size - 1)
				{
					if (flag_[i][j - 1] != -1)
					{
						ww = total_Tiles[pt.wg[i][j - 1]].Right.edge_colorScheme.id;
					}
					if (flag_[i][j + 1] != -1)
					{
						ee = total_Tiles[pt.wg[i][j + 1]].Left.edge_colorScheme.id;
					}
					//����ѡ��error��С��
					//pt.wg[i][j] = total_Tiles[pt.wg[i][j - 1]].match_tile_with_constrain(total_Tiles, st, RightLeft, ww, ee, nn, ss, sig1, sig2, density_in[i*size + j]);

				}
				if (i > 0 && i < size - 1)
				{
					if (flag_[i - 1][j] != -1)
					{
						nn = total_Tiles[pt.wg[i - 1][j]].Top.edge_colorScheme.id;
					}
					if (flag_[i + 1][j] != -1)
					{
						ss = total_Tiles[pt.wg[i + 1][j]].Bottom.edge_colorScheme.id;
					}
				}

				flag_[i][j] = 1;
				pt.wg[i][j] = match_tile_bound_constrain(total_Tiles, st, ww, ee, nn, ss, density_in[i*size + j]);
				black_n += total_Tiles[pt.wg[i][j]].black_pic;
				double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic / pow(tile_edge_length, 2) - density_in[i*size + j]);
				patch_e += density_e;
			}

		}
		patch_e = patch_e / pow(size, 2);
		pt.density = black_n*1.0 / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
		pt_in = pt;
		return big_error;
	}

	int PatchGenerator::match_iter_random(Patch & pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e, vector<CS> Color_, vector<double>& image_density)
	{
		clock_t start, finish;
		start = clock();
		//random search
		//Patch pt_min;
		//double min_error = 10000;
		patch_e = 10000;
		double min_thres;
		//cout << " total_Tiles.size(): " << total_Tiles.size() << endl;
		int area = tile_edge_length*tile_edge_length;
		vector<double> para_ = { 0.2, 0, 0.8 };
		for (int iter = 0; iter < 50; iter++)
		{
			Patch pt = pt_in;
			int black_n = 0;
			int big_error_num = 0;
			double patch_err_iter = 0;
			vector<double> image_density_min;
			//1.�����ܶ�����ֱ�ӷ�, ÿ��ʹ�ò�ͬ�ĳ�ʼ״̬, ���е�һ������������
			for (int i = 0; i < size; i++)
			{
				for (int j = 0; j < size; j++)
				{
					int pos = -1;
					double error = 100;
					vector<int> cand_tile;

					if (iter == -1)
					{
						for (int k = 0; k < total_Tiles.size(); k++)
						{
							if (error > abs(density_in[i*size + j] - total_Tiles[k].black_pic*1.0 / area))
							{
								error = abs(density_in[i*size + j] - total_Tiles[k].black_pic*1.0 / area);
								pos = k;
							}						
						}
						pt.wg[i][j] = pos;
					}
					else
					{
						for (int k = 0; k < total_Tiles.size(); k++)
						{
							double error_one = abs(density_in[i*size + j] - total_Tiles[k].black_pic*1.0 / area);
							/*if (error_one < error)
							{
							error = error_one;
							cand_tile.swap(vector<int>());
							cand_tile.push_back(k);
							}
							else if (error_one == error)
							{
							cand_tile.push_back(k);
							}*/
							double diff_err = abs(error_one - error);
							if (diff_err < 0.001)
							{
								//cout << "< 0.001: "<<error_one << "  " << error << endl;
								cand_tile.push_back(k);
							}
							else if (error_one < error)
							{
								//cout << "density: " << density_in[i*size + j] << "  " << total_Tiles[k].black_pic*1.0 / area << endl;
								//cout << "error_one < error: " << error_one << "  " << error << endl;
								error = error_one;
								cand_tile.swap(vector<int>());
								cand_tile.push_back(k);
							}
						}
						/*for (int tt = 0; tt < cand_tile.size(); tt++)
						cout << total_Tiles[cand_tile[tt]].black_pic*1.0 / area << " ";*/
						pos = rand() % cand_tile.size();
						//cout << "target: " << density_in[i*size + j] << "   Cand_tile.size: " << cand_tile.size() << "   pos�� "<<pos<<endl;
						pt.wg[i][j] = cand_tile[pos];
						//cout << size<<" "<<i<<"  "<< j<<"  "<<density_in[i*size + j] << endl;
					}				
				}
				//cout << endl;
			}
			/*finish = clock();
			cout << endl << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;*/

			vector<Patch>patch_show;
			//patch_show.push_back(pt);
			//show_patch(patch_show, Color_, total_Tiles);
			//2. ��������
			int ww, ss, nn, ee;
			vector<vector<int> >color_id(size*size, vector<int>(4, -1));
			vector<vector<int> >tile_edge_id(total_Tiles.size(), vector<int>(4, -1));
			vector<int>default_numbers(size*size, 0);
			set<int> is_iter;
			for (int i = 0; i < total_Tiles.size(); i++)
			{
				tile_edge_id[i][0] = total_Tiles[i].Left.id;
				tile_edge_id[i][1] = total_Tiles[i].Bottom.id;
				tile_edge_id[i][2] = total_Tiles[i].Right.id;
				tile_edge_id[i][3] = total_Tiles[i].Top.id;
			}
			for (int i = 0; i < size; i++)
			{
				for (int j = 0; j < size; j++)
				{
					ww = ss = nn = ee = -1;
					if (i == 0)//����
					{
						nn = sq[pt.nn][j];
						color_id[i*size + j][1] = nn;
					}
					if (i == size - 1)
					{
						ss = sq[pt.sn][j];
						color_id[i*size + j][3] = ss;
					}
					if (j == 0)
					{
						ww = sq[pt.wn][i];
						color_id[i*size + j][0] = ww;
					}
					if (j == size - 1)
					{
						ee = sq[pt.en][i];
						color_id[i*size + j][2] = ee;
					}
					for (int k = 0; k < 4; k++)
					{
						if (k == 0 && color_id[i*size + j][k] == -1)
						{
							color_id[i*size + j][k] = total_Tiles[pt.wg[i][j - 1]].Right.id;
						}
						if (k == 1 && color_id[i*size + j][k] == -1)
						{
							color_id[i*size + j][k] = total_Tiles[pt.wg[i - 1][j]].Top.id;
						}
						if (k == 2 && color_id[i*size + j][k] == -1)
						{
							color_id[i*size + j][k] = total_Tiles[pt.wg[i][j + 1]].Left.id;
						}
						if (k == 3 && color_id[i*size + j][k] == -1)
						{
							color_id[i*size + j][k] = total_Tiles[pt.wg[i + 1][j]].Bottom.id;
						}
					}
				}
			}
			//3.����������
			int cnt = 0;
			//int num_mismatch[10][10];
			vector<pair<Point, int>> num_mismatch;
			double thres = 0.05;
			//all_edge_match: ��������λ�ò�ƥ�����Ŀ������
			//while (!all_edge_match(total_Tiles, pt, color_id, num_mismatch))
			//{
			//	//start = clock();
			//	cnt++;
			//	
			//	//��num_mismatch���Ԫ�ذ�������ȫ���滻
			//	for (int mis_in = 0; mis_in < num_mismatch.size(); mis_in++)
			//	{
			//		int posx = num_mismatch[mis_in].first.x;
			//		int posy = num_mismatch[mis_in].first.y;
			//		int default_num = defaultNum(total_Tiles[pt.wg[posx][posy]], posx, posy, color_id);

			//		int startpos = rand() % total_Tiles.size();
			//		//cout << "startpos: " << startpos << endl;
			//		for (int k = 0; k < total_Tiles.size(); k++, startpos++)
			//		{
			//			//finish = clock();
			//			//cout << endl << k << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
			//			int kk = startpos%total_Tiles.size();
			//			if (kk == pt.wg[posx][posy])
			//				continue;
			//			Tile tt = total_Tiles[kk];
			//			if (abs(tt.black_pic*1.0 / area - density_in[posx*size + posy]) > thres)
			//				continue;
			//			int num = defaultNum(tt, posx, posy, color_id);
			//			if (num < default_num)  //�����滻
			//				//if (num == 0)  //�����滻
			//			{
			//				pt.wg[posx][posy] = startpos%total_Tiles.size();
			//				if (posx > 0)
			//					color_id[(posx - 1)*size + posy][3] = tt.Bottom.id;
			//				if (posy > 0)
			//					color_id[posx*size + posy - 1][2] = tt.Left.id;
			//				if (posx != size - 1)
			//					color_id[(posx + 1)*size + posy][1] = tt.Top.id;
			//				if (posy != size - 1)
			//					color_id[posx*size + posy + 1][0] = tt.Right.id;
			//				//patch_show.push_back(pt);
			//				//show_patch(patch_show, Color_, total_Tiles);
			//				break;
			//			}
			//		}

			//	}
			//	

			//	////�ҵ��滻��λ��, ÿ�ζ��ǲ�ƥ���������ĵ�һ��
			//	//int posx = num_mismatch[0].first.x;
			//	//int posy = num_mismatch[0].first.y;
			//	//int default_num = num_mismatch[0].second;

			//	//int startpos = rand() % total_Tiles.size();
			//	////cout << "startpos: " << startpos << endl;
			//	//for (int k = 0; k < total_Tiles.size(); k++, startpos++)
			//	//{
			//	//	//finish = clock();
			//	//	//cout << endl << k << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
			//	//	int kk = startpos%total_Tiles.size();
			//	//	if (kk == pt.wg[posx][posy])
			//	//		continue;
			//	//	Tile tt = total_Tiles[kk];
			//	//	if (abs(tt.black_pic*1.0 / area - density_in[posx*size + posy]) > thres)
			//	//		continue;
			//	//	int num = defaultNum(tt, posx, posy, color_id);
			//	//	if (num < default_num)  //�����滻
			//	//	//if (num == 0)  //�����滻
			//	//	{
			//	//		pt.wg[posx][posy] = startpos%total_Tiles.size();
			//	//		if (posx > 0)
			//	//			color_id[(posx - 1)*size + posy][3] = tt.Bottom.id;
			//	//		if (posy > 0)
			//	//			color_id[posx*size + posy - 1][2] = tt.Left.id;
			//	//		if (posx != size - 1)
			//	//			color_id[(posx + 1)*size + posy][1] = tt.Top.id;
			//	//		if (posy != size - 1)
			//	//			color_id[posx*size + posy + 1][0] = tt.Right.id;
			//	//		//patch_show.push_back(pt);
			//	//		//show_patch(patch_show, Color_, total_Tiles);
			//	//		break;
			//	//	}
			//	//}
			//	if (cnt > 1)
			//	{
			//		thres += 0.05;
			//		cnt = -1;
			//		//cout << "cnt times is over 5!" << endl;
			//	}
			//	//finish = clock();
			//	//cout << endl << "All time consumption3: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
			//}
			//cout << "cnt times: " << cnt << "  thres:" << thres<<endl;

			while (!all_edge_match(tile_edge_id, pt, color_id))
			{
				//start = clock();
				cnt++;
				if (is_iter.size() == size*size)
				{
					thres += 0.05;
					is_iter.clear();
				}

				int posx, posy; //�Ҵ��滻��λ��
				while (1)
				{
					posx = rand() % size;
					posy = rand() % size;
					if (is_iter.count(posx*size + posy) == 0)
						break;
				}

				//cout << "posx,posy" << posx << " " << posy << " " << cnt << endl;
				int default_num = defaultNum(total_Tiles[pt.wg[posx][posy]], posx, posy, color_id);
				if (default_num == 0)
				{
					is_iter.insert(posx*size + posy);
					//patch_show.push_back(pt);
					//show_patch(patch_show, Color_, total_Tiles);
					continue;
				}
				else
				{
					int startpos = rand() % total_Tiles.size();
					int flag = 0;
					//cout << "startpos: " << startpos << endl;
					for (int k = 0; k < total_Tiles.size(); k++, startpos++)
					{
						//finish = clock();
						//cout << endl << k << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
						int kk = startpos%total_Tiles.size();
						if (kk == pt.wg[posx][posy])
							continue;
						Tile tt = total_Tiles[kk];
						if (abs(tt.black_pic*1.0 / area - density_in[posx*size + posy]) > thres)
							continue;

						//int temp_dn = defaultNum(tt, posx, posy, color_id);
						int num = defaultNum(tt, posx, posy, color_id);
						if (num < default_num)  //�滻
						{
							pt.wg[posx][posy] = startpos%total_Tiles.size();
							if (posx > 0)
								color_id[(posx - 1)*size + posy][3] = tt.Bottom.id;
							if (posy > 0)
								color_id[posx*size + posy - 1][2] = tt.Left.id;
							if (posx != size - 1)
								color_id[(posx + 1)*size + posy][1] = tt.Top.id;
							if (posy != size - 1)
								color_id[posx*size + posy + 1][0] = tt.Right.id;
							is_iter.erase(posx*size + posy);
							flag = 1;
							//patch_show.push_back(pt);
							//show_patch(patch_show, Color_, total_Tiles);
							break;
						}
					}
					//finish = clock();
					//cout << endl << "All time consumption3: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;

					if (flag == 0)
						is_iter.insert(posx*size + posy);
				}
				//finish = clock();
				//cout << endl << "All time consumption4: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
			}
			//cout << "thres: " << thres << endl;
			for (int i = 0; i < size; i++)
			{
				for (int j = 0; j < size; j++)
				{
					/*Mat pic_ = Mat(200, 200, CV_8UC3, Scalar(255, 255, 255));
					total_Tiles[pt.wg[i][j]].draw_Tile(pic_);
					imwrite(result_path + to_string(total_Tiles[pt.wg[i][j]].black_pic*1.0 / area) + ".png", pic_);*/
					black_n += total_Tiles[pt.wg[i][j]].black_pic;
					double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic*1.0 / area - density_in[i*size + j]);
					//cout << "pt ij: " << total_Tiles[pt.wg[i][j]].black_pic*1.0 / area << "    density: " << density_in[i*size + j] << endl;
					if (density_e> inter_error_threshold) big_error_num++;
					patch_err_iter += density_e;
					image_density_min.push_back(total_Tiles[pt.wg[i][j]].black_pic*1.0 / area);
					//cout << density_e << " ";
				}
			}
			//patch_err_iter = match_error(density_in, image_density_min, para_[0], para_[1], para_[2]);
			if (patch_err_iter < patch_e)
			{
				patch_e = patch_err_iter;
				pt.density = black_n*1.0 / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
				pt_in = pt;
				image_density = image_density_min;
				big_error = big_error_num;
				min_thres = thres;
			}
			//cout << iter << " iteration: " << patch_err_iter / size / size << "  " << big_error_num << endl;
			
		}
		cout << " Final:  " << patch_e / size / size << "  " << min_thres << endl;
		if (min_thres > 0.2) thres_over[2]++;
		else if (min_thres > 0.15) thres_over[1]++;
		else if (min_thres > 0.1) thres_over[0]++;

		//cout << pt_in.M << " " << pt_in.N << endl;
		return big_error;
	}

	int PatchGenerator::matched_degree_density_first(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e, vector<CS> Color_,vector<double>& image_density) 
	{
		clock_t start, finish;
		start = clock();
		Patch pt = pt_in;
		int black_n = 0;
		big_error = 0;

		int area = tile_edge_length*tile_edge_length;
		//1.�����ܶ�����ֱ�ӷ�
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				int pos = -1;
				double error = 100;
				for (int k = 0; k < total_Tiles.size(); k++)
				{
					if (error > abs(density_in[i*size + j] - total_Tiles[k].black_pic*1.0 / area))
					{
						error = abs(density_in[i*size + j] - total_Tiles[k].black_pic*1.0 / area);
						pos = k;
					}
				}
				pt.wg[i][j] = pos;
				//cout << size<<" "<<i<<"  "<< j<<"  "<<density_in[i*size + j] << endl;
			}
			//cout << endl;
		}
		/*finish = clock();
		cout << endl << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;*/

		vector<Patch>patch_show;
		//patch_show.push_back(pt);
		//show_patch(patch_show, Color_, total_Tiles);
		//2.����������
		double thres = 0.05;
		int ww, ss, nn, ee;
		vector<vector<int> >color_id(size*size, vector<int>(4, -1));
		vector<vector<int> >tile_edge_id(total_Tiles.size(), vector<int>(4, -1));
		vector<int>default_numbers(size*size, 0);
		set<int> is_iter;
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			tile_edge_id[i][0] = total_Tiles[i].Left.id;
			tile_edge_id[i][1] = total_Tiles[i].Bottom.id;
			tile_edge_id[i][2] = total_Tiles[i].Right.id;
			tile_edge_id[i][3] = total_Tiles[i].Top.id;
		}
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				ww = ss = nn = ee = -1;
				if (i == 0)//����
				{
					nn = sq[pt.nn][j];
					color_id[i*size + j][1] = nn;
				}
				if (i == size - 1)
				{
					ss = sq[pt.sn][j];
					color_id[i*size + j][3] = ss;
				}
				if (j == 0)
				{
					ww = sq[pt.wn][i];
					color_id[i*size + j][0] = ww;
				}
				if (j == size - 1)
				{
					ee = sq[pt.en][i];
					color_id[i*size + j][2] = ee;
				}
				for (int k = 0; k < 4; k++)
				{
					if (k == 0 && color_id[i*size + j][k] == -1)
					{
						color_id[i*size + j][k] = total_Tiles[pt.wg[i][j - 1]].Right.id;
					}
					if (k == 1 && color_id[i*size + j][k] == -1)
					{
						color_id[i*size + j][k] = total_Tiles[pt.wg[i - 1][j]].Top.id;
					}
					if (k == 2 && color_id[i*size + j][k] == -1)
					{
						color_id[i*size + j][k] = total_Tiles[pt.wg[i][j + 1]].Left.id;
					}
					if (k == 3 && color_id[i*size + j][k] == -1)
					{
						color_id[i*size + j][k] = total_Tiles[pt.wg[i + 1][j]].Bottom.id;
					}
				}
			}
		}
		int cnt = -1;
		while (!all_edge_match(tile_edge_id, pt, color_id))
		{
			//start = clock();
			cnt++;
			if (is_iter.size() == size*size)
			{
				thres += 0.05;
				is_iter.clear();
			}

			int posx, posy;
			while (1)
			{
				posx = rand() % size;
				posy = rand() % size;
				if (is_iter.count(posx*size + posy) == 0)
					break;
			}

			//cout << "posx,posy" << posx << " " << posy << " " << cnt << endl;
			int default_num = defaultNum(total_Tiles[pt.wg[posx][posy]], posx, posy, color_id);
			if (default_num == 0)
			{
				is_iter.insert(posx*size + posy);
				//patch_show.push_back(pt);
				//show_patch(patch_show, Color_, total_Tiles);
				continue;
			}
			else
			{
				int startpos = rand() % total_Tiles.size();
				int flag = 0;
				//cout << "startpos: " << startpos << endl;
				for (int k = 0; k < total_Tiles.size(); k++, startpos++)
				{
					//finish = clock();
					//cout << endl << k << "All time consumption: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;

					if (startpos%total_Tiles.size() == pt.wg[posx][posy])
						continue;
					Tile tt = total_Tiles[startpos%total_Tiles.size()];
					int kk = startpos%total_Tiles.size();

					if (abs(tt.black_pic*1.0 / area - density_in[posx*size + posy]) > thres)
						continue;

					//int temp_dn = defaultNum(tt, posx, posy, color_id);
					Tile tile = tt;
					int num = 0;
					if (tile_edge_id[kk][0] != color_id[posx*size + posy][0])
						num++;
					if (tile_edge_id[kk][1] != color_id[posx*size + posy][1])
						num++;
					if (tile_edge_id[kk][2] != color_id[posx*size + posy][2])
						num++;
					if (tile_edge_id[kk][3] != color_id[posx*size + posy][3])
						num++;
					int temp_dn = num;

					if (temp_dn < default_num)
					{
						pt.wg[posx][posy] = startpos%total_Tiles.size();
						if (posx > 0)
							color_id[(posx - 1)*size + posy][3] = tt.Bottom.id;
						if (posy > 0)
							color_id[posx*size + posy - 1][2] = tt.Left.id;
						if (posx != size - 1)
							color_id[(posx + 1)*size + posy][1] = tt.Top.id;
						if (posy != size - 1)
							color_id[posx*size + posy + 1][0] = tt.Right.id;
						is_iter.erase(posx*size + posy);
						flag = 1;
						//patch_show.push_back(pt);
						//show_patch(patch_show, Color_, total_Tiles);
						break;
					}
				}
				//finish = clock();
				//cout << endl << "All time consumption3: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;

				if (flag == 0)
					is_iter.insert(posx*size + posy);
			}
			//finish = clock();
			//cout << endl << "All time consumption4: " << (double)(finish - start) / CLOCKS_PER_SEC << " s " << endl;
		}
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				black_n += total_Tiles[pt.wg[i][j]].black_pic;
				double density_e = abs(total_Tiles[pt.wg[i][j]].black_pic*1.0 / area - density_in[i*size + j]);
				if (density_e> inter_error_threshold) big_error++;
				patch_e += density_e;
				image_density.push_back(total_Tiles[pt.wg[i][j]].black_pic*1.0 / area);
				//cout << density_e << " ";
			}
		}
		pt.density = black_n*1.0 / (pow(size*total_Tiles[0].Top.edge_colorScheme.edge_length, 2));
		pt_in = pt;
		//cout << pt_in.M << " " << pt_in.N << endl;
		return big_error;
	}


	int PatchGenerator::defaultNum(Tile tile, int posx, int posy, vector<vector<int> >color_id)
	{
		int num = 0;
		if (tile.Left.id != color_id[posx*size + posy][0])
			num++;
		if (tile.Bottom.id != color_id[posx*size + posy][1])
			num++;
		if (tile.Right.id != color_id[posx*size + posy][2])
			num++;
		if (tile.Top.id != color_id[posx*size + posy][3])
			num++;

		return num;
	}
	bool PatchGenerator::all_edge_match(vector<Tile> total_Tiles, Patch pt, vector<vector<int>> color_id, vector<pair<Point, int>>& num_mismatch)
	{
		num_mismatch.swap(vector<pair<Point, int>>());
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				int num = defaultNum(total_Tiles[pt.wg[i][j]], i, j, color_id);
				num_mismatch.push_back(make_pair(Point(i, j), num));
			}
		}
		sort(num_mismatch, cmp_mismatch_b);
		if (num_mismatch[0].second != 0)
			return false;
		else return true;
	}

	bool PatchGenerator::all_edge_match(vector<vector<int> > tile_edge_id, Patch pt, vector<vector<int> > color_id)
	{
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				//int num = defaultNum(total_Tiles[pt.wg[i][j]], i, j, color_id);
				int num = 0;
				if (tile_edge_id[pt.wg[i][j]][0] != color_id[i*size + j][0])
					num++;
				if (tile_edge_id[pt.wg[i][j]][1] != color_id[i*size + j][1])
					num++;
				if (tile_edge_id[pt.wg[i][j]][2] != color_id[i*size + j][2])
					num++;
				if (tile_edge_id[pt.wg[i][j]][3] != color_id[i*size + j][3])
					num++;

				if (num != 0)
					return false;
			}
		}
		return true;
	}

	void PatchGenerator::internal_tiling_class(int C, vector<Patch>&all_patch, Patch& pt, vector<Tile>total_Tiles, double sig1, double sig2)
	{
		int x = C / size;
		int y = C%size;
		if (C >= size*size)
		{
			pt.density = 0;
			for (int i = 0; i < size; i++)
			{
				for (int j = 0; j < size; j++)
				{
					pt.density += total_Tiles[pt.wg[i][j]].black_pic;
				}
			}
			all_patch.push_back(pt);
			return;
		}
		int ww = -1, ss = -1, nn = -1, ee = -1;
		int st = 0;
		int black_n = 0;
		for (int i = x; i < x + 1; i++)
		{
			for (int j = y; j < y + 1; j++)
			{
				ww = ss = nn = ee = -1;
				if (i == 0)//����
				{
					nn = sq[pt.nn][j];
				}
				if (i == size - 1)
				{
					ss = sq[pt.sn][j];
				}
				if (j == 0)
				{
					ww = sq[pt.wn][i];
				}
				if (j == size - 1)
				{
					ee = sq[pt.en][i];
				}
				if (i == 0 && j == 0)
				{
					vector<int> choose_pos = total_Tiles[0].match_tile_with_constrain_vector(total_Tiles, st, -1, ww, ee, nn, ss, sig1, sig2);
					for (int k = 0; k < choose_pos.size(); k++)
					{
						if (k > 5)
							break;
						pt.wg[i][j] = choose_pos[k];
						//pt.density += total_Tiles[pt.wg[i][j]].black_pic;
						internal_tiling_class(C + 1, all_patch, pt, total_Tiles, sig1, sig2);
					}
				}
				else if (i == 0 && j != 0)
				{
					vector<int> choose_pos = total_Tiles[pt.wg[i][j - 1]].match_tile_with_constrain_vector(total_Tiles, st, RightLeft, ww, ee, nn, ss, sig1, sig2);
					for (int k = 0; k < choose_pos.size(); k++)
					{
						if (k > 5)
							break;
						pt.wg[i][j] = choose_pos[k];
						//pt.density += total_Tiles[pt.wg[i][j]].black_pic;
						internal_tiling_class(C + 1, all_patch, pt, total_Tiles, sig1, sig2);
					}
				}
				else if (i != 0 && j == 0)
				{
					vector<int> choose_pos = total_Tiles[pt.wg[i - 1][j]].match_tile_with_constrain_vector(total_Tiles, st, BottomTop, ww, ee, nn, ss, sig1, sig2);
					for (int k = 0; k < choose_pos.size(); k++)
					{
						if (k > 5)
							break;
						pt.wg[i][j] = choose_pos[k];
						//pt.density += total_Tiles[pt.wg[i][j]].black_pic;
						internal_tiling_class(C + 1, all_patch, pt, total_Tiles, sig1, sig2);
					}
				}
				else
				{
					double min_e = 10000;
					vector<int> final_;
					for (int f_num = 0; f_num < total_Tiles.size(); f_num++)
					{
						if (ww != -1)
						{
							if (total_Tiles[f_num].Left.edge_colorScheme.id != ww)
								continue;
						}
						if (ee != -1)
						{
							if (total_Tiles[f_num].Right.edge_colorScheme.id != ee)
								continue;
						}
						if (ss != -1)
						{
							if (total_Tiles[f_num].Top.edge_colorScheme.id != ss)
								continue;
						}
						if (nn != -1)
						{
							if (total_Tiles[f_num].Bottom.edge_colorScheme.id != nn)
								continue;
						}


						/*if (total_Tiles[f_num].Left.edge_colorScheme.Sigma<min(sig1,sig2) || total_Tiles[f_num].Left.edge_colorScheme.Sigma>max(sig1,sig2))
						continue;
						if (total_Tiles[f_num].Bottom.edge_colorScheme.Sigma<min(sig1, sig2) || total_Tiles[f_num].Bottom.edge_colorScheme.Sigma>max(sig1, sig2))
						continue;
						if (ee == -1 && (total_Tiles[f_num].Right.edge_colorScheme.Sigma<min(sig1, sig2) - 0.01 || total_Tiles[f_num].Right.edge_colorScheme.Sigma>max(sig1, sig2) + 0.01))
						continue;
						if (ss == -1 && (total_Tiles[f_num].Top.edge_colorScheme.Sigma<min(sig1, sig2) - 0.01 || total_Tiles[f_num].Top.edge_colorScheme.Sigma>max(sig1, sig2) + 0.01))
						continue;*/


						double error_ = total_Tiles[pt.wg[i - 1][j]].Top.compare_edge_with(total_Tiles[f_num].Bottom);
						error_ += total_Tiles[pt.wg[i][j - 1]].Right.compare_edge_with(total_Tiles[f_num].Left);
						if (error_ <= min_e)
						{
							if (min_e - error_ > 0.001)
							{
								final_.swap(vector<int>());
								min_e = error_;
								//min_index = i;
								final_.push_back(f_num);
							}
							else
							{
								final_.push_back(f_num);
							}
						}
					}
					//srand((unsigned)time(NULL));
					for (int k = 0; k < final_.size(); k++)
					{
						if (k > 5)
							break;
						pt.wg[i][j] = final_[k];
						//pt.density += total_Tiles[pt.wg[i][j]].black_pic;
						internal_tiling_class(C + 1, all_patch, pt, total_Tiles, sig1, sig2);
					}
				}
			}
		}
	}

	void PatchGenerator::draw_patch(vector<CS> Color_, vector<Tile> total_Tiles)
	{
		Patch pt;
		Mat show = Mat(1500, 3800, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(1500, 3800, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 10;
		int _0y = 10;
		int l = 50;
		int length_t = tile_edge_length;
		for (int i = 0; i < patch.size(); i++)
		{
			int ii = i % 8;
			int _0xx = _0x + ii*length_t*size + ii*l;
			int _0yy = _0y + (i / 8)*length_t*size + (i / 8)*l;
			pt = patch[i];
			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					R_Edge test1, test2, test3, test4;
					if (k == 0)
					{
						//w
						test1.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + k * 110, _0y + 100 * (j + 1) + j * 10), Color_[sq[pt.wn][j]]);
						test1.draw_edge(show1);
					}
					if (k == size - 1)
					{
						//e
						test2.set_parameters(Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + 100 * (j + 1) + j * 10), Color_[sq[pt.en][j]]);
						test2.draw_edge(show1);
					}
					if (j == 0)
					{
						//n
						test3.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + j * 110), Color_[sq[pt.nn][k]]);
						test3.draw_edge(show1);
					}
					if (j == size - 1)
					{
						//s
						test4.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + 110 * (j + 1)), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + 110 * (j + 1)), Color_[sq[pt.sn][k]]);
						test4.draw_edge(show1);
					}

				}
			}

			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
					total_Tiles[pt.wg[j][k]].draw_Tile(show);
					//Point2f shift = Point2f(-9 * j, 9 * i);
					total_Tiles[pt.wg[j][k]].draw_tileConts(show);
					cout << pt.wg[j][k] << " ";
					//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
				}
				cout << endl;
			}
		}
		imshow("patch", show);
		imwrite("patch.png", show);
		//imshow("edge", show1);
	}
	int PatchGenerator::draw_patch(int choice, int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show, vector<pair<double, int> >&txt)		//choice==1:ֻ������; =2:ֻ�����ݲ������Ϣ
	{
		int p_scale = size2scale[size] - 1;
		//cout << "size: " << size << "  p_scale:" << p_scale << endl;
		//ͳ����ת��ʹ�ô���
		class_id_time.clear();
		id_classID.clear();
		for (int i = 0; i < patch.size(); i++)
		{
			Patch pt = patch[i];
			if (pt.class_id == -1)
				continue;
			if (class_id_time.count(pt.class_id) == 0)
			{
				class_id_time[pt.class_id] = pt.used_time;
			}
			else
			{
				class_id_time[pt.class_id] += pt.used_time;
			}
			id_classID[patch[i].id] = patch[i].class_id;
		}
		
		//if (choice != 2)
		
		sort(patch.begin(), patch.end(), cmp_patch_rotate); // ����class_id����
		if (choice == 3 )
		{
			sort(patch.begin(), patch.end(), cmp_patch);  // ����density����
		}

		Patch pt;
		double max_d = -1, min_d = 1000;
		int _0x = 10 + x;
		int _0y = 10 + y;
		cout << "choice " << choice<<"  _0x: " << _0x << "  " << _0y << endl;
		int l = tile_edge_length + 25 + size*10;
		int length_t = tile_edge_length;
		int used_patch = 0;
		set<int> class_rotate_number;
		int rotate_flag = 0;
		ofstream outfile(result_num, ios::app);
		int count = 0;
		cout << "The number of this scale's patch: " << patch.size() << endl;
		int cnt_rotate = -1;
		int not_rotate_cnt = -1;
		for (int i = 0; i < patch.size(); i++)
		{
			/*if (choice == 1 && patch[i].used_time == 0)
			continue;*/
			if (patch[i].class_id == -1)
				continue;
			if (patch[i].used_time != 0) used_patch++;
			rotate_flag = 1;
			int patch_taotal_times = class_id_time[patch[i].class_id];
			if (patch_taotal_times != 0 && class_rotate_number.count(patch[i].class_id) == 0)
			{
				not_rotate_cnt++;
			}
			else
				rotate_flag = 0;
			double dd = 0;
			int ii = not_rotate_cnt % each_row_num[p_scale];
			int _0xx = _0x + ii*(length_t*size + l);
			int _0yy = _0y + (not_rotate_cnt / each_row_num[p_scale])*(length_t*size + l);

			pt = patch[i];
			
			if (rotate_flag != 0 && patch_taotal_times != 0)
			{
				for (int j = 0; j < size; j++)
				{
					for (int k = 0; k < size; k++)
					{
						total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
						total_Tiles[pt.wg[j][k]].draw_Tile(show);
						//Point2f shift = Point2f(-9 * j, 9 * i);
						total_Tiles[pt.wg[j][k]].draw_tileConts(show);
						dd += total_Tiles[pt.wg[j][k]].black_pic*1.0 / pow(Color_[0].edge_length, 2);
						//cout << total_Tiles[pt.wg[j][k]].black_pic*1.0 / pow(Color_[0].edge_length, 2) << " ";
						//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
					}
					//cout << endl;
				}
				//putText(show, to_string(dd / size / size), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 15), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);
				//putText(show, to_string(patch[i].density) + "  " + to_string(patch[i].class_id) + "  " + to_string(i), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 15), FONT_HERSHEY_SIMPLEX, 0.75, Scalar(0, 0, 0), 1.8);
				//putText(show, to_string(patch[i].used_time), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);

				int density_int = patch[i].density * 10000;
				putText(show, "0." + to_string(density_int), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);
				putText(show, to_string(class_id_time[patch[i].class_id]), Point2f(_0xx + 110 + p_scale*20, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);
				putText(show, to_string(id_classID[patch[i].id]), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 70), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);
				txt.push_back(make_pair(dd / size / size, patch[i].used_time));
				max_d = max(max_d, dd);
				min_d = min(min_d, dd);
				//cout << i << " " << dd << endl;
				class_rotate_number.insert(patch[i].class_id);
				if (choice == 1 && patch_taotal_times != 0)
				{
					cout << "(class,times):" << patch[i].class_id << " " << patch_taotal_times << endl;
					outfile << "(class,times):" << patch[i].class_id << " " << patch_taotal_times << endl;
					count += patch_taotal_times;
					/*if (i != 0 && patch[i].class_id == patch[i - 1].class_id)
						cout << "repeat" << endl;*/
				}
			}
			//cout <<"not_rotate_cnt: "<< not_rotate_cnt << endl;
			
		}
		cout << "min_d: " << min_d <<"  "<<max_d<< "  den: " << min_d / (size*size) << " used_number: "<<used_number<<endl;
		if (choice == 1)
		{
			if (max_d > -1 && min_d < 1000)
			{
				cout << size << " size has density range (" << min_d / (size*size) << ", " << max_d / (size*size) << ")" << endl;
				outfile << size << " size has density range (" << min_d / (size*size) << ", " << max_d / (size*size) << ")" << endl;
			}
			used_number = count;
			cout << used_patch << " patch (" << class_rotate_number.size() << " rotate class) are used for " << count << " total number " << endl;
			outfile << used_patch << " patch (" << class_rotate_number.size()<<" rotate class) are used for " << count << " total number " << endl;
		}
		outfile.close();
		return class_rotate_number.size();
	}

	void PatchGenerator::show_patch(vector<Patch> patch_show, vector<double> patch_e, vector<CS> Color_, vector<Tile> total_Tiles, string name)
	{
		Patch pt;
		Mat show = Mat(5500, 6800, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(5500, 6800, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 10;
		int _0y = 10;
		int l = 50;
		int length_t = 75;
		for (int i = 0; i < patch_show.size(); i++)
		{
			int ii = i % 12;
			int _0xx = _0x + ii*length_t*size + 2*ii*l;
			int _0yy = _0y + (i / 12)*length_t*size + 4* (i / 12)*l;
			pt = patch_show[i];
			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					R_Edge test1, test2, test3, test4;
					if (k == 0)
					{
						//w
						test1.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + k * 110, _0y + 100 * (j + 1) + j * 10), Color_[sq[pt.wn][j]]);
						test1.draw_edge(show1);
					}
					if (k == size - 1)
					{
						//e
						test2.set_parameters(Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + 100 * (j + 1) + j * 10), Color_[sq[pt.en][j]]);
						test2.draw_edge(show1);
					}
					if (j == 0)
					{
						//n
						test3.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + j * 110), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + j * 110), Color_[sq[pt.nn][k]]);
						test3.draw_edge(show1);
					}
					if (j == size - 1)
					{
						//s
						test4.set_parameters(Point2f(i * 220 + i*l + _0x + k * 110, _0y + 110 * (j + 1)), Point2f(i * 220 + i*l + _0x + (k + 1) * 110, _0y + 110 * (j + 1)), Color_[sq[pt.sn][k]]);
						test4.draw_edge(show1);
					}

				}
			}

			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
					total_Tiles[pt.wg[j][k]].draw_Tile(show);
					//Point2f shift = Point2f(-9 * j, 9 * i);
					total_Tiles[pt.wg[j][k]].draw_tileConts(show);
					//cout << pt.wg[j][k] << " ";
					//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
				}
				//cout << endl;
			}
			string text = to_string(i) + "  den:" + to_string(patch_e[i]/size/size);
			putText(show, text, Point2f(_0xx, _0yy + size*(length_t + 10) + 35), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);

		}
		//imshow("patch", show);
		imwrite(result_path + name + ".png", show);
		imwrite(result_path + name + "_edge.png", show1);
	}

	void PatchGenerator::draw_patch_initial(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show, Mat &show1, vector<pair<double, int> >&txt) //initial:����+����;
	{
		int p_scale = size2scale[size] - 1;
		Patch pt;
		double max_d = -1, min_d = 1000;
		int _0x = 10 + x;
		int _0y = 10 + y;
		int l = 95 + size * 10;
		int length_t = tile_edge_length;
		int used_patch = 0;
		cout << "The number of this scale's patch: " << patch.size() << endl;
		int p_classid = 0;
		vector<int>class_flag(total_Tiles.size(), 0);
		cout << patch.size() << endl;
		for (int i = 0; i < patch.size(); i++)
		{
			//cout << "patch[i].class_id: " << patch[i].class_id << "  " << p_classid << endl;
			if (class_flag[patch[i].class_id] != 0) continue;
			class_flag[patch[i].class_id] = 1;
			p_classid++;
			/*if (choice == 1 && patch[i].used_time == 0)
			continue;*/
			int ii = (p_classid - 1) % each_row_num[p_scale];
			int _0xx = _0x + ii*(length_t*size + l);
			int _0yy = _0y + ((p_classid - 1) / each_row_num[p_scale])*(length_t*size + l);
			//cout << _0xx << "  " << _0yy << " " << sq.size()<<endl;
			pt = patch[i];
			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					R_Edge test1, test2, test3, test4;
					if (k == 0)
					{
						//w
						test1.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10), _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.wn][j]]);
						test1.draw_edge(show1);
					}
					if (k == size - 1)
					{
						//e
						test2.set_parameters(Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.en][j]]);
						test2.draw_edge(show1);
					}
					if (j == 0)
					{
						//n
						test3.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + j * (length_t + 10)), Color_[sq[pt.nn][k]]);
						test3.draw_edge(show1);
					}
					if (j == size - 1)
					{
						//s
						test4.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + (length_t + 10) * j + length_t), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.sn][k]]);
						test4.draw_edge(show1);
					}

				}
			}
			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
					total_Tiles[pt.wg[j][k]].draw_Tile(show);
					//Point2f shift = Point2f(-9 * j, 9 * i);
					//total_Tiles[pt.wg[j][k]].draw_tileConts(show);
					//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
				}
			}
			stringstream ss;
			ss << setiosflags(ios::fixed) << setprecision(4) << patch[i].density << endl;
			string x_value_s;
			ss >> x_value_s;
			putText(show, x_value_s, Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);
			putText(show, to_string(patch[i].class_id), Point2f(_0xx + 100 + size * 20, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);
			//putText(show, to_string(patch[i].used_time), Point2f(_0xx + 160, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 1.3, Scalar(0, 0, 0), 2);
			txt.push_back(make_pair(patch[i].density, patch[i].used_time));
			max_d = max(max_d, patch[i].density);
			min_d = min(min_d, patch[i].density);
			//cout << i << " " << dd << endl;
		}
		cout << "density:" << size << " " << min_d  << " " << max_d  << endl;
	}

	int PatchGenerator::draw_patch_order(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show)//��ʹ�ô�������patch set���
	{
		int p_scale = size2scale[size] - 1;
		//ͳ����ת��ʹ�ô���
		class_id_time.clear();
		for (int i = 0; i < patch.size(); i++)
		{
			Patch pt = patch[i];
			if (pt.class_id == -1)
				continue;
			if (class_id_time.count(pt.class_id) == 0)
			{
				class_id_time[pt.class_id] = pt.used_time;
			}
			else
			{
				class_id_time[pt.class_id] += pt.used_time;
			}
		}
		vector<pair<int, int>> cidVec;
		for (map<int, int>::iterator curr = class_id_time.begin(); curr != class_id_time.end(); curr++)
		{
			if (curr->second>0)
				cidVec.push_back(make_pair(curr->first, curr->second));
		}
			
		sort(cidVec.begin(), cidVec.end(), cmp_pair_sec);
		sort(patch.begin(), patch.end(), cmp_patch_rotate); // ����class_id����

		int cidsize = cidVec.size();
		//cout << "class_id used times vector: " << cidsize << endl;
		for (int i = 0; i < cidsize; i++)
		{
			int cur_cid = cidVec[i].first;
			int index_p = -1;
			for (int t = 0; t < patch.size(); t++)
			{
				if (patch[t].class_id != cur_cid) continue;
				index_p = t;
			}
			Patch pt = patch[index_p];
			int l = 95 + size * 10;
			int ii = i % each_row_num[p_scale];
			int _0xx = 10 + x + ii*(tile_edge_length*size + l);
			int _0yy = 10 + y + (i / each_row_num[p_scale])*(tile_edge_length*size + l);

			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(tile_edge_length + 10), _0yy + (j + 1)*(tile_edge_length + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
					total_Tiles[pt.wg[j][k]].draw_Tile(show);
					//Point2f shift = Point2f(-9 * j, 9 * i);
					total_Tiles[pt.wg[j][k]].draw_tileConts(show);
				}
				//cout << endl;
			}
			int density_int = pt.density * 10000;
			putText(show, "0." + to_string(density_int), Point2f(_0xx, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);
			putText(show, to_string(cidVec[i].second), Point2f(_0xx + 110 + p_scale*20, _0yy + size*(Color_[0].edge_length + 10) + 35), FONT_HERSHEY_SIMPLEX, 0.9, Scalar(0, 0, 0), 2);

		}
		return cidsize;

	}


	void PatchGenerator::draw_result(vector<CS> Color_, vector<Tile> total_Tiles, int M, int N)
	{
		cout << "draw tiling" << endl;
		Patch pt;
		Mat show = Mat(4000, 4000, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(4000, 4000, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 10;
		int _0y = 10;
		int l = 20;
		int length_t = tile_edge_length;
		for (int i = 0; i < N; i++)//Ϊ�˷��㣬һ��һ�е����
		{
			for (int j = 0; j < M; j++)
			{
				pt = patch[tiling_n[j][i]];
				//cout << tiling_n[j][i] << " ";
				cout << i << "," << j << ":" << pt.wn << " " << pt.en << " " << pt.nn << " " << pt.sn << endl;
				int _0xx = _0x + i*length_t*size + i*l;
				int _0yy = _0y + j*length_t*size + j*l;
				int _0xxx = _0x + i*length_t*size;
				int _0yyy = _0y + j*length_t*size;
				//R_Edge test1, test2, test3, test4;
				////w
				//test1.set_parameters(Point2f(i * 100 + i*l + _0x, _0y + j * 100 + j*l), Point2f(i * 100 + i*l + _0x, _0y + (j + 1) * 100 + j*l), Color_[pt.wn]);
				//test1.draw_edge(show);
				////e
				//test2.set_parameters(Point2f((i + 1) * 100 + i*l + _0x, _0y + j * 100 + j*l), Point2f((i + 1) * 100 + i*l + _0x, _0y + (j + 1) * 100 + j*l), Color_[pt.en]);
				//test2.draw_edge(show);
				////n
				//test3.set_parameters(Point2f(i * 100 + i*l + _0x, _0y + j * 100 + j*l), Point2f((i + 1) * 100 + i*l + _0x, _0y + j * 100 + j*l), Color_[pt.nn]);
				//test3.draw_edge(show);
				////s
				//test4.set_parameters(Point2f(i * 100 + i*l + _0x, _0y + (j + 1) * 100 + j*l), Point2f((i + 1) * 100 + i*l + _0x, _0y + (j + 1) * 100 + j*l), Color_[pt.sn]);
				//test4.draw_edge(show);

				for (int jj = 0; jj < size; jj++)
				{
					for (int k = 0; k < size; k++)
					{
						total_Tiles[pt.wg[jj][k]].change_position(Point2f(_0xx + k*(length_t + 5), _0yy + (jj + 1)*(length_t + 5)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
						total_Tiles[pt.wg[jj][k]].draw_Tile(show);
						total_Tiles[pt.wg[jj][k]].draw_tileConts(show);

						total_Tiles[pt.wg[jj][k]].change_position(Point2f(_0xxx + k*(length_t + 0), _0yyy + (jj + 1)*(length_t + 0)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
						total_Tiles[pt.wg[jj][k]].draw_tileConts(show1);
						//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
					}
				}
			}
			//cout << endl;
		}
		int b_pix = 0, all_pix = 0;
		int b1_pix = 0, all1_pix = 0, b2_pix = 0, all2_pix = 0, b3_pix = 0, all3_pix = 0, b4_pix = 0, all4_pix = 0;
		for (int i = _0y; i < _0y + N*length_t*size; i++)
		{
			for (int j = _0x; j < _0x + M*length_t*size; j++)
			{
				cv::Vec3b vec_3 = show1.at<cv::Vec3b>(i, j);
				int a = vec_3[0];
				int b = vec_3[1];
				int c = vec_3[2];
				all_pix++;
				if (j >= _0x &&j < _0x + length_t*size)
				{
					all1_pix++;
					if (!(a == 255 && b == 255 && c == 255))
					{
						b1_pix++;
						b_pix++;
					}
				}
				else if (j >= _0x + length_t*size &&j < _0x + 2 * length_t*size)
				{
					all2_pix++;
					if (!(a == 255 && b == 255 && c == 255))
					{
						b2_pix++;
						b_pix++;
					}
				}
				else if (j >= _0x + 2 * length_t*size &&j < _0x + 3 * length_t*size)
				{
					all3_pix++;
					if (!(a == 255 && b == 255 && c == 255))
					{
						b3_pix++;
						b_pix++;
					}
				}
				else if (j >= _0x + 3 * length_t*size &&j < _0x + 4 * length_t*size)
				{
					all4_pix++;
					if (!(a == 255 && b == 255 && c == 255))
					{
						b4_pix++;
						b_pix++;
					}
				}
			}
		}
		cout << "all density:" << b_pix*1.0 / all_pix << endl;
		cout << "density1:" << b1_pix*1.0 / all1_pix << endl;
		cout << "density2:" << b2_pix*1.0 / all2_pix << endl;
		cout << "density3:" << b3_pix*1.0 / all3_pix << endl;
		cout << "density4:" << b4_pix*1.0 / all4_pix << endl;

		imshow("tiling", show);
		imshow("tiling-1", show1);
		imwrite("tiling.png", show);
		imwrite("tiling-1.png", show1);
	}

	bool PatchGenerator::Single_connnect(Patch pt1, vector<Tile> total_Tiles)
	{
		int ll = tile_edge_length;
		Patch pt = pt1;
		bou_descriptor bd1, bd2;
		vector<Point2f>P, P1;
		vector<bou_descriptor>tile2;

		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				tile2 = total_Tiles[pt.wg[i][j]].all_C;
				int xx = ll*j;
				int yy = ll*i;
				for (int k = 0; k < tile2.size(); k++)
				{
					bd1 = tile2[k];
					for (int kk = 0; kk < 4; kk++)
					{
						for (int kkk = 0; kkk < bd1.C[kk].size(); kkk++)
						{
							bd1.C[kk][kkk].x += xx;
							bd1.C[kk][kkk].y += yy;
						}
					}
					tile2[k] = bd1;
				}
				cal_descriptor(pt1.all_C, tile2, i, j);
			}
		}
		if (pt1.all_C.size() <= 1)
			return true;
		else
			return false;
	}
	int PatchGenerator::Single_connnect_num(Patch pt1, vector<Tile> total_Tiles)
	{
		int ll = tile_edge_length;
		Patch pt = pt1;
		bou_descriptor bd1, bd2;
		vector<Point2f>P, P1;
		vector<bou_descriptor>tile2;

		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				tile2 = total_Tiles[pt1.wg[i][j]].all_C;
				int xx = ll*j;
				int yy = ll*i;
				for (int k = 0; k < tile2.size(); k++)
				{
					bd1 = tile2[k];
					for (int kk = 0; kk < 4; kk++)
					{
						for (int kkk = 0; kkk < bd1.C[kk].size(); kkk++)
						{
							bd1.C[kk][kkk].x += xx;
							bd1.C[kk][kkk].y += yy;
						}
					}
					tile2[k] = bd1;
				}
				cal_descriptor(pt1.all_C, tile2, i, j);
				/*for (int i = 0; i < pt1.all_C.size(); i++)
				{
				bd1 = pt1.all_C[i];
				for (int j = 0; j < 4; j++)
				{
				P = bd1.C[j];
				for (int k = 0; k < P.size(); k++)
				cout << P[k].x << "," << P[k].y << " ";
				cout << endl;
				}
				cout << endl;
				}*/
				//cout << "this tile's contents number: "<< pt1.all_C.size() << endl;
			}
		}
		return pt1.all_C.size();
	}
	void PatchGenerator::draw_single_patch(Mat &show, Point2f shift, int c, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		for (int i = 0; i < size; i++)
		{
			for (int j = 0; j < size; j++)
			{
				//total_Tiles[patch[c].wg[i][j]].draw_tileConts(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length));
				vector<Scalar>colors;
				colors.push_back(Scalar(255, 0, 0));
				colors.push_back(Scalar(0, 255, 0));
				colors.push_back(Scalar(0, 0, 255));
				colors.push_back(Scalar(255, 0, 255));

				/*if (i == 0)
				total_Tiles[patch[c].wg[i][j]].Bottom.draw_edge(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length));
				if (i == size - 1)
				total_Tiles[patch[c].wg[i][j]].Top.draw_edge(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length));
				if (j == 0)
				total_Tiles[patch[c].wg[i][j]].Left.draw_edge(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length));
				if(j==size-1)
				total_Tiles[patch[c].wg[i][j]].Right.draw_edge(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length));*/
				if (i == 0)
					line(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length), shift + Point2f((j + 1)*Color_[0].edge_length, i*Color_[0].edge_length), colors[size - 1], 3);
				if (i == size - 1)
					line(show, shift + Point2f(j*Color_[0].edge_length, (i + 1)*Color_[0].edge_length), shift + Point2f((j + 1)*Color_[0].edge_length, (i + 1)*Color_[0].edge_length), colors[size - 1], 3);
				if (j == 0)
					line(show, shift + Point2f(j*Color_[0].edge_length, i*Color_[0].edge_length), shift + Point2f(j*Color_[0].edge_length, (i + 1)*Color_[0].edge_length), colors[size - 1], 3);
				if (j == size - 1)
					line(show, shift + Point2f((j + 1)*Color_[0].edge_length, i*Color_[0].edge_length), shift + Point2f((j + 1)*Color_[0].edge_length, (i + 1)*Color_[0].edge_length), colors[size - 1], 3);
			}
		}
		//putText(show, to_string(id_classID[c]), shift + Point2f(15, 50), FONT_HERSHEY_SIMPLEX, 1.5, Scalar(0, 0, 255), 2);
	}
	bool PatchGenerator::is_insect(vector<Point2f>P1, vector<Point2f>P2, vector<Point2f>&tp, int flag/*0zuoyou1shangxia*/)
	{
		tp.clear();
		Point2f p1, p2, p3, p4;
		int flg = 0, flg1 = 0;
		for (int i = 0; i < P1.size(); i += 2)
		{
			p1 = P1[i];
			p2 = P1[i + 1];
			flg = 0;
			tp.push_back(p1);
			tp.push_back(p2);
			for (int j = 0; j < P2.size(); j += 2)
			{
				p3 = P2[j];
				p4 = P2[j + 1];
				flg1 = 0;
				if (flag == 0)
				{
					if (min(p1.y, p2.y) >= max(p3.y, p4.y))
					{
						swap(p1, p3);
						swap(p2, p4);
						flg1 = 1;
					}
					if (p1.x == p3.x&&max(p1.y, p2.y) >= min(p3.y, p4.y))
					{
						flg = 1;
						break;
					}
					if (flg1 == 1)
					{
						swap(p1, p3);
						swap(p2, p4);
						flg1 = 0;
					}
				}
				if (flag == 1)
				{
					if (min(p1.x, p2.x) >= max(p3.x, p4.x))
					{
						swap(p1, p3);
						swap(p2, p4);
						flg1 = 1;
					}
					if (p1.y == p3.y&&max(p1.x, p2.x) >= min(p3.x, p4.x))
					{
						flg = 1;
						break;
					}
					if (flg1 == 1)
					{
						swap(p1, p3);
						swap(p2, p4);
						flg1 = 0;
					}
				}
			}
			if (flg == 1)
			{
				tp.pop_back();
				tp.pop_back();
			}
		}
		if (tp.size() != P1.size())
			return true;
		else
			return false;
	}

	void PatchGenerator::cal_descriptor(vector<bou_descriptor>& tile1, vector<bou_descriptor> tile2, int x, int y)
	{
		//bou_descriptor bd1, bd2;
		bou_descriptor bd, bd1, bd2;
		vector<Point2f> tp, tp1, tp2, tp3, tp4;
		vector<bou_descriptor>tt;
		int flg = 0;
		if (x == 0 && y == 0)
		{
			tile1 = tile2;
		}
		else if (x == 0 && y != 0)
		{
			//�ж�1 0
			for (int i = 0; i < tile2.size(); i++)
			{
				bd2 = tile2[i];//ÿ�����
				//����ÿ�������ֻ��Ҫ��0��
				flg = 0;
				for (int j = 0; j < tile1.size(); j++)
				{
					bd1 = tile1[j];
					tp.clear();
					if (is_insect(bd1.C[1], bd2.C[0], tp, 0))//�ж�һ�������ĳ���ڱ��Ƿ��ܺϲ�������δ���ϲ��ĵ�����
					{
						bd1.C[1] = bd2.C[1];
						bd1.C[1].insert(bd1.C[1].end(), tp.begin(), tp.end());
						bd1.C[2].insert(bd1.C[2].end(), bd2.C[2].begin(), bd2.C[2].end());
						bd1.C[3].insert(bd1.C[3].end(), bd2.C[3].begin(), bd2.C[3].end());
						flg = 1;
					}
					tile1[j] = bd1;
				}
				if (flg == 0)
					tt.push_back(bd2);
			}
			tile1.insert(tile1.end(), tt.begin(), tt.end());
		}
		else if (x != 0 && y == 0)
		{
			//�ж�3 2
			for (int i = 0; i < tile2.size(); i++)
			{
				bd2 = tile2[i];//ÿ�����
				//����ÿ�������ֻ��Ҫ��0��
				flg = 0;
				for (int j = 0; j < tile1.size(); j++)
				{
					bd1 = tile1[j];
					tp.clear();
					if (is_insect(bd1.C[3], bd2.C[2], tp, 1))//�ж�һ�������ĳ���ڱ��Ƿ��ܺϲ�������δ���ϲ��ĵ�����
					{
						bd1.C[3] = bd2.C[3];
						bd1.C[3].insert(bd1.C[3].end(), tp.begin(), tp.end());
						bd1.C[0].insert(bd1.C[0].end(), bd2.C[0].begin(), bd2.C[0].end());
						bd1.C[1].insert(bd1.C[1].end(), bd2.C[1].begin(), bd2.C[1].end());
						flg = 1;
					}
					tile1[j] = bd1;
				}
				if (flg == 0)
					tt.push_back(bd2);
			}
			tile1.insert(tile1.end(), tt.begin(), tt.end());
		}
		else
		{
			//�ж�1 0/3 2
			for (int i = 0; i < tile2.size(); i++)
			{
				bd2 = tile2[i];//ÿ�����
				//����ÿ�������ֻ��Ҫ��0��
				flg = 0;
				vector<int>a1, a2;
				for (int j = 0; j < tile1.size(); j++)
				{
					bd1 = tile1[j];
					tp.clear();
					//tp1.clear();
					//tp2.clear();
					if (is_insect(bd1.C[1], bd2.C[0], tp3, 0))//�ж�һ�������ĳ���ڱ��Ƿ��ܺϲ�������δ���ϲ��ĵ�����
					{
						a1.push_back(j);
						tp1 = tp3;
					}
					if (is_insect(bd1.C[3], bd2.C[2], tp4, 1))//�ж�һ�������ĳ���ڱ��Ƿ��ܺϲ�������δ���ϲ��ĵ�����
					{
						a2.push_back(j);
						tp2 = tp4;
					}
				}
				if (a1.size() == 0 && a2.size() == 0)
					tt.push_back(bd2);
				else if (a1.size() != 0 && a2.size() == 0)
				{
					bd1 = tile1[a1[0]];//!!!
					bd1.C[1] = bd2.C[1];
					bd1.C[1].insert(bd1.C[1].end(), tp1.begin(), tp1.end());
					//bd1.C[2].insert(bd1.C[2].end(), bd2.C[2].begin(), bd2.C[2].end());
					bd1.C[3].insert(bd1.C[3].end(), bd2.C[3].begin(), bd2.C[3].end());
					tile1[a1[0]] = bd1;
				}
				else if (a2.size() != 0 && a1.size() == 0)
				{
					bd1 = tile1[a2[0]];//!!!
					bd1.C[3] = bd2.C[3];
					bd1.C[3].insert(bd1.C[3].end(), tp2.begin(), tp2.end());
					//bd1.C[0].insert(bd1.C[0].end(), bd2.C[0].begin(), bd2.C[0].end());
					bd1.C[1].insert(bd1.C[1].end(), bd2.C[1].begin(), bd2.C[1].end());
					tile1[a2[0]] = bd1;
				}
				else
				{
					bd1 = tile1[a1[0]];
					bd1.C[1] = bd2.C[1];
					bd1.C[1].insert(bd1.C[1].end(), tp1.begin(), tp1.end());
					//bd1.C[2].insert(bd1.C[2].end(), bd2.C[2].begin(), bd2.C[2].end());
					bd1.C[3].insert(bd1.C[3].end(), bd2.C[3].begin(), bd2.C[3].end());//���߼�©�� Ӧ�ò�Ӱ���� �Ժ���˵

					if (a1[0] != a2[0])
					{
						bd2 = tile1[a2[0]];
						bd1.C[0].insert(bd1.C[0].end(), bd2.C[0].begin(), bd2.C[0].end());
						bd1.C[1].insert(bd1.C[1].end(), bd2.C[1].begin(), bd2.C[1].end());
						bd1.C[2].insert(bd1.C[2].end(), bd2.C[2].begin(), bd2.C[2].end());
						bd1.C[3].insert(bd1.C[3].end(), bd2.C[3].begin(), bd2.C[3].end());//���߼�©�� Ӧ�ò�Ӱ���� �Ժ���˵
					}
					tile1[a1[0]] = bd1;

					if (a1[0] != a2[0])
						tile1.erase(tile1.begin() + a2[0]);;

				}
			}
			tile1.insert(tile1.end(), tt.begin(), tt.end());
			tt.clear();
		}
	}

	bool PatchGenerator::is_adjacent(Patch pt, map<int, int>sq_to_pos)
	{
		set<int> judge;
		judge.insert(sq_to_pos[pt.wn]);
		if (abs(sq_to_pos[pt.nn] - sq_to_pos[pt.wn]) <= 1)
		{
			judge.insert(sq_to_pos[pt.nn]);
		}
		else
			return false;

		if (judge.size() == 1)
		{
			if (abs(sq_to_pos[pt.en] - sq_to_pos[pt.wn]) <= 1)
				judge.insert(sq_to_pos[pt.en]);
			else
				return false;
		}
		else
		{
			if (judge.count(sq_to_pos[pt.en]) == 0)
				return false;
		}

		if (judge.size() == 1)
		{
			if (abs(sq_to_pos[pt.sn] - sq_to_pos[pt.wn]) <= 1)
				judge.insert(sq_to_pos[pt.sn]);
			else
				return false;
		}
		else
		{
			if (judge.count(sq_to_pos[pt.sn]) == 0)
				return false;
		}

		return true;
	}
	void PatchGenerator::draw_patch_Edge(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show1, vector<Patch>patch_temp) //initial:����+����;
	{
		Patch pt;
		double max_d = -1, min_d = 1000;
		int _0x = 10 + x;
		int _0y = 10 + y;
		int l = tile_edge_length;
		int length_t = tile_edge_length;
		int used_patch = 0;
		cout << "The number of this scale's patch: " << patch_temp.size() << endl;
		int p_classid = 0;
		for (int i = 0; i < patch_temp.size(); i++)
		{
			int ii = i % drawp_num_eachRow;
			int _0xx = _0x + ii*(length_t*size + l);
			int _0yy = _0y + (i / drawp_num_eachRow)*(length_t*size + l);

			pt = patch_temp[i];
			for (int j = 0; j < size; j++)
			{
				for (int k = 0; k < size; k++)
				{
					R_Edge test1, test2, test3, test4;
					if (k == 0)
					{
						//w
						test1.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10), _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.wn][j]]);
						test1.draw_edge(show1);
					}
					if (k == size - 1)
					{
						//e
						test2.set_parameters(Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.en][j]]);
						test2.draw_edge(show1);
					}
					if (j == 0)
					{
						//n
						test3.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + j * (length_t + 10)), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + j * (length_t + 10)), Color_[sq[pt.nn][k]]);
						test3.draw_edge(show1);
					}
					if (j == size - 1)
					{
						//s
						test4.set_parameters(Point2f(_0xx + k * (length_t + 10), _0yy + (length_t + 10) * j + length_t), Point2f(_0xx + k * (length_t + 10) + length_t, _0yy + (length_t + 10) * j + length_t), Color_[sq[pt.sn][k]]);
						test4.draw_edge(show1);
					}

				}
			}
			/*for (int j = 0; j < size; j++)
			{
			for (int k = 0; k < size; k++)
			{
			total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
			total_Tiles[pt.wg[j][k]].draw_Tile(show);
			}
			}*/
		}
	}
	int PatchGenerator::find_Patch(int id)
	{
		for (int i = 0; i < patch.size(); i++)
		{
			if (patch[i].id == id)
				return i;
		}
		return -1;
	}
	int PatchGenerator::find_patch_edge(Patch pt)
	{
		for (int i = 0; i < patch.size(); i++)
		{
			Patch pt1 = patch[i];
			if (pt1.wn == pt.wn&&pt1.sn == pt.sn&&pt1.nn == pt.nn&&pt1.en == pt.en)
			{
				return i;
			}
		}
		return -1;
	}
	//--------------------------PatchGenerator------------------------------------------

	
}