#define  _CRT_SECURE_NO_WARNINGS
#include "freeBoundary.h"

//vector<int> patch_size = { 1, 2, 4 };
//int size2scale[5] = { 0, 1, 2, 3, 3 };
//vector<int> patch_boundary_seqnum = { 3, 4, 3 };
//vector<int> dmt_num = { 0, 0, 0 };
//int each_row_num[3] = { 2 * drawp_num_eachRow, 1.5*drawp_num_eachRow, drawp_num_eachRow };
//map<int, int>rotate_link;//��¼ÿ��tile��ʱ����ת90�ȵ���һ��tile

vector<int> patch_size = { 1, 2, 4, 8};
vector<int> size2scale = { 0, 1, 2, 3, 3, 4, 4, 4, 4 };
vector<int> patch_boundary_seqnum = { 3, 3, 3, 3};
vector<int> dmt_num = { 0, 0, 0, 0 };
vector<int> each_row_num = { 2 * drawp_num_eachRow, drawp_num_eachRow * 3 / 2, drawp_num_eachRow, drawp_num_eachRow / 2 };
map<int, int>rotate_link;//��¼ÿ��tile��ʱ����ת90�ȵ���һ��tile

int first_show = 1;

namespace FreeBound{
	   
	//--------------------------Multi_Patch------------------------------------------
	Multi_Patch::Multi_Patch()
	{
		set_density(Input_Path);
	}
	Multi_Patch::Multi_Patch(int scale)
	{
		this->scale = scale;
		for (int i = 0; i < scale; i++)
		{
			PatchGenerator pg(3, 3, patch_size[i]);
			patch_g.push_back(pg);
		}
		set_density(Input_Path);
	}
	Multi_Patch::Multi_Patch(int c, int x, int y, int z)
	{
		patch_g[c].size = z;
		patch_g[c].x_num = x;
		patch_g[c].y_num = y;
		set_density(Input_Path);
	}

	Multi_Patch::Multi_Patch(int scale, int color_num)
	{
		this->scale = scale;
		for (int i = 0; i < scale; i++)
		{
			PatchGenerator pg(3, 3, patch_size[i]);
			patch_g.push_back(pg);
			patch_g[i].set_sequence(color_num);
		}
		set_density(Input_Path);
	}

	void Multi_Patch::set_density(string imagepath)  //----lxk
	{
		cout << endl << "-----------------------------------------" << endl
			<< "               Load Image!" << endl
			<< "-----------------------------------------" << endl;

		//Ҫ��������ǲ�����100*100�ĻҶ�ͼ��
		vector<vector<double>> density_all;
		Mat src_gray = imread(imagepath, IMREAD_GRAYSCALE);
		
		//update Image_Width and Image_Height
		Image_Width = src_gray.cols;
		Image_Height = src_gray.rows;
		image_pixel_w = (Image_Width + 10)*tile_edge_length;
		image_pixel_h = (Image_Height + 10)*tile_edge_length;
		M = Image_Height;
		N = Image_Width;

		Mat src_gray1(Image_Height, Image_Width, CV_8UC1, Scalar(255));
		Mat src_gray2(Image_Height, Image_Width , CV_8UC1, Scalar(255));
		if (src_gray.empty())
		{
			cerr << "No image supplied for computing density!" << endl;
			exit(0);
			//return;
		}
		int col = src_gray.cols; //column
		int row = src_gray.rows;
		if (col == Image_Width && row == Image_Height)
			std::cout << "Image col: " << col << "  row: " << row << endl;
		else if (ImageSize < Image_Width || ImageSize < Image_Height)
		{
			std::cout << "Image size error: Exceed the preset value!" << endl;
			return;
		}		
		double Dmax = 0;
		double Dmin = 10000;
		for (int i = 0; i < row; i++)
		{
			vector<double> density_row;
			for (int j = 0; j < col; j++)
			{
				int count_gray = (int)src_gray.at<uchar>(i, j);
				double density = (255.0 - count_gray) / 255;
				//density = density_k * density + density_b; //y=0.6x+d[1]
				density_row.push_back(density);
				if (density > Dmax) Dmax = density;
				if (density < Dmin) Dmin = density;
			}
			density_all.push_back(density_row);
		}
		cout << "The density of original image:" << endl << "Dmax: " << Dmax << endl << "Dmin: " << Dmin << endl;
		//------------------range mapping------------------------------------
		//��[Dmin, Dmax]ӳ�䵽[0.15, 0.85]��,��Ϊpatch���ܶȱ��ﷶΧ��[0.11, 0.87]

		if (range_mapping)
		{
			cout << "Target_max:  " << Target_max << endl << "Target_min:  " << Target_min << endl;
			for (int i = 0; i < row; i++)
			{
				for (int j = 0; j < col; j++)
				{
					double each_v = (Target_max - Target_min) / (Dmax - Dmin);
					//cout << i<<" "<<j<<"  ori den: " << density_all[i][j] << endl;
					density_all[i][j] = (density_all[i][j] - Dmin)*each_v + Target_min;
					//cout << "now den: " << density_all[i][j] << endl;
					double count_gray2 = 255 - density_all[i][j] * 255;
					src_gray1.at<uchar>(i, j) = count_gray2;
				}
			}
			imwrite(result_path+ "Out_mapping.png", src_gray1);
			Dmax = Target_max;
			Dmin = Target_min;
		}

		//-----------------���ܶȽ���ϡ�����----------------------
		if (sparse_sampling)
		{
			int divisor = sample_grad * 100;
			cout << "Sparse sampling gradient:  " << sample_grad << endl;
			for (int i = 0; i < row; i++)
			{
				for (int j = 0; j < col; j++)
				{
					int density = density_all[i][j] * 100;
					int den_samp = (density - (int)(Dmin * 100)) / divisor * divisor + (int)(Dmin * 100);
					int den_samp2 = min(den_samp + divisor, (int)(Dmax * 100));

					if (abs(density - den_samp) > abs(den_samp2 - density))
					{
						density = den_samp2;
					}
					else density = den_samp;

					density_all[i][j] = density / 100.0;

					double count_gray3 = 255 - density_all[i][j] * 255;
					src_gray2.at<uchar>(i, j) = count_gray3;
				}
			}
			imwrite(result_path+ "Out_sparse.png", src_gray2);
		}
		//--------------------------------------------------------------
		density_d = density_all;
		density_d2 = density_all;
		//-----write into txt
		ofstream outfile;
		string NewFileName = result_path+ "New.txt";
		outfile.open(NewFileName, ostream::app);
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
				outfile << density_d[i][j] << ",";
			outfile << endl;
		}
	}

	void Multi_Patch::set_density_txt(string txtpath)  //----lxk 
	{
		//Ҫ��������ǲ�����100*100�ĻҶ�ͼ��
		vector<vector<double>> density_all;
		ifstream in(txtpath);
		string s;
		string delim = ",";
		if (!in.is_open())
		{
			cout << "δ�ɹ����ļ�" << endl;
		}
		while (!in.eof())
		{
			vector<double> res;
			getline(in, s);
			if (in.eof())
				break;
			char * strs = new char[s.length() + 1];
			strcpy(strs, s.c_str());
			char * d = new char[delim.length() + 1];
			strcpy(d, delim.c_str());
			char *p = strtok(strs, d);
			while (p) {
				res.push_back(atof(p)); //����������  
				p = strtok(NULL, d);
			}
			density_all.push_back(res);

		}
		in.close();
		density_d = density_all;

	}

	void Multi_Patch::set_Tms(vector<Tile> total_Tiles, vector<CS> Color_)
	{
		cout << endl << "-----------------------------------------" << endl
			<< "            Compute Tms set!" << endl
			<< "-----------------------------------------" << endl;
		//����1�ٴӸ�����������Ϊ3���õ�1��choose_sq.size,��2���õ���3�ı������У������132˳�򣬵�Ŀǰ��û�з������ã����Ը�һ��֮��˳�����Ϊ321
		set_Tms_scale(1, total_Tiles, Color_);
		for (int i = scale; i > 1; i--)
		{
			set_Tms_scale(i, total_Tiles, Color_);
		}
	}

	void Multi_Patch::set_Tms_scale(int scale_, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		cout << endl << "---------Compute " <<scale_<< " scale Tms set!----------" << endl<<endl;
		int scale_i = scale_ - 1;
		if (scale_ == 1)
		{
			set_Tms_11(patch_boundary_seqnum[0], total_Tiles, Color_);
		}
		if (scale_ == 2)
		{	
			set_Tms_22(patch_boundary_seqnum[scale_i], scale_i, total_Tiles, Color_);//�м�㼶
		}	
		if (scale_ == 3)
		{
			set_Tms_33(patch_boundary_seqnum[scale_i], scale_i, total_Tiles, Color_);//
		}
		if (scale_ == 4)
		{
			set_Tms_44(patch_boundary_seqnum[scale_i], scale_i, total_Tiles, Color_);//��߲㼶
		}
		//add rotate patch
		int pos = patch_g[scale_i].patch.size();
		cout << pos << endl;
		for (int k = 0; k < pos; k++)
		{
			Patch ptt = patch_g[scale_i].patch[k];
			for (int ii = 0; ii < 3; ii++)
			{
				ptt = patch_g[scale_i].add_rotate_patch(ptt, 0);
				patch_g[scale_i].patch.push_back(ptt);
			}
		}
		//cout << patch_g[i].patch.size() << endl;
		sort(patch_g[scale_i].patch.begin(), patch_g[scale_i].patch.end(), cmp_patch_rotate);
		//sort(patch_g[scale_i].patch.begin(), patch_g[scale_i].patch.end(), cmp_patch);
		//give id
		for (int ii = 0; ii < patch_g[scale_i].patch.size(); ii++)
		{
			patch_g[scale_i].patch[ii].id = ii;
		}
	}

	void Multi_Patch::set_Tms_11(int choice_num, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		patch_g[0].size = patch_size[0];
		patch_g[0].set_sequence(Color_.size());
		vector<int> A(choice_num);
		vector<int>temp_A(1);
		int interval = Color_.size() / choice_num + (Color_.size() % choice_num == 0 ? 0 : 1);
		for (int i = 0; i < choice_num; i++)
		{
			A[i] = Color_[i*interval].id;
			temp_A[0] = A[i];
			patch_g[0].choose_sq.push_back(temp_A);
		}
		//patch_g[0].set_patch_density(total_Tiles, Color_, A, 0);
		patch_g[0].x_num = patch_g[0].choose_sq.size();
		patch_g[0].y_num = patch_g[0].choose_sq.size();
		cout << "patch_g[0].choose_sq.size: " << patch_g[0].choose_sq.size() << endl;

		//set patch: boundary sequence of patch
		patch_g[0].set_boundary(A, Color_, total_Tiles);
		cout << "Patches number: " << patch_g[0].patch.size() << endl;

		set_sort_density(1);
		patch_g[0].set_patch_spec_11(total_Tiles, Color_, A, sort_density);

		cout << "patch_g[0].patch: " << patch_g[0].patch.size() << endl;
		sort(patch_g[0].patch.begin(), patch_g[0].patch.end(), cmp_patch);
	

		cout << "Compute 1st Tms over! " << endl;
	}
	void Multi_Patch::set_Tms_22(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		patch_g[scale].size = patch_size[scale];
		patch_g[scale].set_sequence(Color_.size());
		vector<int>temp_A;
		int mapping[10];
		//���ڸ�һ����ұ߽�
		for (int i = 0; i < patch_g[scale + 1].choose_sq.size(); i++)
		{
			vector<int> temp_B = patch_g[scale + 1].choose_sq[i];
			for (int j = scale; j < temp_B.size(); j++)
			{
				temp_A.clear();
				for (int k = scale; k >= 0; k--)
				{
					temp_A.push_back(temp_B[j - k]);
				}
				patch_g[scale].choose_sq.push_back(temp_A);
			}
		}
		//�ҵ���ѡ���е����
		cout << "Compute edges color sequence of 2nd scale patches...... " << endl;
		vector<int> A;
		vector<vector<int> > chooose_sq_t;
		patch_g[scale].find_A(A);
		//cout << "A.size: " << A.size() << endl;
		set<int>cc;
		for (int i = 0; i < A.size(); i++)
			cc.insert(A[i]);
		A.clear();
		for (set<int>::iterator it = cc.begin(); it != cc.end(); it++)
		{
			chooose_sq_t.push_back(patch_g[scale].sq[*it]);
			A.push_back(*it);
		}
		patch_g[scale].choose_sq = chooose_sq_t;
		patch_g[scale].x_num = patch_g[scale].choose_sq.size();
		patch_g[scale].y_num = patch_g[scale].choose_sq.size();
		cout << "patch_g[1].choose_sq.size: " << patch_g[scale].choose_sq.size() << endl;
		//set patch: boundary sequence of patch
		patch_g[scale].set_boundary(A, Color_, total_Tiles);
		cout << "Patches number: " << patch_g[scale].patch.size() << endl;
		
		//set density
		set_sort_density(2);
		//pre_process(patch_size[scale]);
		//patch_g[scale].set_patch(total_Tiles, Color_, A, sort_density);
		patch_g[scale].set_patch_spec(total_Tiles, Color_, A, sort_density);
		cout << "patch_g[2].patch: " << patch_g[scale].patch.size() << endl;
		sort(patch_g[scale].patch.begin(), patch_g[scale].patch.end(), cmp_patch);
		cout << "Compute 2nd Tms over! " << endl;
	}
	void Multi_Patch::set_Tms_33(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		patch_g[scale].x_num = choice_num;
		patch_g[scale].y_num = choice_num;
		patch_g[scale].size = patch_size[scale];
		patch_g[scale].set_sequence(Color_.size());
		vector<int>temp_A;

		//mapping: ��1st��ѡ��IDӳ�䵽��ǰ��, ��color��ɫ��choice_num������ʱ, ��������, �����ѡ�ı����б��1����ȷ����ɫ������
		int mapping[10];
		int shift = 0;
		shift = Color_.size() / patch_g[0].choose_sq.size();
		for (int i = 0; i < Color_.size(); i++)
		{
			mapping[i] = patch_g[0].choose_sq[i / shift][0];
		}
		int edge_s[4] = { 1, 1, 1, 1 };
		for (int i = 0; i < choice_num; i++)
		{
			temp_A.clear(); 
			vector<int>tt;
			if (i == choice_num - 1)
				tt = patch_g[scale].sq[patch_g[scale].sq.size() - 1];
			else if (i == 0)
				tt = patch_g[scale].sq[0];
			else tt = patch_g[scale].sq[edge_s[0] * 27 + edge_s[1] * 9 + edge_s[2] * 3 + edge_s[3]];
			for (int j = 0; j < tt.size(); j++)
			{
				temp_A.push_back(mapping[tt[j]]);
			}
			patch_g[scale].choose_sq.push_back(temp_A);
		}
		cout << "patch_g[3].choose_sq: " << patch_g[scale].choose_sq.size() << endl;
		for (int m = 0; m < patch_g[scale].choose_sq.size(); m++)
			cout << patch_g[scale].choose_sq[m][0] << "  " << patch_g[scale].choose_sq[m][1] << "  " << patch_g[scale].choose_sq[m][2] << "  " << patch_g[scale].choose_sq[m][3] << endl;
		//�ҵ���ѡ���е����
		cout << "Compute edges color sequence of 3rd scale patches...... " << endl;
		vector<int> A;
		patch_g[scale].find_A(A);  //find index in sq of each choose_sq

		//set patch: boundary sequence of patch
		patch_g[scale].set_boundary(A, Color_, total_Tiles);
		cout << "Patches number: " << patch_g[scale].patch.size() << endl;

		//set density
		cout << "Generate 3rd scale patches based on preset uniform density distributions..." << endl;
		set_sort_density(3);

		if (patch_gen_type == 5)
		{
			cout << "Find the most frequent " << topNum_clus << " density distributions of 3rd scale patches..." << endl;
			pre_process(patch_size[scale]);
		}
		cout << "sort_density.size(): " << sort_density.size() << endl;
		cout << "density_situ.size(): " << density_situ.size() << endl;
		/*for (int k = 0; k < sort_density.size(); k++)
		{
			vector<double> den1 = sort_density[k].first;

			if (equal_vec(den1, density_situ[k])) cout << "right!" << endl;
			else cout << "does not match!" << endl;
		}*/
		patch_g[scale].set_patch_spec(total_Tiles, Color_, A, sort_density);
		cout << "patch_g[3].patch: " << patch_g[scale].patch.size() << endl;
		//sort(patch_g[scale].patch.begin(), patch_g[scale].patch.end(), cmp_patch);
		cout << "Compute 3rd Tms over! " << endl;
	}

	void Multi_Patch::set_Tms_44(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		patch_g[scale].x_num = choice_num;
		patch_g[scale].y_num = choice_num;
		patch_g[scale].size = patch_size[scale];
		patch_g[scale].set_sequence(Color_.size());
		vector<int>temp_A;

		//��1st��ѡ��IDӳ�䵽��ǰ��, ��color��ɫ��choice_num������ʱ, �������ã������ѡ�ı����б����ȷ����ɫ������
		int mapping[10];
		int shift = 0;
		shift = Color_.size() / patch_g[0].choose_sq.size();
		for (int i = 0; i < Color_.size(); i++)
		{
			mapping[i] = patch_g[0].choose_sq[i / shift][0];
		}
		int edge_s[8] = { 1, 1, 1, 1, 1, 1, 1, 1 };
		cout << "patch_g[4].sq.size(): " << patch_g[scale].sq.size() << endl;
		for (int i = 0; i < choice_num; i++)
		{
			temp_A.clear();
			vector<int>tt;
			if (i == choice_num - 1)
				tt = patch_g[scale].sq[patch_g[scale].sq.size() - 1];
			else if (i == 0)
				tt = patch_g[scale].sq[0];
			else tt = patch_g[scale].sq[edge_s[7] * pow(3, 7) + edge_s[6] * pow(3, 6) + edge_s[5] * pow(3, 5) + edge_s[4] * pow(3, 4) + edge_s[3] * 27 + edge_s[2] * 9 + edge_s[1] * 3 + edge_s[0]];
			for (int j = 0; j < tt.size(); j++)
			{
				temp_A.push_back(mapping[tt[j]]);
			}
			patch_g[scale].choose_sq.push_back(temp_A);
		}
		cout << "patch_g[4].choose_sq: " << patch_g[scale].choose_sq.size() << endl;
		for (int m = 0; m < patch_g[scale].choose_sq.size(); m++)
			for (int n = 0; n < patch_g[scale].choose_sq[m].size();n++)
				cout << patch_g[scale].choose_sq[m][n] << "  ";

		//�ҵ���ѡ���е����
		cout << endl<<"Compute edges color sequence of 4th scale patches! " << endl;
		vector<int> A;
		patch_g[scale].find_A(A);  //find index of chosen boundary sequence
		for (int m = 0; m < A.size(); m++)
			cout << "A: " << A[m] << endl;
		//set patch

		cout << "Generate 4th scale patches based on preset uniform density distributions!" << endl;
		set_sort_density(4);

		if (patch_gen_type == 5)
		{
			cout << "Find the most frequent " << topNum_clus << " density distributions of 3rd scale patches!" << endl;
			pre_process(patch_size[scale]);
		}
		cout << "sort_density.size(): " << sort_density.size() << endl;
		cout << "density_situ.size(): " << density_situ.size() << endl;
		/*for (int k = 0; k < sort_density.size(); k++)
		{
		vector<double> den1 = sort_density[k].first;
		if (equal_vec(den1, density_situ[k])) cout << "right!" << endl;
		else cout << "does not match!" << endl;
		}*/
		patch_g[scale].set_patch_spec(total_Tiles, Color_, A, sort_density);
		cout << "patch_g[3].patch: " << patch_g[scale].patch.size() << endl;
		sort(patch_g[scale].patch.begin(), patch_g[scale].patch.end(), cmp_patch);
		cout << "Compute 3rd Tms over! " << endl;
	}

	void Multi_Patch::draw_all_Patch(int choice, vector<Tile> total_Tiles, vector<CS> Color_, string name)
	{
		int iwidth = drawp_num_eachRow*(6 * tile_edge_length);
		Mat show = Mat(10500, iwidth, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(10500, iwidth, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 0, _0y = 0;
		vector<pair<double, int> >txt;
		int border = 50;
		//ofstream outfile(name);
		//outfile.close();
		if (choice == 0)
		{
			cout << endl << "Show all patches!" << endl;
			//cout << "scale: "<<scale <<"  error: " <<total_error<<endl;
			for (int i = 0; i < scale; i++)
			{
				txt.clear();
				patch_g[i].draw_patch_initial(_0x, _0y, Color_, total_Tiles, show, show1, txt);
				cout << "patch_g[i].total_classes_num: " << patch_g[i].total_classes_num << endl;
				_0y += (border + Color_[0].edge_length) * patch_size[i] * (patch_g[i].total_classes_num / each_row_num[i] + 1) + 150;
				write_text(name, i + 1, txt);
				cout << i + 1 << " scale has: " << patch_g[i].patch.size() <<" patches"<< endl << endl;
			}
			imwrite(result_path+ "all_patch.png", show);
			imwrite(result_path+ "all_edges.png", show1);
		}
		else if (choice == 1 || choice == 2)
		{
			total_type_num = 0;
			total_type_times = 0;
			vector<int> used_type_each_scale;
			for (int i = 0; i < scale; i++)
			{
				txt.clear();
				int rota_class_num = patch_g[i].draw_patch(choice, _0x, _0y, Color_, total_Tiles, show, txt);
				_0y += (border + Color_[0].edge_length) *  patch_size[i] * (rota_class_num / each_row_num[i] + 1) + 150;
				used_type_each_scale.push_back(rota_class_num);
				total_type_num += rota_class_num;
				write_text(name, i + 1, txt);
				cout << i + 1 << " scale patches usage: " << patch_g[i].used_number << "/" << patch_g[i].patch.size() << endl << endl;
			}
			imwrite(result_path+ "used_patch.png", show);
			if (choice == 1)
			{
				ofstream outfile(result_num, ios::app);
				outfile << endl << endl << "Total usage: " << endl;
				for (int used_i = 0; used_i < scale; used_i++)
				{
					outfile << used_type_each_scale[used_i] << "  " << patch_size[used_i] << "*" << patch_size[used_i] << "  " << patch_g[used_i].used_number << endl;
					total_type_times += patch_g[used_i].used_number;
				}
				outfile << "Totally use " << total_type_num << " rotate classes for " << total_type_times << " tiles!" << endl;
				outfile << "Total error: " << total_error << endl << "Average error:  " << total_error/(M*N) << endl;
			}
		}
		else if (choice == 3)// �����ܶ���
		{
			for (int i = 0; i < scale; i++)
			{
				int rota_class_num = patch_g[i].draw_patch(choice, _0x, _0y, Color_, total_Tiles, show, txt);
				_0y += (border + Color_[0].edge_length)* patch_size[i] * (rota_class_num / each_row_num[i] + 1) + 150;
			}
			imwrite(result_path+ "used_patch_density_order.png", show);
		}
		else if (choice == 4) //����ʹ�ô�����
		{
			for (int i = 0; i < scale; i++)
			{
				int rota_class_num = patch_g[i].draw_patch_order(_0x, _0y, Color_, total_Tiles, show);
				_0y += (border + Color_[0].edge_length)*patch_size[i] * (rota_class_num / each_row_num[i] + 1) + 150;
			}
			imwrite(result_path+ "used_patch_order.png", show);
		}
	}

	void Multi_Patch::draw_used_Patch(int time, int p_scale, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		int width = drawp_num_eachRow*(6 * tile_edge_length);
		string path = result_path+ "the " + to_string(time) + " time.png";
		Mat show = imread(path);
		if (show.empty()) show = Mat(9000, width, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 20, _0y = 100;
		vector<pair<double, int> >txt;
		cout << "Show the " << p_scale<<" scale patches in the " << time << " times' iteration!" << endl;
		for (int i = 1; i < p_scale; i++)
		{
			int each_row = each_row_num[i];
			_0y += (tile_edge_length + Color_[0].edge_length)* (i + 1) *(patch_g[i].patch.size() / 4 / each_row + 1) + 400;
			//cout << i << "  " << each_row << "  " << _0y << "  " << endl;
		}
		patch_g[p_scale].draw_patch(1, _0x, _0y, Color_, total_Tiles, show, txt);

		//imshow("patch", show);

		imwrite(path, show);
	}

	void Multi_Patch::draw_each_Patch(vector<Tile> total_Tiles, vector<CS> Color_, string folder_path)
	{
		cout << "Generate patch images, svgs and models..." << endl;
		if (_access(folder_path.c_str(), 0) == -1)	
			_mkdir(folder_path.c_str());
		string patch_usage = folder_path + "patch_usage.txt";
		double zoom_scale = 2;
		for (int i = 0; i < scale; i++)
		{
			int pgi_size = patch_g[i].patch.size();
			cout << i << " scale has " << pgi_size << " patches!" << endl;
			int image_size = zoom_scale * tile_edge_length * patch_size[i] + 80;
			//ͳ����ת��ʹ�ô���
			map<int, int>map_used_time;
			for (int j = 0; j < pgi_size; j++)
			{
				Patch pt = patch_g[i].patch[j];
				if (pt.class_id == -1)
					continue;
				if (map_used_time.count(pt.class_id) == 0)
				{
					map_used_time[pt.class_id] = pt.used_time;
				}
				else
				{
					map_used_time[pt.class_id] += pt.used_time;
				}
			}
			cout << "used types: " << map_used_time.size() << endl;
			//int index_map = 0;
			for (map<int, int>::iterator it = map_used_time.begin(); it != map_used_time.end(); ++it)
			{
				int index_class = it->first;
				//cout << "index_class: " << index_class << " " << it->second << endl;
				if (it->second > 0)
				{
					for (int k = 0; k < pgi_size; k++)
					{
						if (patch_g[i].patch[k].class_id == index_class)
						{
							string patch_name = folder_path + to_string(i) + "_" + to_string(index_class) + "_" + to_string(it->second) + ".png";
							Mat show = Mat(image_size, image_size, CV_8UC3, Scalar(255, 255, 255));
							patch_svg_name = folder_path + to_string(i) + "_" + to_string(index_class) + "_" + to_string(it->second) + ".svg";
							create_svg(patch_svg_name);
							Patch pt = patch_g[i].patch[k];
							for (int m = 0; m < patch_size[i]; m++)
							{
								for (int n = 0; n < patch_size[i]; n++)
								{
									//total_Tiles[pt.wg[m][m]].change_position(Point2f(_0xx + k*(length_t + 10), _0yy + (j + 1)*(length_t + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
									Tile tile_ = total_Tiles[pt.wg[m][n]];
									Point2f shift_ = Point2f(zoom_scale * n * tile_edge_length, zoom_scale * m * tile_edge_length);
									Point2f shift_obj = Point2f(n * tile_edge_length, m * tile_edge_length);
									tile_.draw_tileConts(show, shift_, zoom_scale);
									string model_path = folder_path + "obj/";
									_mkdir(model_path.c_str());
									obj_path = model_path + to_string(i) + "_" + to_string(index_class) + "_" + to_string(it->second) + "_" + to_string(m) + to_string(n) + "_";
									for (int tcnum = 0; tcnum < tile_.content_patterns.size(); tcnum++)
									{
										string  obj_path_ = obj_path + to_string(tcnum) + ".obj";
										write_obj(obj_path_, tile_.content_patterns[tcnum], shift_obj, 4);
									}
									int con_type = 1;
									if (n == 0) //�����
									{
										//if (tile_.Left.id == 0) con_type = 2;
										tile_.draw_slot(show, shift_, "left", zoom_scale, tile_.Left.id, con_type);
									}
									if (n == patch_size[i] - 1) //���ұ�
									{
										tile_.draw_slot(show, shift_, "right", zoom_scale, tile_.Right.id, con_type);
									}
									if (m == patch_size[i] - 1) //���ϱ�
									{
										tile_.draw_slot(show, shift_, "top", zoom_scale, tile_.Top.id, con_type);
									}
									if (m == 0) // ���±�
									{
										tile_.draw_slot(show, shift_, "bottom", zoom_scale, tile_.Bottom.id, con_type);
									}
								}
							}
							imwrite(patch_name, show);
							end_svg(patch_svg_name);
							ofstream outfile(patch_usage, ios::app);
							outfile << i << " scale class_id:" << index_class << "  usage: " << it->second << endl;
							break;
						}
					}
				}
			}
		}
	}

	void Multi_Patch::tiling(vector<Tile> total_Tiles, vector<CS> Color_)
	{
		//memset(vis, -1, sizeof(vis));
		memset(_H, -1, sizeof(_H));
		memset(_H_p, -1, sizeof(_H_p));
		memset(_H_class, -1, sizeof(_H_class));
		////�Ӵ�С
		//for (int i = scale - 1; i >= 0; i--)
		//{
		//	/*if (i != 0 && i != scale - 1)
		//		continue;*/
		//	tiling_each_scale(i, total_Tiles, Color_);
		//	//tiling_supp(i, total_Tiles, Color_);
		//}
		//tiling_supp(0, total_Tiles, Color_);//����empty����tile
	}
	void Multi_Patch::tiling_each_scale(int c, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		int choose_type = 1;// 0: first lower thres; 1: min; 2: random in a range
		//--show pos
		int check_pos = -1;
		int row_ = 21;
		int col_ = 16;
		Mat show2 = Mat(2500, 12500, CV_8UC3, Scalar(255, 255, 255));
		vector<int> ptk_set = { 35, 41, 48,46, 50, 58, 60, 45, 54, 47, 53, 44, 56, 51, 61 };
		vector<int> ptk_set_times(ptk_set.size(), 0);
		//--show pos

		double thres_ = 0.05;
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int cnt_t = 0;
		int p_scale = size2scale[c + 1] - 1;
		/*1 2 4 */
		int search_step = 1;
		cout << "patch.size: " << patch_g[p_scale].patch.size() << endl;
		if (tiling_steps) search_step = c + 1;
		for (int i = c; i < M; i = i + search_step)
		{
			for (int j = c; j < N; j = j + search_step)
			{
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1 || (c != 0 && onetile[i - k1][j - k2] == 1))
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;
				//legal, record the density for tiling
				vector<double> density_dis; 
				for (int k1 = c; k1 >= 0; k1--)
				{
					for (int k2 = c; k2 >= 0; k2--)
					{
						ds += density_d[i - k1][j - k2];
						density_dis.push_back(density_d[i - k1][j - k2]);
						//cout << density_d[i - k1][j - k2] << " ";
					}
				}
				ds /= (c + 1)*(c + 1);
				cnt_t++;
				// 11-15
				vector<double> para_;
				double dynamic_mt_fre;
				//double frequence_dis = measure_high_frequency(density_dis);
				double frequence_dis = measure_high_frequency_sober(density_dis);
				double fre_toler[2] = {0.9, 1.2};//{ 0.6, 0.9 };//{ 0.12, 0.25 };//{1.0, 1.2}
				if (frequence_dis < fre_toler[0]) //low frequence
				{
					para_ = para_group[0];
					dynamic_mt_fre = dynamic_mt;
				}
				else if (frequence_dis < fre_toler[1]) //mid frequence
				{
					//cout << "frequence_dis>" << fre_toler[0] << endl;
					para_ = para_group[1];
					dynamic_mt_fre = dynamic_mt*1.2;
				}
				else  //high
				{
					para_ = para_group[2];   
					dynamic_mt_fre = dynamic_mt*1.4;
				}
				// 11-15

				//11-16 cr
				/*if (_H_fre[i - c][j - c] > -0.0001)
				{
					if (_H_fre[i][j] < 0.12)
					{
						para_ = para_group[0];
						dynamic_mt_fre = dynamic_mt;
					}
					else if (_H_fre[i][j] > 0.25)
					{
						para_ = para_group[1];
						dynamic_mt_fre = dynamic_mt*1.1;
					}
					else
					{
						para_ = para_group[2];
						dynamic_mt_fre = dynamic_mt*1.2;
					}
				}
				double frequence_dis = _H_fre[i][j];*/

				//11-16 cr
				//�ж��ܷ�ƽ��
				int iter_times = 0;
				double dynamic_match_threshold = dynamic_mt - match_threshold;// match_threshold;
				while (dynamic_match_threshold < dynamic_mt_fre) 
				{
					iter_times++;
					int min_index = 0;
					double min_e = 1000;
					vector<int> mins;
					bool got_one = false;
					//cout << rr << endl;
					for (int k = 0; k < patch_g[p_scale].patch.size(); k++)
					{
						int flag1 = 1;
						vector<double> patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
								//density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (vis[x - 1][y] != -1 && _H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (vis[x + 1][y] != -1 && _H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (vis[x][y - 1] != -1 && _H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (vis[x][y + 1] != -1 && _H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						if (flag1 == 0) continue;
						//flag1==1:����߽�����, ѡ��, ��match error
						
						double thres = match_error(density_dis, patch_density, para_[0], para_[1], para_[2]);
						//double thres = match_error(density_dis, patch_density);
						//show a density distribution at a given location
						//if (c + 1 == 4 && iter_times == check_pos) //show once
						//{						
						//	int l = 100;
						//	int size = sqrt(density_dis.size());
						//	if (i == 4 * row_ - 1 && j == 4 * col_ - 1)
						//	{
						//		cout << i << " " << j << endl;
						//		for (int mm = 0; mm < density_dis.size(); mm++)
						//		{
						//			int color = 255 * (1 - density_dis[mm]);
						//			rectangle(show2, Point(10 + mm%size*l, 20 + mm / size*l), Point(10 + mm%size*l + l, 20 + mm / size*l + l), Scalar(color, color, color), -1);
						//			putText(show2, d2s_mant(density_dis[mm], 2), Point(10 + mm%size*l + 10, 20 + mm / size*l + 25), FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1.8);
						//			//cout << sup[j] << " ";
						//		}
						//		putText(show2, d2s_mant(frequence_dis, 4), Point2f(20, 450), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);
						//		putText(show2, d2s_mant(para_[0], 2) + "  " + d2s_mant(para_[1], 2) + "  " + d2s_mant(para_[2], 2), Point2f(20, 480), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);
						//		
						//		int ptk_id = patch_g[p_scale].patch[k].class_id;
						//		for (int ddd = 0; ddd < ptk_set.size(); ddd++)
						//		{
						//			if (ptk_id == ptk_set[ddd])
						//			{
						//				ptk_set_times[ddd]++;
						//				cout << "patch[" << k << "].class_id=" << ptk_id << " has error: " << thres << endl << "density target: ";
						//				for (int q = 0; q < density_dis.size(); q++)
						//					cout << density_dis[q] << " ";
						//				cout << endl << " patch density: ";
						//				for (int q = 0; q < patch_density.size(); q++)
						//					cout << patch_density[q] << " ";
						//				cout << endl << endl;
						//				int _0xx = ddd * (l + 25)* size + 10;
						//				if (ptk_set_times[ddd] == 1) //draw target
						//				{
						//					for (int mm = 0; mm < density_dis.size(); mm++)
						//					{
						//						int color = 255 * (1 - density_dis[mm]);
						//						rectangle(show2, Point(_0xx + mm%size*l, 20 + mm / size*l), Point(_0xx + mm%size*l + l, 20 + mm / size*l + l), Scalar(color, color, color), -1);
						//						putText(show2, d2s_mant(density_dis[mm], 2), Point(_0xx + mm%size*l + 10, 20 + mm / size*l + 25), FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1.8);
						//						//cout << sup[j] << " ";
						//					}
						//				}
						//				for (int jj = 0; jj < size; jj++)
						//				{
						//					for (int kk = 0; kk < size; kk++)
						//					{
						//						total_Tiles[patch_g[p_scale].patch[k].wg[jj][kk]].change_position(Point2f(_0xx + kk*(75 + 10), ptk_set_times[ddd] * 500 + (jj + 1)*(75 + 10)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
						//						total_Tiles[patch_g[p_scale].patch[k].wg[jj][kk]].draw_Tile(show2);
						//						//Point2f shift = Point2f(-9 * j, 9 * i);
						//						total_Tiles[patch_g[p_scale].patch[k].wg[jj][kk]].draw_tileConts(show2);
						//						//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
						//					}
						//				}
						//				putText(show2, d2s_mant(thres, 4), Point2f(_0xx, ptk_set_times[ddd] * 500 + 375), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);
						//				putText(show2, to_string(ptk_id), Point2f(_0xx + 200, ptk_set_times[ddd] * 500 + 370), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0, 0, 0), 2);
						//			}
						//		}
						//		/*cout << "draw pos!" << endl;
						//		string path_ = result_path+ "pos(" + to_string(i) + "," + to_string(j) + ").png";
						//		imwrite(path_, show2);*/
						//	}
						//}
						
				
						if (thres > dynamic_match_threshold)
							continue;

						//first lower thres
						if (choose_type == 0)
						{
							min_index = k;
							got_one = true;
							break;
						}
						else if (choose_type == 1) //min
						{
							if (thres < min_e)
							{
								got_one = true;
								min_e = thres;
								min_index = k;
							}
						}
						else if (choose_type == 2) //random pick
						{
							if (thres <= min_e || abs(thres - min_e)<thres_)
							{
								got_one = true;
								if (abs(thres - min_e)<thres_) mins.push_back(k);
								else
								{
									mins.swap(vector<int>());
									min_e = thres;
									mins.push_back(k);
								}
							}
						}						
					}

					if (c + 1 == 4 && iter_times == check_pos && i == 4 * row_ - 1 && j == 4 * col_ - 1)
					{
						cout << "draw pos!" << endl;
						string path_ = result_path+ "pos(" + to_string(i) + "," + to_string(j) + ").png";
						imwrite(path_, show2);
					}
					
					//if (p_scale == 2)
					//{
					//	four_tiling_index.push_back(k);
					//	//four_tiling_error.push_back(one_ptch_error);
					//}
					if (got_one)
					{
						if (choose_type == 2)
						{
							/*int rr = rand();
							int candi_num = mins.size();
							cout << "rr: " << rr << "  mins: " << candi_num << " rr%candi_num: " << rr%candi_num << endl;
							min_index = mins[rr%candi_num];*/
							int candi_num = mins.size();
							int total_num = -1;
							for (int cnum = 0; cnum < candi_num; cnum++)
							{
								if (patch_g[p_scale].patch[mins[cnum]].used_time>total_num)
								{
									total_num = patch_g[p_scale].patch[mins[cnum]].used_time;
									min_index = mins[cnum];
								}
							}
						}						
						numm++;
						patch_g[p_scale].patch[min_index].used_time++;
						//error = thres;
						double one_ptch_error = 0, patch_error = 0;
						for (int k1 = 0; k1 <= c; k1++)
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[patch_g[p_scale].patch[min_index].wg[k1][k2]];
								one_ptch_error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
								//patch_error += tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)];
								patch_error += density_d[i - (c - k1)][j - (c - k2)] - tt.black_pic / pow(tile_edge_length, 2);
								vis[i - k1][j - k2] = 1;
								_H[i - k1][j - k2] = patch_g[p_scale].patch[min_index].wg[c - k1][c - k2];
								_H_p[i - k1][j - k2] = patch_g[p_scale].patch[min_index].id;
								if (k1 == c && k2 == c)
									_H_class[i - k1][j - k2] = p_scale;
								cnt++;
							}
						}

						//error-diffusion
						if (error_diffusion)
						{
							double quant_error = one_ptch_error / ((c + 1)*(c + 1));
							if (patch_error < 0)
								quant_error = 0 - quant_error;
							int cc = c + 1;

							if (i == 3 && j == 19)
								cout << quant_error << endl;
							//right
							Dithering(i, j + cc, c, 7.0 / 16, quant_error);
							//left-bottom
							Dithering(i + cc, j - cc, c, 3.0 / 16, quant_error);
							//bottom
							Dithering(i + cc, j, c, 5.0 / 16, quant_error);
							//right-bottom
							Dithering(i + cc, j + cc, c, 1.0 / 16, quant_error);

						}
						error += one_ptch_error;
						//cout << "Match threshold of pos ("<<i<<","<<j<<") is: " << dynamic_match_threshold << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += match_threshold;
				}			
			}
			//cout << endl;
		}
		if (cnt != 0) cout << "density error: " << error / cnt << endl;
		cout << "The " << p_scale + 1 << " scale uses " << numm << " patches! " << endl;
		cout << dmt_num[p_scale] << " patches adjust the matching threshold! " << endl;
		cout << "can tile:" << cnt_t << endl;
	}

	void Multi_Patch::tiling_each_scale_dmt(int c, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int cnt_t = 0;
		int p_scale = size2scale[c + 1] - 1;
		/*1 2 4 */
		int search_step = 1;
		if (tiling_steps) search_step = c + 1;

		for (int i = c; i < M; i = i + search_step)
		{
			for (int j = c; j < N; j = j + search_step)
			{
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;

				vector<double> ima;

				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
						ima.push_back(density_d[i - (c - k1)][j - (c - k2)]);
					}
				}
				ds /= (c + 1)*(c + 1);
				double is_high_f = measure_high_frequency(ima);
				cout << is_high_f << endl;
				cnt_t++;
				//�ж��ܷ�ƽ��
				double dynamic_match_threshold = match_threshold;
				while (dynamic_match_threshold < dynamic_mt)
				{
					if (is_high_f <= 0.005&& dynamic_match_threshold >= dynamic_mt_low)
						break;

					int rr = 0;// rand();
					bool got_one = false;
					//cout << rr << endl;
					for (int kkk = rr % patch_g[p_scale].patch.size(), kk = 0; kk < patch_g[p_scale].patch.size(); kkk++, kk++)
					{
						int k = kkk;
						k %= patch_g[p_scale].patch.size();

						if ((patch_g[p_scale].patch[k].wn == 0) && (patch_g[p_scale].patch[k].sn == 0) && (patch_g[p_scale].patch[k].en == 0) && (patch_g[p_scale].patch[k].nn == 0) && patch_g[p_scale].patch[k].density > 0.15)
							continue;
						int flag1 = 1;
						vector<double> density_dis, patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
								//change match error function
								/*if (abs(tt.black_pic / pow(75, 2) - density_d[i - (c - k1)][j - (c - k2)]) > dynamic_match_threshold)
								{
								flag1 = 0;
								break;
								}*/
								density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (vis[x - 1][y] != -1 && _H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (vis[x + 1][y] != -1 && _H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (vis[x][y - 1] != -1 && _H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (vis[x][y + 1] != -1 && _H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						//ѡ��
						if (flag1)
						{
							//����߽���������match error
							double thres = match_error(density_dis, patch_density, local_coef, average_coef, gradient_coef);
							if (thres > dynamic_match_threshold)
								continue;
							numm++;
							patch_g[p_scale].patch[k].used_time++;
							//error = thres;
							for (int k1 = 0; k1 <= c; k1++)
							{
								for (int k2 = 0; k2 <= c; k2++)
								{
									Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
									error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
									vis[i - k1][j - k2] = 1;
									_H[i - k1][j - k2] = patch_g[p_scale].patch[k].wg[c - k1][c - k2];
									_H_p[i - k1][j - k2] = k;
									if (k1 == c && k2 == c)
										_H_class[i - k1][j - k2] = p_scale;
									cnt++;
								}
							}
							got_one = true;
							break;
						}
					}
					if (got_one)
					{
						cout << "dynamic match threshold: " << dynamic_match_threshold << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += match_threshold;
				}

			}
			//cout << endl;
		}
		if (cnt != 0) cout << "density error: " << error / cnt << endl;
		cout << "The " << p_scale + 1 << " scale uses " << numm << " patches! " << endl;
		cout << dmt_num[p_scale] << " patches adjust the matching threshold! " << endl;
		cout << "can tile:" << cnt_t << endl;
	}

	int Multi_Patch::re_tiling_each_scale(int c, vector<Tile> total_Tiles, vector<CS> Color_, vector<pair<Patch, int>> sup_patch)
	{
		int used_min = 2; //new tile >used_min wil be remain
		int add_num = 0;
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int cnt_t = 0;
		int p_scale = size2scale[c + 1] - 1;
		int sup_size = sup_patch.size();
		if (sup_size == 0)
		{
			cout << "No new supplement patches!" << endl;
			return 0;
		}
		vector<vector<int>> fill_index;
		for (int findex = 0; findex < sup_size; findex++)
		{
			vector<int> one_usage;
			fill_index.push_back(one_usage);
		}
		//vector<int> used_times_sup(sup_size, 0);
		/*1 2 4 */
		int current_vis[ImageSize][ImageSize];
		int current_H[ImageSize][ImageSize];
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				current_H[i][j] = _H[i][j];
				current_vis[i][j] = vis[i][j];
			}
		}

		int search_step = 1;
		if (tiling_steps) search_step = c + 1;
		for (int i = c; i < M; i = i + search_step)
		{
			for (int j = c; j < N; j = j + search_step)
			{
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1 || (c != 0 && onetile[i - k1][j - k2] == 1))
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
					}
				}
				ds /= (c + 1)*(c + 1);
				cnt_t++;
				//�ж��ܷ�ƽ��
				double dynamic_match_threshold = /*match_threshold * 30*/re_dynamic_mt - 0.0001;
				while (dynamic_match_threshold < re_dynamic_mt)
				{
					int rr = 0;// rand();
					bool got_one = false;
					for (int kkk = rr % sup_patch.size(), kk = 0; kk < sup_patch.size(); kkk++, kk++)
					{
						int k = kkk;
						k %= sup_patch.size();
						//if (!(patch_g[c].patch[k].density > ds - 0.15&&patch_g[c].patch[k].density < ds + 0.15))
						/*if (2 * int(ds * 10) + (int(ds * 100) % 10 > 5 ? 1 : 0) != 2 * int(patch_g[c].patch[k].density * 10) + (int(patch_g[c].patch[k].density * 100) % 10 > 5 ? 1 : 0))
						continue;*/
						int flag1 = 1;
						vector<double> density_dis, patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[sup_patch[k].first.wg[k1][k2]];
								//change match error function
								/*if (abs(tt.black_pic / pow(75, 2) - density_d[i - (c - k1)][j - (c - k2)]) > dynamic_match_threshold)
								{
								flag1 = 0;
								break;
								}*/
								density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (current_vis[x - 1][y] != -1 && current_H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[current_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (current_vis[x + 1][y] != -1 && current_H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[current_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (current_vis[x][y - 1] != -1 && current_H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[current_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (current_vis[x][y + 1] != -1 && current_H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[current_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						//ѡ��
						if (flag1)
						{
							//����߽���������match error
							double thres = match_error(density_dis, patch_density, 0.4, 0.2, 0.4);
							if (thres > dynamic_match_threshold)
								continue;
							numm++;
							sup_patch[k].first.used_time++;
							fill_index[k].push_back(i);
							fill_index[k].push_back(j);

							for (int k1 = 0; k1 <= c; k1++)
							{
								for (int k2 = 0; k2 <= c; k2++)
								{
									current_vis[i - k1][j - k2] = 1;
									current_H[i - k1][j - k2] = sup_patch[k].first.wg[c - k1][c - k2];
								}
							}

							got_one = true;
							break;
						}
					}
					if (got_one)
					{
						cout << "dynamic match threshold: " << dynamic_match_threshold << "(" << i << "," << j << ")" << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += (match_threshold * 30);
				}

			}
			//cout << endl;
		}
		cout << "add sup!" << endl;

		map<int, int>class_num;
		for (int m = 0; m < sup_size; m++)
		{
			if (class_num.count(sup_patch[m].first.class_id) == 0)
				class_num[sup_patch[m].first.class_id] = sup_patch[m].first.used_time;
			else
				class_num[sup_patch[m].first.class_id] += sup_patch[m].first.used_time;

			////�ޱ߽�Լ��
			//sup_patch[m].first.id = patch_g[p_scale].patch.size();
			//patch_g[p_scale].patch.push_back(sup_patch[m].first);
		}
		cout << "before used " << class_num.size() << endl;

		//��sup_patch��ʹ�õ������ӵ�patch��, ���������滻δʹ�õ�
		//for (int m = 0; m < sup_size; m++)
		//{
		//	if (sup_patch[m].first.used_time != 0) // patch��δ�õ��ı߽���sup���һ���õ�
		//	{
		//		int final_index = 0;
		//		int index_p = sup_patch[m].second;
		//		if (patch_g[p_scale].patch[index_p].used_time == 0)
		//		{
		//			cout << "Replace unused patches!" << endl;
		//			patch_g[p_scale].patch[index_p] = sup_patch[m].first;
		//			//cout << "patch_g[p_scale].patch[index_p].used_time!" << patch_g[p_scale].patch[index_p].used_time<<endl;
		//			final_index = index_p;
		//		}
		//		else //δʹ�õ����滻,��ͬ�߽����Ϊ�������ӽ�patch��
		//		{
		//			cout << "Add new patches!" << endl;
		//			patch_g[p_scale].patch.push_back(sup_patch[m].first);
		//			final_index = patch_g[p_scale].patch.size() - 1;
		//		}
		//		for (int n = 0; n < fill_index[m].size(); n = n + 2)
		//		{
		//			int i = fill_index[m][n];
		//			int j = fill_index[m][n + 1];
		//			for (int k1 = 0; k1 <= c; k1++)
		//			{
		//				for (int k2 = 0; k2 <= c; k2++)
		//				{
		//					Tile tt = total_Tiles[patch_g[p_scale].patch[final_index].wg[k1][k2]];
		//					error += abs(tt.black_pic / pow(75, 2) - density_d[i - (c - k1)][j - (c - k2)]);
		//					vis[i - k1][j - k2] = 1;
		//					_H[i - k1][j - k2] = patch_g[p_scale].patch[final_index].wg[c - k1][c - k2];
		//					_H_p[i - k1][j - k2] = final_index;
		//					if (k1 == c && k2 == c)
		//						_H_class[i - k1][j - k2] = p_scale;
		//					cnt++;
		//				}
		//			}
		//		}
		//	}
		//}
		vector<int> empty_index; //��¼patch��û�б�ʹ�õ�λ��
		/*for (int n = 0; n < patch_g[p_scale].patch.size(); n++)
		if (patch_g[p_scale].patch[n].used_time == 0) empty_index.push_back(n);*/
		//int full_size = patch.size();
		cout << "patch_g[p_scale].patch size:" << patch_g[p_scale].patch.size() << endl;
		for (int n = 0; n < patch_g[p_scale].patch.size(); n += 4)
		{
			if (patch_g[p_scale].patch[n].used_time == 0 && patch_g[p_scale].patch[n + 1].used_time == 0 && patch_g[p_scale].patch[n + 2].used_time == 0 && patch_g[p_scale].patch[n + 3].used_time == 0)
			{
				empty_index.push_back(n);
				patch_g[p_scale].patch[n + 1].class_id = -1;
				patch_g[p_scale].patch[n + 2].class_id = -1;
				patch_g[p_scale].patch[n + 3].class_id = -1;
			}
		}
		cout << empty_index.size() << endl;
		int replace_index = 0;
		for (int m = 0; m < sup_size; m++)
		{
			if (class_num[sup_patch[m].first.class_id] > used_min) // sup_patch�Ƿ���retiling�׶�ʹ��
			{
				cout << "sup_patch " << m << " is used!" << endl;
				add_num++;
				int final_index = 0;
				/*if (replace_index < empty_index.size())
				{
					sup_patch[m].first.id = patch_g[p_scale].patch[empty_index[replace_index]].id;
					patch_g[p_scale].patch[empty_index[replace_index]] = sup_patch[m].first;
					final_index = empty_index[replace_index];
					replace_index++;
				}
				else
				{*/
					sup_patch[m].first.id = patch_g[p_scale].patch.size();
					patch_g[p_scale].patch.push_back(sup_patch[m].first);
					final_index = patch_g[p_scale].patch.size() - 1;
				//}
				for (int n = 0; n < fill_index[m].size(); n = n + 2)
				{
					int i = fill_index[m][n];
					int j = fill_index[m][n + 1];
					for (int k1 = 0; k1 <= c; k1++)
					{
						for (int k2 = 0; k2 <= c; k2++)
						{
							Tile tt = total_Tiles[patch_g[p_scale].patch[final_index].wg[k1][k2]];
							error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
							vis[i - k1][j - k2] = 1;
							last_vis[i - k1][j - k2] = 1;
							_H[i - k1][j - k2] = patch_g[p_scale].patch[final_index].wg[c - k1][c - k2];
							_H_p[i - k1][j - k2] = patch_g[p_scale].patch[final_index].id;
							if (k1 == c && k2 == c)
								_H_class[i - k1][j - k2] = p_scale;
							cnt++;
						}
					}

				}

			}
		}
		int avail_num = 0;
		for (int d = 0; d < patch_g[p_scale].patch.size(); d++)
			if (patch_g[p_scale].patch[d].used_time != 0) avail_num++;
		if (cnt != 0) cout << "density error: " << error / cnt << endl;
		cout << "At present the set has " << patch_g[p_scale].patch.size() << " patches and " << avail_num << " available patches!" << endl;
		cout << "Add " << add_num<<" patches and Retiling " << numm << " patches of " << p_scale + 1 << " scale!" << endl;
		cout << dmt_num[p_scale] << " patches adjust the matching threshold! " << endl;
		cout << "can tile:" << cnt_t << endl;
		return add_num;
	}

	int Multi_Patch::re_tiling_each_scale_waiting(int c, vector<Tile> total_Tiles, vector<CS> Color_, vector<pair<Patch, int>> sup_patch)
	{
		int add_num = 0;
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int cnt_t = 0;
		int p_scale = size2scale[c + 1] - 1;
		int sup_size = sup_patch.size();
		if (sup_size == 0)
		{
			cout << "No new supplement patches!" << endl;
			return 0;
		}
		vector<vector<int>> fill_index;
		for (int findex = 0; findex < sup_size; findex++)
		{
			vector<int> one_usage;
			fill_index.push_back(one_usage);
		}
		//vector<int> used_times_sup(sup_size, 0);
		/*1 2 4 */
		int search_step = 1;
		if (tiling_steps) search_step = c + 1;
		int current_vis[ImageSize][ImageSize];
		int current_H[ImageSize][ImageSize];
		memset(current_vis, -1, sizeof(current_vis));
		memset(current_H, -1, sizeof(current_H));
		for (int i = c; i < M; i = i + search_step)
		{
			for (int j = c; j < N; j = j + search_step)
			{
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
					}
				}
				ds /= (c + 1)*(c + 1);
				cnt_t++;
				//�ж��ܷ�ƽ��
				double dynamic_match_threshold = /*match_threshold * 2*/re_dynamic_mt - 0.001;
				while (dynamic_match_threshold < re_dynamic_mt)
				{
					int rr = 0;// rand();
					bool got_one = false;
					for (int kkk = rr % sup_patch.size(), kk = 0; kk < sup_patch.size(); kkk++, kk++)
					{
						int k = kkk;
						k %= sup_patch.size();
						int flag1 = 1;
						vector<double> density_dis, patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[sup_patch[k].first.wg[k1][k2]];
								density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (current_vis[x - 1][y] != -1 && current_H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[current_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (current_vis[x + 1][y] != -1 && current_H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[current_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (current_vis[x][y - 1] != -1 && current_H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[current_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (current_vis[x][y + 1] != -1 && current_H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[current_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						//ѡ��
						if (flag1)
						{
							//����߽���������match error
							double thres = match_error(density_dis, patch_density, 0.6, 0.4, 0);
							if (i == 96 && j == 16)
								cout << i << "," << j << ": " << thres << endl;

							if (thres > dynamic_match_threshold)
								continue;
							numm++;
							sup_patch[k].first.used_time++;
							fill_index[k].push_back(i);
							fill_index[k].push_back(j);

							for (int k1 = 0; k1 < patch_size[p_scale]; k1++)
							{
								for (int k2 = 0; k2 < patch_size[p_scale]; k2++)
								{
									current_vis[i - k1][j - k2] = 1;
									current_H[i - k1][j - k2] = sup_patch[k].first.wg[c - k1][c - k2];
								}
							}

							got_one = true;
							break;
						}
					}
					if (got_one)
					{
						cout << "dynamic match threshold: " << dynamic_match_threshold << "(" << i << "," << j << ")" << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += (match_threshold*2);
				}

			}
			//cout << endl;
		}
		cout << "add sup!" << endl;
		
		map<int, int>class_num;
		for (int m = 0; m < sup_size; m++)
		{
			if (class_num.count(sup_patch[m].first.class_id) == 0)
				class_num[sup_patch[m].first.class_id] = sup_patch[m].first.used_time;
			else
				class_num[sup_patch[m].first.class_id] += sup_patch[m].first.used_time;

			//�ޱ߽�Լ��
			sup_patch[m].first.id = patch_g[p_scale].patch.size();
			patch_g[p_scale].patch.push_back(sup_patch[m].first);
		}
		cout << "before used " << class_num.size() << endl;
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
				_H_temp[i][j] = current_H[i][j];
		}

		int replace_index = 0;
		for (int m = 0; m < sup_size; m++)
		{
			if (class_num[sup_patch[m].first.class_id] >= replace_num_threshold&&sup_patch[m].first.used_time > 0) // sup_patch��retiling�׶�ʹ�ó�����ֵ
			{
				cout << "used time:" << class_num[sup_patch[m].first.class_id] << endl;
				Patch pt = sup_patch[m].first;
				vector<int>replace_position;//(x,y,patch.class_id)
				//�����ж�ÿ��λ���Ƿ���̣��ۼƳ�����ֵ��Ϊ����
				int tile_num = 0;
				for (int n = 0; n < fill_index[m].size(); n = n + 2)
				{
					int i = fill_index[m][n];
					int j = fill_index[m][n + 1];
					if (can_tile(pt, total_Tiles, i - (patch_size[p_scale] - 1), j - (patch_size[p_scale] - 1), replace_position, p_scale))
					{
						tile_num++;
					}
					else
					{
						fill_index[m][n] = -1;
						fill_index[m][n + 1] = -1;
						class_num[sup_patch[m].first.class_id]--;
					}

				}

				if (class_num[sup_patch[m].first.class_id] < /*replace_num_threshold*/0)
					break;

				//push patch into patch set
				sup_patch[m].first.id = patch_g[p_scale].patch.size();
				sup_patch[m].first.used_time = tile_num;
				patch_g[p_scale].patch.push_back(sup_patch[m].first);
				int final_index = patch_g[p_scale].patch.size() - 1;
				for (int n = 0; n < fill_index[m].size(); n = n + 2)
				{
					int i = fill_index[m][n];
					int j = fill_index[m][n + 1];
					if (i == -1 || j == -1)
						continue;
					cout << i << " " << j << endl;
					for (int k1 = 0; k1 <= c; k1++)
					{
						for (int k2 = 0; k2 <= c; k2++)
						{
							Tile tt = total_Tiles[patch_g[p_scale].patch[final_index].wg[k1][k2]];
							vis[i - k1][j - k2] = 1;
							_H[i - k1][j - k2] = patch_g[p_scale].patch[final_index].wg[c - k1][c - k2];
							_H_p[i - k1][j - k2] = patch_g[p_scale].patch[final_index].id;
							if (k1 == c && k2 == c)
								_H_class[i - k1][j - k2] = p_scale;
							cnt++;
						}
					}
				}
				for (int n = 0; n < replace_position.size(); n += 4)
				{
					int i = replace_position[n];
					int j = replace_position[n + 1];
					int final_index = replace_position[n + 2];
					int last_index = replace_position[n + 3];
					for (int k1 = 0; k1 <= c; k1++)
					{
						for (int k2 = 0; k2 <= c; k2++)
						{
							Tile tt = total_Tiles[patch_g[p_scale].patch[final_index].wg[k1][k2]];
							error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
							vis[i - k1][j - k2] = 1;
							_H[i - k1][j - k2] = patch_g[p_scale].patch[final_index].wg[c - k1][c - k2];
							_H_p[i - k1][j - k2] = patch_g[p_scale].patch[final_index].id;
							if (k1 == c && k2 == c)
								_H_class[i - k1][j - k2] = p_scale;
							cnt++;
						}
					}
					patch_g[p_scale].patch[final_index].used_time++;
					patch_g[p_scale].patch[last_index].used_time--;
				}
				cout << "sup_patch " << m << " is used!" << endl;
				add_num++;
			}
		}
		int avail_num = 0;
		for (int d = 0; d < patch_g[p_scale].patch.size(); d++)
			if (patch_g[p_scale].patch[d].used_time != 0) avail_num++;
		if (cnt != 0) cout << "density error: " << error / cnt << endl;
		cout << "At present the set has " << patch_g[p_scale].patch.size() << " patches and " << avail_num << " available patches!" << endl;
		cout << "Add " << add_num << " patches and Retiling " << numm << " patches of " << p_scale + 1 << " scale!" << endl;
		cout << dmt_num[p_scale] << " patches adjust the matching threshold! " << endl;
		cout << "can tile:" << cnt_t << endl;
		return add_num;
	}

	void Multi_Patch::tiling_each_scale_bidirection(int c, vector<Tile> total_Tiles, vector<CS> Color, int start_i, int start_j) //---lxk
	{
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int cnt_t = 0;
		int p_scale = size2scale[c + 1] - 1;
		/*1 2 4 */
		int search_step = 1;
		if (tiling_steps) search_step = c + 1;
		if (start_i < c || start_j < c) cout << "Wrong start coordinate!" << endl;
		//forward direct tiling 
		for (int i = start_i; i < M; i = i + search_step)
		{
			for (int j = c; j < N; j = j + search_step)
			{
				if (i == start_i && j == c) j = start_j;
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
					}
				}
				ds /= (c + 1)*(c + 1);
				//�ж�c*c���Ƿ����ƽ��
				/*for (int k1 = 0; k1 <= c; k1++)
				{
				for (int k2 = 0; k2 <= c; k2++)
				{
				if (abs(ds - density_d[i - k1][j - k2]) > 0.05)
				{
				flag = 1;
				break;
				}
				}
				}
				if (flag)
				continue;*/
				cnt_t++;
				//�ж��ܷ�ƽ��
				double dynamic_match_threshold = match_threshold;
				while (dynamic_match_threshold < dynamic_mt)
				{
					int rr = 0;// rand();
					bool got_one = false;
					//cout << rr << endl;
					for (int kkk = rr % patch_g[p_scale].patch.size(), kk = 0; kk < patch_g[p_scale].patch.size(); kkk++, kk++)
					{
						int k = kkk;
						k %= patch_g[p_scale].patch.size();
						//if (!(patch_g[c].patch[k].density > ds - 0.15&&patch_g[c].patch[k].density < ds + 0.15))
						/*if (2 * int(ds * 10) + (int(ds * 100) % 10 > 5 ? 1 : 0) != 2 * int(patch_g[c].patch[k].density * 10) + (int(patch_g[c].patch[k].density * 100) % 10 > 5 ? 1 : 0))
						continue;*/
						int flag1 = 1;
						vector<double> density_dis, patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
								//change match error function
								/*if (abs(tt.black_pic / pow(75, 2) - density_d[i - (c - k1)][j - (c - k2)]) > dynamic_match_threshold)
								{
								flag1 = 0;
								break;
								}*/
								density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (vis[x - 1][y] != -1 && _H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (vis[x + 1][y] != -1 && _H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (vis[x][y - 1] != -1 && _H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (vis[x][y + 1] != -1 && _H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						//ѡ��
						if (flag1)
						{
							//����߽���������match error
							double thres = match_error(density_dis, patch_density, local_coef, average_coef, gradient_coef);
							if (thres > dynamic_match_threshold)
								continue;
							numm++;
							patch_g[p_scale].patch[k].used_time++;
							//error = thres;
							for (int k1 = 0; k1 <= c; k1++)
							{
								for (int k2 = 0; k2 <= c; k2++)
								{
									Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
									error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
									vis[i - k1][j - k2] = 1;
									_H[i - k1][j - k2] = patch_g[p_scale].patch[k].wg[c - k1][c - k2];
									_H_p[i - k1][j - k2] = k;
									if (k1 == c && k2 == c)
										_H_class[i - k1][j - k2] = p_scale;
									cnt++;
								}
							}
							got_one = true;
							break;
						}
					}
					if (got_one)
					{
						//cout << "dynamic match threshold: " << dynamic_match_threshold << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += match_threshold;
				}

			}
			//cout << endl;
		}
		//reverse direction
		for (int i = start_i; i >= c; i = i - search_step)
		{
			for (int j = N - 1; j >= c; j = j - search_step)
			{
				if (i == start_i && j == N - 1) j = start_j - search_step;
				if (j < 0) continue;
				ds = 0;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							ds = 1;
							break;
						}
					}
				}
				if (ds == 1)
					continue;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
					}
				}
				ds /= (c + 1)*(c + 1);
				cnt_t++;
				//�ж��ܷ�ƽ��
				double dynamic_match_threshold = match_threshold;
				while (dynamic_match_threshold < dynamic_mt)
				{
					int rr = 0;// rand();
					bool got_one = false;
					//cout << rr << endl;
					for (int kkk = rr % patch_g[p_scale].patch.size(), kk = 0; kk < patch_g[p_scale].patch.size(); kkk++, kk++)
					{
						int k = kkk;
						k %= patch_g[p_scale].patch.size();
						//if (!(patch_g[c].patch[k].density > ds - 0.15&&patch_g[c].patch[k].density < ds + 0.15))
						/*if (2 * int(ds * 10) + (int(ds * 100) % 10 > 5 ? 1 : 0) != 2 * int(patch_g[c].patch[k].density * 10) + (int(patch_g[c].patch[k].density * 100) % 10 > 5 ? 1 : 0))
						continue;*/
						int flag1 = 1;
						vector<double> density_dis, patch_density;
						for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
						{
							for (int k2 = 0; k2 <= c; k2++)
							{
								Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
								//change match error function
								/*if (abs(tt.black_pic / pow(75, 2) - density_d[i - (c - k1)][j - (c - k2)]) > dynamic_match_threshold)
								{
								flag1 = 0;
								break;
								}*/
								density_dis.push_back(density_d[i - (c - k1)][j - (c - k2)]);
								patch_density.push_back(tt.black_pic / pow(tile_edge_length, 2));

								if (k1 == 0)//n
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x > 0)
									{
										if (vis[x - 1][y] != -1 && _H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[_H[x - 1][y]].Top.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k1 == c)//s
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (x < M - 1)
									{
										if (vis[x + 1][y] != -1 && _H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[_H[x + 1][y]].Bottom.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == 0)//w
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y > 0)
									{
										if (vis[x][y - 1] != -1 && _H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[_H[x][y - 1]].Right.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
								if (k2 == c)//e
								{
									int x = i - (c - k1);
									int y = j - (c - k2);
									if (y < N - 1)
									{
										if (vis[x][y + 1] != -1 && _H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[_H[x][y + 1]].Left.id)
										{
											flag1 = 0;
											break;
										}
									}
								}
							}
							if (flag1 == 0) break;
						}
						//ѡ��
						if (flag1)
						{
							//����߽���������match error
							double thres = match_error(density_dis, patch_density, local_coef, average_coef, gradient_coef);
							if (thres > dynamic_match_threshold)
								continue;
							numm++;
							patch_g[p_scale].patch[k].used_time++;
							//error = thres;
							for (int k1 = 0; k1 <= c; k1++)
							{
								for (int k2 = 0; k2 <= c; k2++)
								{
									Tile tt = total_Tiles[patch_g[p_scale].patch[k].wg[k1][k2]];
									error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
									vis[i - k1][j - k2] = 1;
									_H[i - k1][j - k2] = patch_g[p_scale].patch[k].wg[c - k1][c - k2];
									_H_p[i - k1][j - k2] = k;
									if (k1 == c && k2 == c)
										_H_class[i - k1][j - k2] = p_scale;
									cnt++;
								}
							}
							got_one = true;
							break;
						}
					}
					if (got_one)
					{
						//cout << "dynamic match threshold: " << dynamic_match_threshold << endl;
						if (dynamic_match_threshold > match_threshold) dmt_num[p_scale]++;
						break;
					}
					else dynamic_match_threshold += match_threshold;
				}

			}
			//cout << endl;
		}
		if (cnt != 0) cout << "density error: " << error / cnt << endl;
		cout << "The " << p_scale + 1 << " scale uses " << numm << " patches! " << endl;
		cout << dmt_num[p_scale] << " patches adjust the matching threshold! " << endl;
		cout << "can tile:" << cnt_t << endl;
	}

	void Multi_Patch::tiling_supp(int c, vector<Tile> total_Tiles, vector<CS> Color_)
	{
		double ds = 0;
		int numm = 0;
		double error = 0;
		int cnt = 0;
		int p_scale = size2scale[c + 1] - 1;
		bool j_error = false;

		cout << "Tiling all empty area by 1*1 tiles!" << endl;
		for (int i = c; i < M; i++)
		{
			for (int j = c; j < N; j++)
			{
				if (vis[i][j] != -1)
					continue;
				ds = 0;
				j_error = false;
				//�ж�c*c���Ƿ����tile
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							ds = 1;
							break;
						}
						if (onetile[i - k1][j - k2] == 1)
							j_error = true;
					}
				}
				if (ds == 1)
					continue;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						ds += density_d[i - k1][j - k2];
					}
				}
				ds /= (c + 1)*(c + 1);
				int flag = 0;

				//�ж��ܷ�ƽ��
				int min_pos = -1;
				double ex_den = 10;
				int rr = 0;// rand();
				//cout << rr << "  patch_g[c].patch.size(): " << patch_g[c].patch.size() << endl;
				for (int kkk = rr % patch_g[c].patch.size(), kk = 0; kk < patch_g[c].patch.size(); kkk++, kk++)
				{
					int k = kkk;					
					k %= patch_g[c].patch.size();
					
					//if (!(patch_g[c].patch[k].density > ds - 0.4&&patch_g[c].patch[k].density < ds + 0.4))
					//if(int(ds*10)!=int(patch_g[c].patch[k].density*10))
					//continue;
					int flag1 = 1;
					for (int k1 = 0; k1 <= c; k1++)//���Ͻǿ�ʼ
					{
						for (int k2 = 0; k2 <= c; k2++)
						{
							Tile tt = total_Tiles[patch_g[c].patch[k].wg[k1][k2]];
							if (k1 == 0)//n
							{
								int x = i - (c - k1);
								int y = j - (c - k2);
								if (x > 0)
								{
									if (vis[x - 1][y] != -1 && _H[x - 1][y] >= 0 && tt.Bottom.id != total_Tiles[_H[x - 1][y]].Top.id)
									{
										flag1 = 0;
										break;
									}
								}
							}
							if (k1 == c)//s
							{
								int x = i - (c - k1);
								int y = j - (c - k2);
								if (x < M - 1)
								{
									if (vis[x + 1][y] != -1 && _H[x + 1][y] >= 0 && tt.Top.id != total_Tiles[_H[x + 1][y]].Bottom.id)
									{
										flag1 = 0;
										break;
									}
								}
							}
							if (k2 == 0)//w
							{
								int x = i - (c - k1);
								int y = j - (c - k2);
								if (y > 0)
								{
									if (vis[x][y - 1] != -1 && _H[x][y - 1] >= 0 && tt.Left.id != total_Tiles[_H[x][y - 1]].Right.id)
									{
										flag1 = 0;
										break;
									}
								}
							}
							if (k2 == c)//e
							{
								int x = i - (c - k1);
								int y = j - (c - k2);
								if (y < N - 1)
								{
									if (vis[x][y + 1] != -1 && _H[x][y + 1] >= 0 && tt.Right.id != total_Tiles[_H[x][y + 1]].Left.id)
									{
										flag1 = 0;
										break;
									}
								}
							}
						}
					}
					//ѡ��
					if (flag1)
					{
						flag = 1;
						if (abs(patch_g[c].patch[k].density - ds) < ex_den)
						{
							ex_den = abs(patch_g[c].patch[k].density - ds);
							min_pos = k;
						}
					}
					//cout << "min_pos: "<<min_pos << endl;
				}
				if (min_pos == -1)
				{
					cout << "Miss match!" << endl;
					continue;
				}
				//ѡ���ܶ������С��
				//error += abs(patch_g[c].patch[min_pos].density - ds);
				//cout << "Error: " << abs(patch_g[c].patch[min_pos].density - ds) << endl;
				numm++;
				patch_g[c].patch[min_pos].used_time++;
				if (min_pos == -1)
					cout << endl;
				double one_ptch_error = 0, patch_error = 0;
				for (int k1 = 0; k1 <= c; k1++)
				{
					for (int k2 = 0; k2 <= c; k2++)
					{
						Tile tt = total_Tiles[patch_g[p_scale].patch[min_pos].wg[k1][k2]];
						one_ptch_error += abs(tt.black_pic / pow(tile_edge_length, 2) - density_d[i - (c - k1)][j - (c - k2)]);
						//cout << tt.black_pic / pow(tile_edge_length, 2) << "  " << density_d[i - (c - k1)][j - (c - k2)] << " min: " << min_pos << "  ";
						patch_error += density_d[i - (c - k1)][j - (c - k2)] - tt.black_pic / pow(tile_edge_length, 2);
						vis[i - k1][j - k2] = 1;
						_H[i - k1][j - k2] = patch_g[p_scale].patch[min_pos].wg[c - k1][c - k2];
						_H_p[i - k1][j - k2] = patch_g[p_scale].patch[min_pos].id;
						//_H_p[i - k1][j - k2] = min_pos;
						//cout << "min_pos: " << min_pos << "  patch[min_pos].id:  " << patch_g[p_scale].patch[min_pos].id << endl;
						if (k1 == c && k2 == c)
							_H_class[i - k1][j - k2] = c;
						cnt++;
					}
				}
				//error-diffusion
				if (error_diffusion_11&&j_error)
				{
					double quant_error = one_ptch_error / ((c + 1)*(c + 1));
					if (patch_error < 0)
						quant_error = 0 - quant_error;
					int cc = c + 1;

					//if (i == 3 && j == 19)
					//	cout << quant_error << endl;
					//right
					Dithering(i, j + cc, c, 7.0 / 16, quant_error);
					//left-bottom
					Dithering(i + cc, j - cc, c, 3.0 / 16, quant_error);
					//bottom
					Dithering(i + cc, j, c, 5.0 / 16, quant_error);
					//right-bottom
					Dithering(i + cc, j + cc, c, 1.0 / 16, quant_error);
					
					cout << "Error diffusion for 1*1 tiles" << endl;

				}
				error += one_ptch_error;
				//cout << "Error at (" << i << "," << j << "): " << one_ptch_error<<"   ";
				//if (cnt % 4 == 0) cout << endl;

			}
			//cout << endl;
		}
		total_error += error;
		cout << "Total density error of empty area: " << error / cnt << endl;
		cout << c + 1 << " scale supplement number:" << numm << endl;
	}
	void Multi_Patch::draw_tiling(vector<Tile> total_Tiles, vector<CS> Color_, int draw_scale, int draw_iter_times)
	{
		//draw_scale == 0, �����ս��
		Mat show = Mat(image_pixel_h, image_pixel_w, CV_8UC3, Scalar(255, 255, 255));
		Mat show_origin = Mat(image_pixel_h, image_pixel_w, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(image_pixel_h, image_pixel_w, CV_8UC3, Scalar(255, 255, 255));
		patch_svg_name = result_path + "tiling_result_with_init_" + to_string(draw_scale) + "_" + to_string(draw_iter_times)+".svg";
		if (draw_iter_times == 0) create_svg(patch_svg_name);
		int _0x = 10, _0y = 10;
		int empty_tile = 0;
		double error = 0;
		ofstream outfile(result_path+ "error.txt");
		ofstream outfile2(result_num, ios::app);
		int _H_class_temp[ImageSize][ImageSize];
		memset(_H_class_temp, -1, sizeof(_H_class_temp));
		for (int t = 0; t < scale; t++) //used_number��������
			patch_g[t].used_number = 0;
		//vector<int>number(5, 0);
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				int posx = i;
				int posy = j;
				if (_H_class[i][j] != -1)
				{
					for (int k1 = 0; k1 < patch_size[_H_class[i][j]]; k1++)
					{
						for (int k2 = 0; k2 < patch_size[_H_class[i][j]]; k2++)
						{
							_H_class_temp[i + k1][j + k2] = _H_class[i][j];
						}
					}
				}
			}
		}
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (_H[i][j] >= 0 && _H[i][j] < total_Tiles.size())
				{
					//outfile << abs(density_d[i][j] - total_Tiles[_H[i][j]].black_pic*1.0 / pow(Color_[0].edge_length, 2)) << " ";
					//error += abs(density_d[i][j] - total_Tiles[_H[i][j]].black_pic*1.0 / pow(Color_[0].edge_length, 2));

					outfile << abs(density_d2[i][j] - total_Tiles[_H[i][j]].black_pic*1.0 / pow(Color_[0].edge_length, 2)) << " ";
					error += abs(density_d2[i][j] - total_Tiles[_H[i][j]].black_pic*1.0 / pow(Color_[0].edge_length, 2));
					total_Tiles[_H[i][j]].draw_tileConts(show_origin, Point2f(_0x + j*(Color_[0].edge_length + 0), _0y + i*(Color_[0].edge_length + 0)));
					if (draw_iter_times == 0)
						total_Tiles[_H[i][j]].draw_tileConts(show, Point2f(_0x + j*(Color_[0].edge_length + 0), _0y + i*(Color_[0].edge_length + 0)), _H_class_temp[i][j], 1);				
				}
				else
				{
					empty_tile++;
					//cout << endl << endl << "hahahahah" << endl << _H[i][j] << "  " << _H[i][j] << endl << endl;
					outfile << -0 << " ";
				}

				/*if (_H_class[i][j] != -1)
				patch_g[_H_class[i][j]].patch[_H_p[i][j]].used_time++;*/
				if (_H_class[i][j] != -1 && draw_iter_times == 0)
				{
					//number[_H_class[i][j]]++;
					patch_g[_H_class[i][j]].draw_single_patch(show1, Point2f(_0x + j*(Color_[0].edge_length + 0), _0y + i*(Color_[0].edge_length + 0)), _H_p[i][j], total_Tiles, Color_);
					patch_g[_H_class[i][j]].used_number++;
				}
			}
			outfile << endl;
			//cout << endl;
		}
		//cout << "patch_g[i].used_number: " << patch_g[0].used_number << "  " << patch_g[1].used_number << "  " << patch_g[2].used_number << endl;
		outfile.close();
		//show one tile
		/*Mat show_inter = Mat(800, 800, CV_8UC3, Scalar(255, 255, 255));
		int i_one = 24;
		int j_one = 36;
		cout << "density_d: " << endl;
		for (int i = i_one; i < i_one + 4; i++)
		{
		for (int j = j_one; j < j_one + 4; j++)
		{
		cout << density_d[i][j] << " ";
		}
		}
		cout << "total_Tiles: " << endl;
		for (int i = i_one; i < i_one + 4; i++)
		{
		for (int j = j_one; j < j_one + 4; j++)
		{
		cout << total_Tiles[_H[i][j]].black_pic*1.0 / pow(Color_[0].edge_length, 2) << " ";
		total_Tiles[_H[i][j]].draw_tileConts(show_inter, Point2f(_0x + (j-j_one)*(Color_[0].edge_length + 0), _0y + (i-i_one)*(Color_[0].edge_length + 0)));
		}
		}
		imshow("one_tile", show_inter);*/
		cout << "Total empty number: " << empty_tile << endl;
		cout << "all density error:" << error / (M*N - empty_tile) << endl;
		cout << "each scale number: ";
		for (int t = 0; t < scale; t++)
			cout<<patch_g[t].used_number << "  ";
		cout << endl;
		//imshow("result", show);
		total_error = error;
		outfile2 << endl << "After " << draw_scale << " scale " << draw_iter_times << " tiling iters, the empty area : " << empty_tile << endl;
		outfile2 << "Total density error: " << total_error<<"  average: "<<error / (M*N - empty_tile) << endl << endl;
		outfile2.close();
		//draw_scale == 1, draw_iter_times == 0, �����ս��
		if (draw_iter_times == 0) 
		{
			imwrite(result_path + "tiling_result_with_init_" + to_string(draw_scale) + ".png", show);
			imwrite(result_path + "tiling_result_black_with_init_" + to_string(draw_scale) + ".png", show_origin);
			imwrite(result_path + "divide_with_init_" + to_string(draw_scale) + ".png", show1);
			end_svg(patch_svg_name);
		}	
		else 
		{
			imwrite(result_path+ "tiling_black_" + to_string(draw_scale) + "_after_" + to_string(draw_iter_times) + "_iter_times.png", show_origin);
		}

	}

	void Multi_Patch::draw_special_tiling(vector<Tile> total_Tiles, vector<CS> Color_, int draw_scale, int draw_iter_times)
	{
		//draw_scale == 0, �����ս��
		Mat show_origin = Mat(image_pixel_h, image_pixel_w, CV_8UC3, Scalar(255, 255, 255));
		int _0x = 10, _0y = 10;
		int empty_tile = 0;
		double error = 0;
		
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (_H_temp[i][j] >= 0 && _H_temp[i][j] < total_Tiles.size())
				{
					total_Tiles[_H_temp[i][j]].draw_Tile(show_origin, Point2f(_0x + j*(Color_[0].edge_length + 0), _0y + i*(Color_[0].edge_length + 0)));
				}
			}
		}
		imwrite(result_path+ "temp_tiling.png", show_origin);
	}

	void Multi_Patch::box_s_patch(int size)
	{
		box_patch.size = size;
		Patch pt;
		vector<int>cmpp;
		set<vector<int> >qc;
		pt.M = size;
		pt.N = size;
		int cnt = 0;
		for (int i = 0; i < M; i += size)
		{
			for (int j = 0; j < N; j += size)
			{
				cmpp.clear();
				if (i + size >= M || j + size >= N)
					continue;
				cnt++;
				for (int k1 = 0; k1 < size; k1++)
				{
					for (int k2 = 0; k2 < size; k2++)
					{
						pt.wg[k1][k2] = _H[i + k1][j + k2];
						cmpp.push_back(_H[i + k1][j + k2]);
					}
				}
				if (qc.count(cmpp) != 0)
					continue;
				else
				{
					qc.insert(cmpp);
					box_patch.patch.push_back(pt);
				}
			}
		}
		cout << "box select patch number:" << box_patch.patch.size() << " " << cnt << endl;
	}
	void Multi_Patch::pre_process(int p_size)
	{
		sort_density.clear();
		pre_density.clear();
		freq_priority.clear();
		vector<int> density_times;
		int interval = 1;
		if (cluster_steps) interval = p_size;
		//sliding windows to analyse: scale-1=3
		for (int i = p_size - 1; i < M; i = i + interval)
		{
			vector<double> freq_pri;
			for (int j = p_size - 1; j < N; j = j + interval)
			{
				vector<double> tt;
				int flag = 0;
				for (int k1 = p_size - 1; k1 >= 0; k1--)
				{
					for (int k2 = p_size - 1; k2 >= 0; k2--)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							flag = 1;
							break;
						}
					}
				}
				if (flag == 1)
					continue;
				vector<double> window_image;
				for (int k1 = p_size - 1; k1 >= 0; k1--)
				{
					for (int k2 = p_size - 1; k2 >= 0; k2--)
					{
						tt.push_back(normalize(density_d[i - k1][j - k2], density_gradient));
						//������������ܶ��Լ�����Ƶ�ʸߵ�
						window_image.push_back(density_d[i - k1][j - k2]);
					}
				}
				/*if (pre_density[tt] >= 0)
				pre_density[tt]++;
				else
				pre_density[tt] = 1;*/

				//new
				int flag_ = 0;
				for (int d_index = 0; d_index < density_situ.size(); d_index++)
				{
					if (equal_vec(tt, density_situ[d_index]))
					{
						all_distru_index.push_back(d_index);
						density_times[d_index]++;
						flag_ = 1;
						break;
					}
				}
				if (flag_ == 0)
				{
					density_situ.push_back(tt);
					density_times.push_back(1);
					all_distru_index.push_back(density_situ.size() - 1);

				}
				//�����Ƶ�ʲ�ֵ�󱣴浽���ȼ�������
				//freq_pri.push_back(measure_high_frequency(window_image));
			}
			//freq_priority.push_back(freq_pri);
		}
		int d = 3;
		while (d > 0)
		{
			if (patch_size[d - 1] == p_size) break;
			d--;
		}
		/*cout << "There are " << pre_density.size() << " different density distributions for " << d << " scale patches!" << endl;
		vector<PAIR> s_t(pre_density.begin(), pre_density.end());*/
		cout << "There are " << density_times.size() << " different density distributions for " << d << " scale patches!" << endl;
		vector<PAIR> s_t;
		for (int g = 0; g < density_times.size(); g++)
		{
			s_t.push_back(make_pair(density_situ[g], density_times[g]));
		}
		//sort(s_t.begin(), s_t.end(), cmp_pre_process);
		for (int i = 0, index = 0; i < s_t.size(); i++)
		{
			if (index > topNum_clus)
				break;
			//��Ƶ�ľ���ֱ������
			//if (measure_high_frequency(s_t[i].first) < 0.15)
			//{
			//	//cout << i << " s_t is low frequency!" << endl;
			//	continue;
			//}
			//cout << "s_t[" << i << "]: " << s_t[i].second << endl;
			index++;
			sort_density.push_back(s_t[i]);

			/*cout << "sort_density: " << s_t[i].second << endl;
			for (int d = 0; d < s_t[i].first.size(); d++)
			cout << s_t[i].first[d] << " ";
			cout << endl;*/
		}
	}
	void Multi_Patch::re_pre_process(int p_size, int cho_distribution_num)
	{
		map<vector<double>, int> pre_density_rotate;
		sort_density.clear();
		pre_density.clear();
		int interval = 1;
		if (cluster_steps) interval = p_size;
		for (int i = p_size - 1; i < M; i = i + interval)
		{
			for (int j = p_size - 1; j < N; j = j + interval)
			{
				vector<double> tt;
				int flag = 0;
				for (int k1 = scale - 1; k1 >= 0; k1--)
				{
					for (int k2 = scale - 1; k2 >= 0; k2--)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							flag = 1;
							break;
						}
					}
				}
				if (flag == 1)
					continue;

				for (int k1 = p_size - 1; k1 >= 0; k1--)
				{
					for (int k2 = p_size - 1; k2 >= 0; k2--)
					{
						tt.push_back(normalize(density_d[i - k1][j - k2], density_gradient));
					}
				}
				if (pre_density[tt] >= 0)
					pre_density[tt]++;
				else
					pre_density[tt] = 1;
			}
		}

		//����תpatch
		map<vector<double>, int>::iterator it1;
		map<vector<double>, int>::iterator it2;;
		for (it1 = pre_density.begin(); it1 != pre_density.end(); it1++)
		{
			pre_density_rotate[it1->first] = 1;
			for (it2 = pre_density.begin(); it2 != pre_density.end(); it2++)
			{
				if (it1 == it2)
					continue;
				for (int i = 0; i < 4; i++)
				{
					double error = match_error(rotate(it1->first, i), it2->first);
					if (error < threshold_rotate)
					{
						//cout << i << " " << error << endl;
						pre_density_rotate[it1->first]++;
						break;
						/*for (int j = 0; j < it1->first.size(); j++)
						{
						cout << it1->first[j] << " ";
						}
						cout << endl;
						for (int j = 0; j < it2->first.size(); j++)
						{
						cout << it2->first[j] << " ";
						}
						cout << endl;*/
					}
				}

			}
		}
		vector<PAIR> s_t(pre_density_rotate.begin(), pre_density_rotate.end());//rotate����

		//vector<PAIR> s_t(pre_density.begin(), pre_density.end());
		sort(s_t.begin(), s_t.end(), cmp_pre_process);

		cout << "distribution number " << s_t.size() << endl;
		/*for (int i = 0; i < s_t.size(); i++)
		{
		if (i > cho_distribution_num)
		break;
		sort_density.push_back(s_t[i]);
		for (int j = 0; j < s_t[i].first.size(); j++)
		{
		cout << s_t[i].first[j] << " ";
		}
		cout << s_t[i].second << endl;
		}*/
		int cnt = 0;
		for (int i = 0; i < s_t.size(); i++)
		{
			/*if (cnt > cho_distribution_num)
				break;*/
			if (i == 0)
			{
				sort_density.push_back(s_t[i]);
				cnt++;
				cout << i << " distribution is: ";
				for (int jj = 0; jj < s_t[i].first.size(); jj++)
				{
					cout << s_t[i].first[jj] << " ";
				}
				cout << s_t[i].second << endl;
			}
			else
			{
				int flag = 1;
				for (int j = 0; j < sort_density.size(); j++)
				{
					
					for (int r = 0; r < 4; r++)
					{
						if (match_error(sort_density[j].first, rotate(s_t[i].first, r)) < threshold_rotate)
						{
							flag = 0;
							cout << i << " distribution is merged!" << endl;
							break;
						}
					}
					if (flag == 0)
						break;
				}
				if (flag != 0)
				{
					sort_density.push_back(s_t[i]);
					cnt++;
					cout << i << " distribution is: ";
					for (int jj = 0; jj < s_t[i].first.size(); jj++)
					{
						cout << s_t[i].first[jj] << " ";
					}
					cout << s_t[i].second << endl;
				}
			}
		}

		vector<vector<double> >sups;
		for (int i = 0; i < sort_density.size(); i++)
		{
			sups.push_back(sort_density[i].first);
		}
		draw_grey(result_path+ "old_gathering" + to_string(p_size) + ".png", sups);
	}
	void Multi_Patch::gathering_sup(int p_size)
	{
		map<vector<double>, int> pre_density_rotate;
		vector<vector<double> >sups;
		sort_density.clear();
		pre_density.clear();
		int interval = 1;
		if (cluster_steps) interval = p_size;
		for (int i = p_size - 1; i < M; i = i + interval)
		{
			for (int j = p_size - 1; j < N; j = j + interval)
			{
				vector<double> tt;
				int flag = 0;
				for (int k1 = scale - 1; k1 >= 0; k1--)
				{
					for (int k2 = scale - 1; k2 >= 0; k2--)
					{
						if (vis[i - k1][j - k2] != -1)
						{
							flag = 1;
							break;
						}
					}
				}
				if (flag == 1)
					continue;

				for (int k1 = p_size - 1; k1 >= 0; k1--)
				{
					for (int k2 = p_size - 1; k2 >= 0; k2--)
					{
						tt.push_back(normalize(density_d[i - k1][j - k2], density_gradient));
					}
				}
				if (pre_density.count(tt) > 0)
					pre_density[tt]++;
				else
				{
					pre_density[tt] = 1;
					
					sups.push_back(tt);
				}
				/*if (i == 87 && j == 3)
				{
					for (int kk = 0; kk < tt.size(); kk++)
						cout << tt[kk] << " ";
					cout << endl;
				}*/
			}
		}
		if (first_show == 1)
			draw_grey(result_path+ "all_sup_" + to_string(p_size) + ".png", sups);

		//1.�ֳ���������
		//2.���ݻҶȼ������ϸ��Ϊ4��level
		//3.ÿ��level��һ��ģ���ܶ�
		vector<vector<double> >diagonal, horizonal;
		vector<vector<double> >l1, l2, l3, l4, l5;
		gathering_two(diagonal, horizonal, p_size);
		if (first_show == 1)
		{
			draw_grey(result_path+ "dia_" + to_string(p_size) + ".png", diagonal);
			draw_grey(result_path+ "hor_" + to_string(p_size) + ".png", horizonal);
		}
		cout << "diagonal size " << diagonal.size() << endl;
		cout << "horizonal size " << horizonal.size() << endl;
		
		if (diagonal.size() != 0)
		{
			divide_level(diagonal, l1, l2, l3, l4, l5);
			cout << "diagonal each size " << l1.size() << " " << l2.size() << " " << l3.size() << " " << l4.size() << " " << l5.size() << endl;

			vector<vector<double> >temp1 = acquire_density(l1, 55);
			if (first_show == 1)
				draw_grey(result_path+ "dia_l1_" + to_string(p_size) + ".png", temp1);
			vector<vector<double> >temp2 = acquire_density(l2, 55);
			if (first_show == 1)
				draw_grey(result_path+ "dia_l2_" + to_string(p_size) + ".png", temp2);
			vector<vector<double> >temp3 = acquire_density(l3, 55);
			if (first_show == 1)
				draw_grey(result_path+ "dia_l3_" + to_string(p_size) + ".png", temp3);
			vector<vector<double> >temp4 = acquire_density(l4, 55);
			if (first_show == 1)
				draw_grey(result_path+ "dia_l4_" + to_string(p_size) + ".png", temp4);
			vector<vector<double> >temp5 = acquire_density(l5, 55);
			if (first_show == 1)
				draw_grey(result_path+ "dia_l5_" + to_string(p_size) + ".png", temp5);

			vector<double> model_density = average_density(l1);//����pre-density�еĴ���
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l2);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l3);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l4);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l5);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
		}
		
		if (horizonal.size() != 0)
		{
			divide_level(horizonal, l1, l2, l3, l4, l5);
			cout << "horizonal each size " << l1.size() << " " << l2.size() << " " << l3.size() << " " << l4.size() << " " << l5.size() << endl;

			vector<vector<double> >temp1 = acquire_density(l1, 55);
			if (first_show == 1)
				draw_grey(result_path+ "hor_l1_" + to_string(p_size) + ".png", temp1);
			vector<vector<double> >temp2 = acquire_density(l2, 55);
			if (first_show == 1)
				draw_grey(result_path+ "hor_l2_" + to_string(p_size) + ".png", temp2);
			vector<vector<double> >temp3 = acquire_density(l3, 55);
			if (first_show == 1)
				draw_grey(result_path+ "hor_l3_" + to_string(p_size) + ".png", temp3);
			vector<vector<double> >temp4 = acquire_density(l4, 55);
			if (first_show == 1)
				draw_grey(result_path+ "hor_l4_" + to_string(p_size) + ".png", temp4);
			vector<vector<double> >temp5 = acquire_density(l5, 55);
			if (first_show == 1)
				draw_grey(result_path+ "hor_l5_" + to_string(p_size) + ".png", temp5);

			vector<double> model_density = average_density(l1);//����pre-density�еĴ���
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l2);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l3);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l4);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
			model_density = average_density(l5);
			if (model_density.size() != 0)
				sort_density.push_back(make_pair(model_density, 1));
		}

		sups.clear();
		for (int i = 0; i < sort_density.size(); i++)
		{
			sups.push_back(sort_density[i].first);
		}
		if (first_show == 1)
			draw_grey(result_path+ "new_gathering_" + to_string(p_size) + ".png", sups);
	}
	void Multi_Patch::gathering_two(vector<vector<double> >&diagonal, vector<vector<double> >&horizonal, int size)
	{
		//int dir[8] = { 135,90,45,180,0, };
		int d[8][2] = { -1,-1,-1,0,-1,1,0,-1,0,1,1,-1,1,0,1,1 };
		//1.�жϷ���
		//2.����Ƿ����ݶȷ��򵥵�
		map<vector<double>, int>::iterator it1;
		for (it1 = pre_density.begin(); it1 != pre_density.end(); it1++)
		{
			/*for (int i = 0; i < it1->first.size(); i++)
				cout << it1->first[i] << " ";
			cout << endl;*/

			/*double a[16] = { 0.8,0.7,0.35,0.35,0.8,0.75,0.4,0.35,0.8,0.75,0.4,0.35,0.8,0.75,0.4,0.35 };
			vector<double> vec(a, a + 16);
			if (is_equal_vector(it1->first, vec))
				cout << "find" << endl;*/

			Point2f p(0, 0);//ÿ��sup���ݶȷ���
			int angle = 0;
			for (int ii = 0; ii < it1->first.size(); ii++)
			{
				int i = ii / size;
				int j = ii%size;
				
				double x = 0, y = 0;
				for (int k = 0; k<8; k++)
				{
					int dx = i + d[k][0];
					int dy = j + d[k][1];
					if (dx >= 0 && dx < size && dy >= 0 && dy < size)
					{
						x = x + d[k][0] * (it1->first[dx*size + dy] - it1->first[i*size + j]);
						y = y + d[k][1] * (it1->first[dx*size + dy] - it1->first[i*size + j]);
					}
				}
				p.x += x;
				p.y += y;

				/*double max_density = -10;
				int pos = -1;
				for (int j = 0; j < 9; j++)
				{
					int dx = x + d[j][0];
					int dy = y + d[j][1];
					if (dx >= 0 && dx < size&&dy >= 0 && dy < size)
					{
						if (it1->first[dx*size + dy] - it1->first[i] > max_density)
						{
							max_density = it1->first[dx*size + dy] - it1->first[i];
							pos = j;
						}
					}
				}
				cout << pos << endl;
				p.x += d[pos][0];
				p.y += d[pos][1];*/
			}
			
		
			double angle_ = p.y / sqrt(pow(p.x, 2) + pow(p.y, 2));
			angle = acos(angle_)*(180 / PI);
			//cout << p.x << " " << p.y << endl;
			//cout << angle << endl;

			if (sqrt(pow(p.x, 2) + pow(p.y, 2)) < 2)
				continue;
			double angle_thres = 10;
			if ((angle <= angle_thres) || ((angle >= 90 - angle_thres) && (angle <= 90 + angle_thres)) || (angle >= 180 - angle_thres))//��������
			{
				//add �ж��Ƿ񵥵�
				if (angle <= angle_thres)
				{
					vector<double> temp = rotate(it1->first, 2);
					if (is_monotonic(temp, 1))
						horizonal.push_back(temp);
				}
				else if ((angle >= 90 - angle_thres && angle <= 90 + angle_thres) && p.x < 0)
				{
					vector<double> temp = rotate(it1->first, 1);
					if (is_monotonic(temp, 1))
						horizonal.push_back(temp);
				}
				else if ((angle >= 90 - angle_thres && angle <= 90 + angle_thres) && p.x >= 0)
				{
					vector<double> temp = rotate(it1->first, 3);
					if (is_monotonic(temp, 1))
						horizonal.push_back(temp);
				}
				else
				{
					vector<double> temp = rotate(it1->first, 0);
					if (is_monotonic(temp, 1))
						horizonal.push_back(temp);
				}
			}
			else if ((angle > 45 - angle_thres&&angle < 45 + angle_thres) || (angle > 135 - angle_thres&&angle < 135 + angle_thres))
			{

				//add �ж��Ƿ񵥵�
				if (angle > angle_thres && angle < 90 - angle_thres && p.x < 0)
				{
					vector<double> temp = rotate(it1->first, 1);
					if (is_monotonic(temp, 2))
						diagonal.push_back(temp);
				}
				else if (angle > angle_thres && angle < 90 - angle_thres && p.x >= 0)
				{
					vector<double> temp = rotate(it1->first, 2);
					if (is_monotonic(temp, 2))
						diagonal.push_back(temp);
				}
				else if (angle > 90 + angle_thres && angle < 180 - angle_thres && p.x >= 0)
				{
					vector<double> temp = rotate(it1->first, 3);
					if (is_monotonic(temp, 2))
						diagonal.push_back(temp);
				}
				else
				{
					vector<double> temp = rotate(it1->first, 0);
					if (is_monotonic(temp, 2))
						diagonal.push_back(temp);
				}
			}
		}
	}

	void Multi_Patch::divide_level(vector<vector<double>> all_sup, vector<vector<double>> &l1, vector<vector<double>> &l2, vector<vector<double>> &l3, vector<vector<double>> &l4, vector<vector<double>> &l5)
	{
		double threshold = 0.1;
		l1.clear();
		l2.clear();
		l3.clear();
		l4.clear();
		l5.clear();
		
		/*l1.push_back(all_sup[0]);
		for (int i = 1; i < all_sup.size(); i++)
		{
			int push = 1;
			for (int j = 0; j < l1.size(); j++)
			{
				double error = match_error(all_sup[i], l1[j], 0, 1, 0);
				if (error > threshold)
				{
					push = 0;
					break;
				}
			}
			if (push == 1)
			{
				l1.push_back(all_sup[i]);
				continue;
			}
			
			push = 1;
			if (l2.size() == 0)
			{
				l2.push_back(all_sup[i]);
				continue;
			}
			else
			{
				for (int j = 0; j < l2.size(); j++)
				{
					double error = match_error(all_sup[i], l2[j], 0, 1, 0);
					if (error > threshold)
					{
						push = 0;
						break;
					}
				}
				if (push == 1)
				{
					l2.push_back(all_sup[i]);
					continue;
				}
			}	

			push = 1;
			if (l3.size() == 0)
			{
				l3.push_back(all_sup[i]);
				continue;
			}
			else
			{
				for (int j = 0; j < l3.size(); j++)
				{
					double error = match_error(all_sup[i], l3[j], 0, 1, 0);
					if (error > threshold)
					{
						push = 0;
						break;
					}
				}
				if (push == 1)
				{
					l3.push_back(all_sup[i]);
					continue;
				}
			}

			push = 1;
			if (l4.size() == 0)
			{
				l4.push_back(all_sup[i]);
				continue;
			}
			else
			{
				for (int j = 0; j < l4.size(); j++)
				{
					double error = match_error(all_sup[i], l1[j], 0, 1, 0);
					if (error > threshold)
					{
						push = 0;
						break;
					}
				}
				if (push == 1)
				{
					l4.push_back(all_sup[i]);
					continue;
				}
			}
		}*/

		for (int i = 0; i < all_sup.size(); i++)
		{
			double ave_den = 0;
			double max_den = -1;
			for (int j = 0; j < all_sup[i].size(); j++)
			{
				ave_den += all_sup[i][j];
				max_den = max(max_den, all_sup[i][j]);
			}
			ave_den /= all_sup[i].size();
			if (ave_den < threshold + 0.25)
				l1.push_back(all_sup[i]);
			else if (ave_den >= threshold + 0.25&&ave_den < 2 * threshold + 0.25)
				l2.push_back(all_sup[i]);
			else if (ave_den >= 2 * threshold + 0.25&&ave_den < 3 * threshold + 0.25)
				l3.push_back(all_sup[i]);
			else if (ave_den >= 3 * threshold + 0.25&&ave_den < 4 * threshold + 0.25)
				l4.push_back(all_sup[i]);
			else
				l5.push_back(all_sup[i]);
		}
	}

	vector<double> Multi_Patch::average_density(vector<vector<double>> vec)
	{
		if (vec.size() == 0)
			return vector<double>();

		else if (vec.size() == 1)
			return vec[0];

		vector<double> ave = vec[0];

		int rr = 0;
		vector<double> temp1;
		while (rr < 4)
		{
			if (pre_density.count(rotate(vec[0], rr)) > 0)
			{
				temp1 = rotate(vec[0], rr);
				break;
			}
			rr++;
		}
		int num = pre_density[temp1];
		for (int j = 0; j < vec[0].size(); j++)
			ave[j] *= num;

		for (int i = 1; i < vec.size(); i++)
		{
			int r = 0;
			vector<double> temp = vec[i];
			while (r < 4)
			{
				if (pre_density.count(rotate(vec[i], r)) > 0)
				{
					temp = rotate(vec[i], r);
					break;
				}
				r++;
			}
			for (int j = 0; j < vec[i].size(); j++)
			{
				ave[j] += (vec[i][j] * pre_density[temp]);
			}
			num += pre_density[temp];
		}
		for (int i = 0; i < ave.size(); i++)
		{
			ave[i] /= num;
			cout << ave[i] << " ";
		}
		cout << num << endl;
		return ave;
	}
	
	void Multi_Patch::regeneration(vector<Tile> total_Tiles, vector<CS> Color_, int scale)
	{
		cout << endl << "Tile and regeneration " << scale << " scale patches dynamically!" << endl;
		double distribution[5] = { 0, 0.4, 0.6, 0.8, 1.0 };
		int patch_scale = scale - 1;
		int p_index = patch_size[patch_scale] - 1;

		judge_frequency(p_index + 1);
		//if (scale == 3) draw_rest("den_fre.png");
		if (scale != 1)
		{
			cout << "Tiling " << scale << " scale tiles!" << endl;
			tiling_each_scale(p_index, total_Tiles, Color_);
		}
		//tiling_each_scale_bidirection(p_index, total_Tiles, Color_,3,3);
		else if (scale == 1)
			return;

		int cnt = 0;
		draw_used_Patch(cnt, patch_scale, total_Tiles, Color_);
		int dis_num = topNum_clus - 1;
		cout << endl << "Iteratively regenerate the " << scale << " scale patches" << endl << endl;
		//while (cnt < 5) //����5��
		int flag = 0;
		//draw_all_Patch(1, total_Tiles, Color_, result_path+ "initial_data.txt");
		draw_tiling(total_Tiles, Color_, scale, 0);
		//draw_rest("rest_image_initial.png");
		int last_patchNum = 0;
		cout << "patch_g[patch_scale].patch.size())" << patch_g[patch_scale].patch.size() << endl;
		while (/*tiled_reign() < distribution[4] &&*/ (last_patchNum != patch_g[patch_scale].patch.size()) && (cnt < iter_num))
		{
			last_patchNum = patch_g[patch_scale].patch.size();
			flag = 0;
			dis_num++;
			/*for (int i = 0; i < patch_g[patch_scale].patch.size(); i++)
			{
				if (patch_g[patch_scale].patch[i].used_time == 0)
				{
					flag = 1;
					break;
				}
			}
			if (flag == 0)
			{
				cout << "No unused patches......" << endl;
				break;
			}*/
			//re_pre_process(patch_size[patch_scale], dis_num);//����ѡ�ֲ�
			gathering_sup(patch_size[patch_scale]);
			first_show = 0;
			vector<pair<Patch, int>> sup_patch = patch_g[patch_scale].set_unused_patch(total_Tiles, Color_, sort_density);//�����·ֲ���������patch

			if (replace)//�滻�Ѿ��̺õ�
			{
				int add_num = re_tiling_each_scale_waiting(p_index, total_Tiles, Color_, sup_patch);
			}
			else
			{
				int add_num = re_tiling_each_scale(p_index, total_Tiles, Color_, sup_patch);
			}

			//cout << cnt << " iteration total number of patch set: " << patch_g[scale - 1].patch.size() << endl;
			draw_used_Patch(cnt + 1, patch_scale, total_Tiles, Color_);
			//draw_special_tiling(total_Tiles, Color_, 0);
			draw_tiling(total_Tiles, Color_, scale, ++cnt);
			//draw_tiling(total_Tiles, Color_);
			//if (sort_density.size() < dis_num - 1)
			//{
			//	cout << "sort_density.size() < dis_num! " << endl;
			//	break; //ȫ�����ɹ���, ����Ҫ�ٵ���
			//}
			//if (add_num < 5)
			//{
			//	cout << "No enough new patch generated! " << endl;
			//	break; //����5������patch
			//}
		}
		if (cnt == iter_num) cout << "Iterated " << iter_num <<" times over!" << endl;
		//--------------------show all_distru_index------------------
		//for (int g = 0; g < four_tiling_index.size(); g++)
		//{
		//	cout << "the " << g << " area' density is the " << all_distru_index[g] << endl;
		//	/*for (int q = 0; q < density_situ[all_distru_index[g]].size(); q++)
		//		cout << density_situ[all_distru_index[g]][q] << " ";*/
		//	cout << endl << "the " << g << " area tile patch " << four_tiling_index[g] << endl;
		//	cout << "used patch is generated according to density " << patch_g[patch_scale].patch_error[four_tiling_index[g]].first << endl;
		//	/*for (int q = 0; q < density_situ[all_distru_index[g]].size(); q++)
		//		cout << density_situ[patch_g[patch_scale].patch_error[four_tiling_index[g]].first][q] << " ";
		//	cout << endl;
		//	for (int m = 0; m < 4; m++)
		//		for (int n = 0; n < 4; n++)
		//			cout << total_Tiles[patch_g[patch_scale].patch[four_tiling_index[g]].wg[m][n]].black_pic / pow(tile_edge_length, 2) << " ";*/
		//}
		cout << "tiled reign " << tiled_reign() << " cnt " << cnt << endl;
		return;
	}
	void Multi_Patch::design_reign()
	{
		ifstream in("flag.txt");
		if (in)
		{
			if (box_flags) cout << "Load flag.txt and set onetile[][]." << endl << endl;
			else cout << "Do not use box selection." << endl;
		}
		else cout << "Cannot find flag.txt, set onetile[][] as 0!" << endl << endl;
		
		memset(vis, -1, sizeof(vis));
		memset(last_vis, -1, sizeof(vis));
		memset(onetile, 0, sizeof(onetile));
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{

				if (density_d[i][j] <= density_margin)
				{
					vis[i][j] = 1;
					last_vis[i][j] = 1;
				}
				if (box_flags) in >> onetile[i][j];
				else onetile[i][j] = 0;
			}
		}

		/*for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				cout << onetile[i][j] << " ";
			}
			cout << endl;
		}*/
	}

	double Multi_Patch::tiled_reign()
	{
		int cnt = 0;
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (vis[i][j] != -1)
					cnt++;
			}
		}
		return cnt*1.0 / (M*N);
	}

	

	void Multi_Patch::set_sort_density(int patch_scale) //---------------lxk
	{
		sort_density.clear();
		if (patch_scale == 1)
		{
			double d[20] = { 0.0, 0.15, 0.22, 0.29, 0.36, 0.43, 0.5, 0.57, 0.64, 0.71, 0.78, 0.85, 0.9 };
			//double d[11] = { 0.0, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85 };
			vector<vector<double>> all_density = {
				{ d[1] },
				{ d[2] },
				{ d[3] },
				{ d[4] },
				{ d[5] },
				{ d[6] },
				{ d[7] },
				{ d[8] },
				{ d[9] }, 
				{ d[10] }, 
				{ d[11] }, 
				{ d[12] }, };
			for (int i = 0; i < all_density.size(); i++)
			{
				vector<double> tt = all_density[i];
				sort_density.push_back(make_pair(tt, 1));
			}
		}
		if (patch_scale == 2)
		{
			//double d[8] = { 0.0, 0.2, 0.4, 0.6, 0.8, 0.3,0.5,0.7 };
			//double d[11] = { 0.0, 0.15, 0.25, 0.35, 0.45, 0.5, 0.55, 0.65, 0.75, 0.85 };
			double d[11] = { 0.0, 0.22, 0.31, 0.4, 0.49, 0.5, 0.58, 0.67, 0.76, 0.85 };
			vector<vector<double>> all_density = {
				{ d[1], d[1], d[1], d[1] },
				{ d[2], d[2], d[2], d[2] },
				{ d[3], d[3], d[3], d[3] },
				{ d[4], d[4], d[4], d[4] },
				//{ d[5], d[5], d[5], d[5] },
				{ d[6], d[6], d[6], d[6] },
				{ d[7], d[7], d[7], d[7] },
				{ d[8], d[8], d[8], d[8] },
				{ d[9], d[9], d[9], d[9] },
				/*{ d[10], d[10], d[10], d[10] }*/ };
			for (int i = 0; i < all_density.size(); i++)
			{
				vector<double> tt = all_density[i];
				sort_density.push_back(make_pair(tt, 1));
			}
			draw_grey(result_path + "intial_set2.png", all_density, true);
		}
		else if (patch_scale == 3)
		{
			//double d[11] = { 0.0, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9 };  //��0.06��ϸ�ߴ���
			//double d[11] = { 0.0, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.9 };
			//double d[11] = { 0.0, 0.2, 0.29, 0.38, 0.47, 0.56, 0.65, 0.74, 0.81, 0.9 };  //��0.1��ϸ�ߴ���

			//double d[11] = { 0.0, 0.22, 0.3, 0.38, 0.46, 0.54, 0.62, 0.7, 0.78, 0.86 };  //��0.1��ϸ�ߴ���
			double d[11] = { 0.0, 0.22, 0.31, 0.4, 0.49, 0.58, 0.67, 0.76, 0.85 };  //��0.1��ϸ�ߴ���
			vector<vector<double>> all_density = {
				{ d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1] },
				{ d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2] },
				{ d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3] },
				{ d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4] },
				{ d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5] },
				{ d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6] },
				{ d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7] },
				{ d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8] },

				{ d[8], d[6], d[4], d[2], d[8], d[6], d[4], d[2], d[8], d[6], d[4], d[2], d[8], d[6], d[4], d[2] }, //deep Straight line
				{ d[6], d[5], d[4], d[3], d[6], d[5], d[4], d[3], d[6], d[5], d[4], d[3], d[6], d[5], d[4], d[3] }, //light Straight line
				{ d[7], d[4], d[2], d[2], d[7], d[4], d[2], d[2], d[7], d[4], d[2], d[2], d[7], d[4], d[2], d[2] },  //slowly Straight changing I
				{ d[7], d[7], d[7], d[4], d[7], d[7], d[7], d[4], d[7], d[7], d[7], d[4], d[7], d[7], d[7], d[4] },  //slowly Straight changing II
				{ d[8], d[8], d[6], d[4], d[8], d[6], d[4], d[2], d[6], d[4], d[2], d[2], d[4], d[2], d[2], d[2] }, //diagonal	
				{ d[8], d[8], d[8], d[6], d[8], d[8], d[6], d[4], d[8], d[6], d[4], d[3], d[6], d[4], d[3], d[2] },  //deep diagonal
				{ d[8], d[8], d[7], d[6], d[8], d[7], d[6], d[5], d[7], d[6], d[5], d[4], d[6], d[5], d[4], d[4] },  //more deep diagonal
				{ d[8], d[8], d[6], d[2], d[8], d[6], d[2], d[1], d[6], d[2], d[1], d[1], d[2], d[1], d[1], d[1] }, //diagonal II

				/*{ d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1] },
				{ d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2] },
				{ d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3] },
				{ d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4] },
				{ d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5] },
				{ d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6] },
				{ d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7] },
				{ d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8] },*/
				//{ d[8], d[8], d[8], d[7], d[8], d[8], d[7], d[6], d[8], d[7], d[6], d[5], d[7], d[6], d[5], d[4] },  //more deep diagonal
				//{ 0.8, 0.6, 0.4, 0.2, 0.6, 0.8, 0.6, 0.4, 0.4, 0.6, 0.8, 0.6, 0.2, 0.4, 0.6, 0.8 }, //Oblique two wings	
				//{ 0.6, 0.6, 0.5, 0.4, 0.6, 0.5, 0.4, 0.3, 0.5, 0.4, 0.3, 0.2, 0.4, 0.4, 0.3, 0.2 },  //slowly diagonal changing
				 
				/*{ d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9] }*/
				/*{ d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10] } */ };
			for (int i = 0; i < all_density.size(); i++)
			{
				vector<double> tt = all_density[i];
				sort_density.push_back(make_pair(tt, 1));
			}

			draw_grey(result_path+ "intial_set3.png", all_density, true);
		}
		else if (patch_scale == 4)
		{
			double d[11] = { 0.0, 0.15, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, d[9] };
			vector<vector<double>> all_density;
			for (int m = 0; m < 8; m++)
			{
				vector<double> uniform_d;
				for (int n = 0; n < 64; n++)
				{
					uniform_d.push_back(d[m + 1]);
				}
				all_density.push_back(uniform_d);
			}
				
			//vector<vector<double>> all_density = {
			//	{ d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1], d[1] },
			//	{ d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2], d[2] },
			//	{ d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3], d[3] },
			//	{ d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4], d[4] },
			//	{ d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5], d[5] },
			//	{ d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6], d[6] },
			//	{ d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7], d[7] },
			//	{ d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8], d[8] },
			//	//{ 0.8, 0.6, 0.4, 0.2, 0.8, 0.6, 0.4, 0.2, 0.8, 0.6, 0.4, 0.2, 0.8, 0.6, 0.4, 0.2 }, //deep Straight line
			//	//{ 0.6, 0.5, 0.4, 0.3, 0.6, 0.5, 0.4, 0.3, 0.6, 0.5, 0.4, 0.3, 0.6, 0.5, 0.4, 0.3 }, //light Straight line
			//	//{ 0.7, 0.4, 0.2, 0.2, 0.7, 0.4, 0.2, 0.2, 0.7, 0.4, 0.2, 0.2, 0.7, 0.4, 0.2, 0.2 },  //slowly Straight changing I
			//	//{ 0.7, 0.7, 0.7, 0.4, 0.7, 0.7, 0.7, 0.4, 0.7, 0.7, 0.7, 0.4, 0.7, 0.7, 0.7, 0.4 },  //slowly Straight changing II
			//	//{ 0.8, 0.8, 0.6, 0.4, 0.8, 0.6, 0.4, 0.2, 0.6, 0.4, 0.2, 0.2, 0.4, 0.2, 0.2, 0.2 }, //diagonal	
			//	//{ 0.8, 0.8, 0.8, 0.6, 0.8, 0.8, 0.6, 0.4, 0.8, 0.6, 0.4, 0.3, 0.6, 0.4, 0.3, 0.2 },  //deep diagonal
			//	//{ 0.8, 0.8, 0.8, 0.7, 0.8, 0.8, 0.7, 0.6, 0.8, 0.7, 0.6, 0.5, 0.7, 0.6, 0.5, 0.4 },  //more deep diagonal
			//	//{ 0.8, 0.8, 0.6, 0.2, 0.8, 0.6, 0.2, 0.15, 0.6, 0.2, 0.15, 0.15, 0.2, 0.15, 0.15, 0.15 }, //diagonal II
			//	//{ 0.8, 0.6, 0.4, 0.2, 0.6, 0.8, 0.6, 0.4, 0.4, 0.6, 0.8, 0.6, 0.2, 0.4, 0.6, 0.8 }, //Oblique two wings	
			//	//{ 0.6, 0.6, 0.5, 0.4, 0.6, 0.5, 0.4, 0.3, 0.5, 0.4, 0.3, 0.2, 0.4, 0.4, 0.3, 0.2 },  //slowly diagonal changing

			//	/*{ d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9], d[9] }*/
			//	/*{ d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10], d[10] } */ };
			for (int i = 0; i < all_density.size(); i++)
			{
				vector<double> tt = all_density[i];
				sort_density.push_back(make_pair(tt, 1));
			}

			draw_grey(result_path+ "intial_set_4th.png", all_density, false);
		}

	}

	void Multi_Patch::test_show(vector<Tile> total_Tiles, vector<CS> Color_, vector<double> dent, vector<Patch> patches)
	{
		double min_e = 1000;
		int min_index = -1;
		vector<double> min_den;
		Patch min_p;
		int size = sqrt(dent.size());
		for (int i = 0; i < patches.size(); i++)
		{
			vector<double> den_p;
			Patch one_p = patches[i];
			for (int m = 0; m < size; m++)
			{
				for (int n = 0; n < size; n++)
				{
					Tile tt = total_Tiles[one_p.wg[m][n]];
					den_p.push_back(tt.black_pic / pow(tile_edge_length, 2));
				}
			}
			double err = match_error(dent, den_p);
			if (err < min_e)
			{
				min_e = err;
				min_index = i;
				min_den = den_p;
				min_p = one_p;
			}
		}
		cout << "min_error: " << min_e << "  min_index: " << min_index << endl;
		for (int t = 0; t < dent.size(); t++)
			cout << dent[t] << " ";
		cout << endl;
		for (int t = 0; t < min_den.size(); t++)
			cout << min_den[t] << " ";
		cout << endl;
		double error_ = 0;
		for (int t = 0; t < min_den.size(); t++)
			error_ += abs(dent[t] - min_den[t]);
		cout << "last error: " << error_ / size / size << endl;

		Mat show = Mat(600, 600, CV_8UC3, Scalar(255, 255, 255));
		Patch pt = min_p;
		int _0xx = 10;
		int _0yy = 10;
		int length_t = 78;

		for (int j = 0; j < size; j++)
		{
			for (int k = 0; k < size; k++)
			{
				total_Tiles[pt.wg[j][k]].change_position(Point2f(_0xx + k*(length_t), _0yy + (j + 1)*(length_t)));//Bottom���ϱߣ�Top���±ߣ������½����ϻ�
				total_Tiles[pt.wg[j][k]].draw_Tile(show);
				//Point2f shift = Point2f(-9 * j, 9 * i);
				total_Tiles[pt.wg[j][k]].draw_tileConts(show);
				//cout << j << "," << k << ": " << total_Tiles[pt.wg[j][k]].Left.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Right.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Top.edge_colorScheme.id << " " << total_Tiles[pt.wg[j][k]].Bottom.edge_colorScheme.id << endl;
			}
		}

		imshow("test show:", show);
	}
	void Multi_Patch::rotate_process(vector<Tile> total_Tiles)
	{
		rotate_pattern_link[sequenceConnect] = sequenceConnect;
		rotate_pattern_link[ltrbConnect] = trblConnect;
		rotate_pattern_link[rbltConnect] = bltrConnect;
		rotate_pattern_link[trblConnect] = rbltConnect;
		rotate_pattern_link[bltrConnect] = ltrbConnect;
		rotate_pattern_link[tlrbMidS] = lbtrMidS;
		rotate_pattern_link[ltbrMidS] = trlbMidS;
		rotate_pattern_link[trlbMidS] = ltbrMidS;
		rotate_pattern_link[lbtrMidS] = tlrbMidS;

		for (int i = 0; i < total_Tiles.size(); i++)
		{
			Tile t1 = total_Tiles[i];
			string s1 = "";
			char bb = '0' + t1.Bottom.id;
			char rr = '0' + t1.Right.id;
			char tt = '0' + t1.Top.id;
			char ll = '0' + t1.Left.id;
			s1 = s1 + bb + rr + tt + ll;
			for (int j = 0; j < total_Tiles.size(); j++)
			{
				Tile t2 = total_Tiles[j];
				string s2 = "";
				bb = '0' + t2.Bottom.id;
				rr = '0' + t2.Right.id;
				tt = '0' + t2.Top.id;
				ll = '0' + t2.Left.id;
				s2 = s2 + ll + bb + rr + tt;
				if (s1 == s2&&rotate_pattern_link[t1.content_type] == t2.content_type)
				{
					//cout << s1 << " " << s2 << endl;
					rotate_link[i] = j;
				}
			}
		}
		/*vector<Tile> temp_Tiles;
		vector<int> rotate_flag(total_Tiles.size(), 1);
		for (int i = 0; i < total_Tiles.size(); i++)
		{
			if (rotate_flag[i] == 0)
				continue;
			temp_Tiles.push_back(total_Tiles[i]);
			int j = i;
			while (1)
			{
				if (rotate_link[j] == i)
					break;
				j = rotate_link[j];
				rotate_flag[j] = 0;
			}
		}
		cout << temp_Tiles.size() << endl;
		total_Tiles.clear();
		total_Tiles = temp_Tiles;*/
	}

	void Multi_Patch::post_process(vector<Tile> total_Tiles, vector<CS> Color_, int scale)
	{
		cout << endl << "post process to merge similar " << scale << " scale patches." << endl << endl;
		int low_number = 5;
		double replace_threshold = 0.08;
		vector<Patch> patch = patch_g[scale].patch;
		cout << " patch.size(): " << patch.size() << endl;
		sort(patch.begin(), patch.end(), cmp_patch_rotate);//��ʱ���ı�ԭpatch
		map<int, int>::iterator it;
		int num_ = 0;
		for (it = patch_g[scale].class_id_time.begin(); it != patch_g[scale].class_id_time.end(); it++)
		{
			if (it->second > 0) num_++;
		}
		cout << " not zero size: " << num_ << endl;
		int change_flag = 0;
		bool stop = true;
		int change_number = 0;
		while (stop)
		{
			cout << patch_g[scale].class_id_time.size() << endl;
			change_flag = 0;
			for (it = patch_g[scale].class_id_time.begin(); it != patch_g[scale].class_id_time.end(); it++)
			{
				//cout << "it: "<<it->first << " " << it->second << endl;
				if (it->second > 0)
				{
					if (it->second < low_number)
						replace_threshold = 0.08;
					else
						replace_threshold = 0.04;
					//replace
					//0.find pos in patch set
					//1.find same edge patch in used patch
					//2.calculate the min match error
					//3.replace,chage patch set data
					int start = -1, end = -1;
					for (int j = 0; j < patch.size(); j++)
					{
						if (it->first == patch[j].class_id)
						{
							if (start == -1)
							{
								start = j;
								end = j;
							}
							else
								end = j;
						}
						else if (start != -1)
							break;
					}
					if (start == -1)
						continue;
					//1.1 find original patch
					//1.2 find rotate patch
					//cout << "start: "<<start << "  " << end << endl;
					for (int k = start; k <= end; k++)
					{
						if (patch[k].used_time <= 0)
							continue;
						int pos = -1;
						double error = 1000;
						Patch min_patch;
						for (int j = 0; j < patch.size(); j++)
						{
							if (patch[j].class_id == it->first)
								continue;
							if (patch[j].class_id == -1)
								continue;
							if (patch_g[scale].class_id_time[patch[j].class_id] == 0 || patch_g[scale].class_id_time[patch[j].class_id] == -1)
								continue;
							if (is_same_edge(patch[j], patch[k]))//�ϸ�same
							{
								double temp_error = cal_patch_error(total_Tiles, patch[j], patch[start], 4);
								if (temp_error < error)
								{
									error = temp_error;
									pos = j;
								}
							}
						}
						//�����original patch���ҵ��ˣ��Ͳ�����ת�������ˡ�����ת����ԭʼֻ�����ڱ߽���ͬ�����ܶȷֲ����ܴ󣬿����Բ���
						if (pos != -1)
						{
							if (error > replace_threshold)
								break;
							//chage tiling data
							for (int mm = 0; mm < M; mm += patch_size[scale])
							{
								for (int nn = 0; nn < N; nn += patch_size[scale])
								{
									if (_H_class[mm][nn] == scale)
									{
										if (_H_p[mm][nn] == patch[k].id)
										{
											for (int k1 = 0; k1 < patch_size[scale]; k1++)
											{
												for (int k2 = 0; k2 < patch_size[scale]; k2++)
												{
													//cout << _H[mm + k1][nn + k2] << " ";
													_H[mm + k1][nn + k2] = patch[pos].wg[k1][k2];
													//cout << patch[pos].wg[k1][k2] << " " << patch[k].wg[k1][k2] << " " << _H[mm + k1][nn + k2] << endl;
													//_H[mm + k1][nn + k2] = 1;
													_H_p[mm + k1][nn + k2] = patch[pos].id;
												}
											}//cout << pos << " " << k << endl;
										}
									}
								}
							}
							//change patch data
							patch_g[scale].class_id_time[patch[k].class_id] -= patch[k].used_time;
							cout << patch_g[scale].class_id_time[patch[k].class_id] << endl;
							patch_g[scale].class_id_time[patch[pos].class_id] += patch[k].used_time;
							patch[pos].used_time += patch[k].used_time;
							patch[k].used_time = 0;
							patch[k].class_id = -1;
							change_flag = 1;

							cout << "change " << it->first << " " << patch[pos].class_id << " " << error << endl;
						}
						else
						{
							//cout << "find rotate patch" << endl;
							//find rotate patch
							for (int j = 0; j < patch.size(); j++)
							{
								if (patch[j].class_id == it->first)
									continue;
								if (patch[j].class_id == -1)
									continue;
								if (patch_g[scale].class_id_time[patch[j].class_id] == 0 || patch_g[scale].class_id_time[patch[j].class_id] == -1)
									continue;
								Patch ptt = patch[j];
								ptt = patch_g[scale].add_rotate_patch(ptt, 0);
								if (is_same_edge(ptt, patch[k]))
								{
									double temp_error = cal_patch_error(total_Tiles, patch[j], patch[start], 4);
									if (temp_error < error)
									{
										error = temp_error;
										pos = j;
										min_patch = ptt;
									}
								}
							}
							if (pos != -1)
							{
								if (error > replace_threshold)
									break;
								//add new patch
								min_patch.id = patch.size();
								patch.push_back(min_patch);
								//chage tiling data
								for (int mm = 0; mm < M; mm += patch_size[scale])
								{
									for (int nn = 0; nn < N; nn += patch_size[scale])
									{
										if (_H_class[mm][nn] == scale)
										{
											if (_H_p[mm][nn] == patch[k].id)
											{
												for (int k1 = 0; k1 < patch_size[scale]; k1++)
												{
													for (int k2 = 0; k2 < patch_size[scale]; k2++)
													{
														_H[mm + k1][nn + k2] = min_patch.wg[k1][k2];
														_H_p[mm + k1][nn + k2] = min_patch.id;
													}
												}
											}
										}
									}
								}
								//change patch data
								patch_g[scale].class_id_time[patch[k].class_id] -= patch[k].used_time;
								patch[patch.size() - 1].used_time = patch[k].used_time;
								patch_g[scale].class_id_time[patch[patch.size() - 1].class_id] += patch[patch.size() - 1].used_time;
								patch[k].used_time = 0;
								patch[k].class_id = -1;
								change_flag = 1;

								cout << "change " << it->first << " " << patch[pos].class_id << " " << error << endl;
							}
						}
					}
					if (change_flag == 1)
					{
						change_number++;

						break;
					}
				}
			}
			patch_g[scale].patch = patch;
			if (change_flag == 0)
				stop = false;
		}
		num_ = 0;
		for (it = patch_g[scale].class_id_time.begin(); it != patch_g[scale].class_id_time.end(); it++)
		{
			if (it->second > 0) num_++;
		}
		cout << " not zero size: " << num_ << endl;
		cout << "change_number: "<<change_number << endl;
	}

	bool Multi_Patch::is_same_edge(Patch p1, Patch p2)
	{
		if (p1.wn == p2.wn&&p1.sn == p2.sn&&p1.nn == p2.nn&&p1.en == p2.en)
			return true;
		else
			return false;
	}

	double Multi_Patch::cal_patch_sup_error(vector<Tile> total_Tiles, int x, int y, Patch pt2, int scale)
	{
		vector<double> v1, v2;
		for (int i = 0; i < scale; i++)
		{
			for (int j = 0; j < scale; j++)
			{
				v1.push_back(density_d[x + i][y + j]);
				v2.push_back(total_Tiles[pt2.wg[i][j]].black_pic*1.0 / pow(tile_edge_length, 2));
			}
		}
		double error = match_error(v1, v2);
		return error;
	}
	void Multi_Patch::draw_rest(string name)
	{
		//show not tiled region
		Mat rest_region = imread(Input_Path);
		for (int j = 0; j < M; j++)
		{
			for (int k = 0; k < N; k++)
			{
				if (vis[j][k] != -1)
				{
					cv::Vec3b vec_3 = rest_region.at<cv::Vec3b>(j, k);
					vec_3[0] = 255;
					vec_3[1] = 255;
					vec_3[2] = 255;
					rest_region.at<cv::Vec3b>(j, k) = vec_3;
				}
			}
		}
		Mat ori_image = rest_region;
		int size_pre = Image_Width * 5000 / 100.0;
		int size_pre2 = Image_Height * 5000 / 100.0;
		resize(rest_region, rest_region, Size(size_pre, size_pre2));
		stringstream ss;
		ss.setf(ios::fixed);
		ss.precision(3);
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				ss << density_d[i][j];
				//int color = 255 * (1 - density_d[i][j]);
				Vec3b v = ori_image.at<cv::Vec3b>(i, j);
				Scalar color = Scalar(v[0], v[1], v[2]);
				rectangle(rest_region, Point(j * 50, i * 50), Point(j * 50 + 50, i * 50 + 50), color, -1);
				//rectangle(rest_region, Point(j * 50, i * 50), Point(j * 50 + 50, i * 50 + 50), Scalar(color, color, color), -1);
				putText(rest_region, to_string(int(density_d[i][j]*1000)/*atof(ss.str().c_str())*/), Point(j * 50, i * 50 + 15), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);
				if (i % 4 == 0)
					line(rest_region, Point(0, 50 * i), Point(5000, 50 * i), Scalar(0, 0, 0), 1);
				if (j % 4 == 0)
					line(rest_region, Point(50 * j, 0), Point(50 * j, 5000), Scalar(0, 0, 0), 1);
			}
		}
		for (int i = 0; i < M; i = i + 4)
		{
			for (int j = 0; j < N; j = j + 4)
			{
				//legal, record the density for tiling
				vector<double> density_dis;
				for (int k1 = 0; k1 < 4; k1++)
				{
					for (int k2 = 0; k2 <4; k2++)
					{
						density_dis.push_back(density_d[i + k1][j + k2]);
						//cout << density_d[i - k1][j - k2] << " ";
					}
				}
				putText(rest_region, to_string(measure_high_frequency_sober(density_dis)), Point(j * 50 + 25, i * 50 + 50), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 0, 255), 2);
				//putText(rest_region, to_string(measure_trend(density_dis)), Point(j * 50 + 25, i * 50 + 50), FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0, 0, 255), 2);
			}
		}

		//--11-23
		//int c = 0;
		//for (int i = 0; i < M; i++)
		//{
		//	for (int j = 0; j < N; j++)
		//	{
		//		double one_ptch_error = 0;
		//		int temp_d = density_d[i][j] * 100 / 10;
		//		double den_t = 0.1*temp_d;

		//		int color = 255 * (1 - den_t);
		//		rectangle(rest_region, Point(j * 50, i * 50), Point(j * 50 + 50, i * 50 + 50), Scalar(color, color, color), -1);
		//		one_ptch_error = density_d[i][j] - den_t;
		//		density_d[i][j] = den_t;

		//		//error-diffusion
		//		if (error_diffusion)
		//		{
		//			double quant_error = one_ptch_error / ((c + 1)*(c + 1));
		//			int cc = c + 1;

		//			//right
		//			Dithering(i, j + cc, c, 7.0 / 16, quant_error);
		//			//left-bottom
		//			Dithering(i + cc, j - cc, c, 3.0 / 16, quant_error);
		//			//bottom
		//			Dithering(i + cc, j, c, 5.0 / 16, quant_error);
		//			//right-bottom
		//			Dithering(i + cc, j + cc, c, 1.0 / 16, quant_error);

		//		}
		//	}
		//}
		//11-23
		
		imwrite(result_path+ "" + name, rest_region);
	}
	void Multi_Patch::clear_tiling(int scale)
	{
		int usedTime_threshold = 5;
		patch_g[scale-1].class_id_time.clear();
		for (int i = 0; i < patch_g[scale-1].patch.size(); i++)
		{
			Patch pt = patch_g[scale - 1].patch[i];
			if (pt.class_id == -1)
				continue;
			if (patch_g[scale - 1].class_id_time.count(pt.class_id) == 0)
			{
				patch_g[scale - 1].class_id_time[pt.class_id] = pt.used_time;
			}
			else
			{
				patch_g[scale - 1].class_id_time[pt.class_id] += pt.used_time;
			}
		}
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				last_vis[i][j] = vis[i][j];
			}
		}
		for (int i = 0; i < M; i++)
		{
			for (int j = 0; j < N; j++)
			{
				if (_H_class[i][j] == scale - 1)
				{
					//pre-define patch || dynamic gereration but used time less threshold
					if (_H_p[i][j] < patch_g[scale - 1].patch_bound.size() || patch_g[scale - 1].class_id_time[_H_p[i][j]] < usedTime_threshold)
					{
						int pos = patch_g[scale - 1].find_Patch(_H_p[i][j]);
						Patch pt = patch_g[scale - 1].patch[pos];
						pt.used_time--;
						patch_g[scale - 1].patch[pos] = pt;
						for (int k1 = 0; k1 < patch_size[scale - 1]; k1++)
						{
							for (int k2 = 0; k2 < patch_size[scale - 1]; k2++)
							{
								vis[i + k1][j + k2] = -1;
								_H[i + k1][j + k2] = -1;
								_H_p[i + k1][j + k2] = -1;
								_H_class[i + k1][j + k2] = -1;
							}
						}
					}
				}
			}
		}
	}
	bool Multi_Patch::can_tile(Patch pt, vector<Tile> total_tiles, int x, int y, vector<int>& replace_position, int scale)//x,y���Ͻ�
	{
		vector<int> replace_position_temp;
		double replace_threshold = 0.2;
		int i = x - x%patch_size[scale];
		int j = y - y%patch_size[scale];
		int pass_num = 0;
		//1.�ж��Ƿ�߽�������ͬ
		//2.�߽粻��ͬ���ж��ܷ��滻
		if (i - patch_size[scale] >= 0)//top
		{
			if (_H_class[i - patch_size[scale]][j] == -1 && _H_p[i - patch_size[scale]][j] == -1)//δ��
			{
				pass_num++;
			}
			else
			{
				int if_match = 1;
				if (i - 1 >= 0)
				{
					for (int k1 = 0; k1 < patch_size[scale]; k1++)
					{
						if (total_tiles[_H[i - 1][j + k1]].Top.id != total_tiles[pt.wg[0][k1]].Bottom.id)
						{
							if_match = 0;
							break;
						}
					}
				}
				if (if_match == 1)
				{
					pass_num++;
				}
				else//replace
				{
					if (_H_class[i - patch_size[scale]][j] != -1)//same scale patch,can replace
					{
						Patch pt1 = patch_g[scale].patch[_H_p[i - patch_size[scale]][j]];
						Patch pt2 = pt1;
						pt2.sn = pt.nn;
						int pos = patch_g[scale].find_patch_edge(pt2);
						/*cout << pos << endl;
						cout << pt2.wn << " " << pt2.nn << " " << pt2.en << " " << pt2.sn << endl;*/
						if (pos != -1)
						{
							pt2 = patch_g[scale].patch[pos];
							//double error = cal_patch_error(total_tiles, pt1, pt2, patch_size[scale]);
							double error = cal_patch_sup_error(total_tiles, i - patch_size[scale], j, pt2, patch_size[scale]);
							if (error < replace_threshold)
							{
								replace_position_temp.push_back(i - 1);
								replace_position_temp.push_back(j + patch_size[scale] - 1);
								replace_position_temp.push_back(pos);
								replace_position_temp.push_back(_H_p[i - patch_size[scale]][j]);
								pass_num++;
							}
						}
					}
				}
			}
		}
		else
			pass_num++;

		if (i + patch_size[scale] < M)//bottom
		{
			if (_H_class[i + patch_size[scale]][j] == -1 && _H_p[i + patch_size[scale]][j] == -1)//δ��
			{
				pass_num++;
			}
			else
			{
				int if_match = 1;
				if (i + patch_size[scale] < M)
				{
					for (int k1 = 0; k1 < patch_size[scale]; k1++)
					{
						if (total_tiles[_H[i + patch_size[scale]][j + k1]].Bottom.id != total_tiles[pt.wg[patch_size[scale] - 1][k1]].Top.id)
						{
							if_match = 0;
							break;
						}
					}
				}
				if (if_match == 1)
				{
					pass_num++;
				}
				else//replace
				{
					if (_H_class[i + patch_size[scale]][j] != -1)//same scale patch,can replace
					{
						Patch pt1 = patch_g[scale].patch[_H_p[i + patch_size[scale]][j]];
						Patch pt2 = pt1;
						pt2.nn = pt.sn;
						int pos = patch_g[scale].find_patch_edge(pt2);
						/*cout << pos << endl;
						cout << pt2.wn << " " << pt2.nn << " " << pt2.en << " " << pt2.sn << endl;*/
						if (pos != -1)
						{
							pt2 = patch_g[scale].patch[pos];
							//double error = cal_patch_error(total_tiles, pt1, pt2, patch_size[scale]);
							double error = cal_patch_sup_error(total_tiles, i + patch_size[scale], j, pt2, patch_size[scale]);
							if (error < replace_threshold)
							{
								replace_position_temp.push_back(i + 2 * patch_size[scale] - 1);
								replace_position_temp.push_back(j + patch_size[scale] - 1);
								replace_position_temp.push_back(pos);
								replace_position_temp.push_back(_H_p[i + patch_size[scale]][j]);
								pass_num++;
							}
						}
					}
				}
			}
		}
		else
			pass_num++;

		if (j - patch_size[scale] >= 0)//left
		{
			if (_H_class[i][j - patch_size[scale]] == -1 && _H_p[i][j - patch_size[scale]] == -1)//δ��
			{
				pass_num++;
			}
			else
			{
				int if_match = 1;
				for (int k1 = 0; k1 < patch_size[scale]; k1++)
				{
					if (total_tiles[_H[i + k1][j - 1]].Right.id != total_tiles[pt.wg[k1][0]].Left.id)
					{
						if_match = 0;
						break;
					}
				}
				if (if_match == 1)
				{
					pass_num++;
				}
				else//replace
				{
					if (_H_class[i][j - patch_size[scale]] != -1)//same scale patch,can replace
					{
						Patch pt1 = patch_g[scale].patch[_H_p[i][j - patch_size[scale]]];
						Patch pt2 = pt1;
						pt2.en = pt.wn;
						int pos = patch_g[scale].find_patch_edge(pt2);
						cout << pos << endl;
						cout << pt2.wn << " " << pt2.nn << " " << pt2.en << " " << pt2.sn << endl;
						if (pos != -1)
						{
							pt2 = patch_g[scale].patch[pos];
							//double error = cal_patch_error(total_tiles, pt1, pt2, patch_size[scale]);
							double error = cal_patch_sup_error(total_tiles, i, j - patch_size[scale], pt2, patch_size[scale]);
							if (error < replace_threshold)
							{
								replace_position.push_back(i + patch_size[scale] - 1);
								replace_position.push_back(j - 1);
								replace_position.push_back(pos);
								replace_position.push_back(_H_p[i][j - patch_size[scale]]);
								pass_num++;
							}
						}
					}
				}
			}
		}
		else
			pass_num++;
		
		if (j + patch_size[scale] < N)//right
		{
			if (_H_class[i][j + patch_size[scale]] == -1 && _H_p[i][j + patch_size[scale]] == -1)//δ��
			{
				pass_num++;
			}
			else
			{
				int if_match = 1;
				for (int k1 = 0; k1 < patch_size[scale]; k1++)
				{
					cout << _H[i + k1][j + patch_size[scale]] << " " << pt.wg[k1][patch_size[scale] - 1] << endl;

					if (total_tiles[_H[i + k1][j + patch_size[scale]]].Left.id != total_tiles[pt.wg[k1][patch_size[scale] - 1]].Right.id)
					{
						if_match = 0;
						break;
					}
				}
				if (if_match == 1)
				{
					pass_num++;
				}
				else//replace
				{
					if (_H_class[i][j + patch_size[scale]] != -1)//same scale patch,can replace
					{
						Patch pt1 = patch_g[scale].patch[_H_p[i][j + patch_size[scale]]];
						Patch pt2 = pt1;
						pt2.wn = pt.en;
						int pos = patch_g[scale].find_patch_edge(pt2);
						/*cout << pos << endl;
						cout << pt2.wn << " " << pt2.nn << " " << pt2.en << " " << pt2.sn << endl;*/
						if (pos != -1)
						{
							pt2 = patch_g[scale].patch[pos];
							//double error = cal_patch_error(total_tiles, pt1, pt2, patch_size[scale]);
							double error = cal_patch_sup_error(total_tiles, i, j + patch_size[scale], pt2, patch_size[scale]);
							if (error < replace_threshold)
							{
								replace_position_temp.push_back(i + patch_size[scale] - 1);
								replace_position_temp.push_back(j + 2 * patch_size[scale] - 1);
								replace_position_temp.push_back(pos);
								replace_position_temp.push_back(_H_p[i][j + patch_size[scale]]);
								pass_num++;
							}
						}
					}
				}
			}
		}
		else
			pass_num++;
		
		if (pass_num >= 4)
		{
			for (int i = 0; i < replace_position_temp.size(); i++)
			{
				replace_position.push_back(replace_position_temp[i]);
			}
			return true;
		}
		else
			return false;
	}
	void Multi_Patch::draw_grey(string name, vector<vector<double>> sups, bool show_no_value)
	{
		if (sups.size() == 0)
			return;
		Mat show = Mat(5500, 5500, CV_8UC3, Scalar(255, 255, 255));
		Mat show1 = Mat(5500, 5500, CV_8UC3, Scalar(255, 255, 255));

		int _0x = 10, _0y = 10;
		int l = 100;
		int size = sqrt(sups[0].size());
		int each_row_num = 32 / size;
		cout << "draw_grey   size: " << size << "   each: " << each_row_num << endl;
		for (int i = 0; i < sups.size(); i++)
		{
			vector<double> sup = sups[i];
			int _0xx = i / each_row_num * ((l + 25)*size) + 10;
			int _0yy = i % each_row_num * ((l + 25)*size) + 10;
			for (int j = 0; j < sup.size(); j++)
			{
				rectangle(show, Point(_0yy + j%size*l, _0xx + j / size*l), Point(_0yy + j%size*l + l, _0xx + j / size*l + l), Scalar(255 * (1 - sup[j]), 255 * (1 - sup[j]), 255 * (1 - sup[j])), -1);
				putText(show, d2s_mant(sup[j],2), Point(_0yy + j%size*l + 10, _0xx + j / size*l + 25), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);
				//cout << sup[j] << " ";
				if (show_no_value)
					rectangle(show1, Point(_0yy + j%size*l, _0xx + j / size*l), Point(_0yy + j%size*l + l, _0xx + j / size*l + l), Scalar(255 * (1 - sup[j]), 255 * (1 - sup[j]), 255 * (1 - sup[j])), -1);
			}
			//cout << endl;
			/*double x, y, angle;
			cal_direction(sups[i], x, y, angle);
			putText(show, d2s_mant(x,2), Point(_0yy + 10, _0xx + l*size + 25), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);
			putText(show, d2s_mant(y,2), Point(_0yy + 110, _0xx + l*size + 25), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);
			putText(show, d2s_mant(angle,2), Point(_0yy + 210, _0xx + l*size + 25), FONT_HERSHEY_SIMPLEX, 0.45, Scalar(0, 0, 0), 1.8);*/
		}
		imwrite(name, show);
		string namel = name.substr(0, name.size() - 4);
		namel = namel+"_c.png";
		if (show_no_value)
			imwrite(namel, show1);
	}
	vector<vector<double> > Multi_Patch::acquire_density(vector<vector<double>> orinal, int num)
	{
		vector<vector<double> > ans;
		if (orinal.size() < num && orinal.size() > 0)
		{
			for (int i = 0; i < orinal.size(); i++)
				ans.push_back(orinal[i]);
			return ans;
		}
		else if (orinal.size() == 0)
		{
			return vector<vector<double> >();
		}
		else
		{
			int l = orinal.size() / num;
			for (int i = 0; i < num; i++)
			{
				ans.push_back(orinal[i*l]);
			}
			return ans;
		}		
	}
	void Multi_Patch::writePatch(string name)
	{
		/*
		save data
		patchgenerator
		size

		patch
		1.M N
		2.wg[][]
		3.int wn, sn, nn, en;//��¼������
		4.double density = -1;
		5.int class_id = -1;//�����ж�patch�Ƿ����ڿ���ת��ͬһ��
		6.int id;
		*/
		ofstream outfile(name);
		for (int i = 0; i < scale; i++)
		{
			outfile << "patch " << i << " " << patch_g[i].size << " "<<patch_g[i].total_classes_num << endl;
			set<int>judge_id;
			for (int j = 0; j < patch_g[i].patch.size(); j++)
			{
				//cout << "class_id_usedtimes: "<<patch_g[i].patch[j].class_id << "  " << patch_g[i].patch[j].used_time << endl;
				if (judge_id.count(patch_g[i].patch[j].class_id) != 0)
					continue;
				/*if (patch_g[i].patch[j].used_time <= 0)
					continue;*/
				judge_id.insert(patch_g[i].patch[j].class_id);

				outfile << "p " << patch_g[i].patch[j].id << " " << patch_g[i].patch[j].class_id << " " << patch_g[i].patch[j].M << " " << patch_g[i].patch[j].N << " " << patch_g[i].patch[j].wn << " " << patch_g[i].patch[j].sn << " " << patch_g[i].patch[j].nn << " " << patch_g[i].patch[j].en << " " << patch_g[i].patch[j].density << endl;
				outfile << "wg" << " ";
				for (int k1 = 0; k1 < patch_g[i].size; k1++)
				{
					for (int k2 = 0; k2 < patch_g[i].size; k2++)
					{
						if (k1 == patch_g[i].size - 1 && k2 == patch_g[i].size - 1)
							outfile << patch_g[i].patch[j].wg[k1][k2] << endl;
						else
							outfile << patch_g[i].patch[j].wg[k1][k2] << " ";
					}
				}
			}
		}
		outfile.close();
	}

	void Multi_Patch::readPatch(string name)
	{
		cout << endl << "-----------------------------------------" << endl
			<< "             Load Tms set!" << endl
			<< "-----------------------------------------" << endl;
		if (_access(name.c_str(), 0) != 0)
		{
			cout << "Warning: Cannot find Patch file!" << endl;
			return;
		}
		ifstream in(name);
		string line;
		vector<string> Line;
		int current_scale = -1;
		int Color_size = 3;
		int pos = 0;
		while (getline(in, line))
		{
			if (!line.empty())
			{
				Line.clear();
				getString(line, Line);

				if (Line[0] == "patch")
				{
					pos = 0;
					current_scale = atoi(Line[1].c_str());
					patch_g[current_scale].size = atoi(Line[2].c_str());
					patch_g[current_scale].total_classes_num = atoi(Line[3].c_str());
					patch_g[current_scale].x_num = patch_boundary_seqnum[current_scale];
					patch_g[current_scale].y_num = patch_boundary_seqnum[current_scale];
					patch_g[current_scale].set_sequence(Color_size);
					/*patch_g[current_scale].choose_sq.push_back(patch_g[current_scale].sq[0]);
					patch_g[current_scale].choose_sq.push_back(patch_g[current_scale].sq[patch_g[current_scale].sq.size() - 1]);
					int mid = 0;
					for (int tt = 0; tt < patch_g[current_scale].size; tt++)
					{
						mid += pow(Color_size, tt)*(Color_size / 2);
					}
					patch_g[current_scale].choose_sq.push_back(patch_g[current_scale].sq[mid]);*/
				}
				else if (Line[0] == "p")
				{
					//cout << current_scale << " " << pos << endl;
					patch_g[current_scale].patch.push_back(Patch());
					patch_g[current_scale].patch[pos].id= atoi(Line[1].c_str());
					patch_g[current_scale].patch[pos].class_id = atoi(Line[2].c_str());
					patch_g[current_scale].patch[pos].M = atoi(Line[3].c_str());
					patch_g[current_scale].patch[pos].N = atoi(Line[4].c_str());
					patch_g[current_scale].patch[pos].wn = atoi(Line[5].c_str());
					patch_g[current_scale].patch[pos].sn = atoi(Line[6].c_str());
					patch_g[current_scale].patch[pos].nn = atoi(Line[7].c_str());
					patch_g[current_scale].patch[pos].en = atoi(Line[8].c_str());
					patch_g[current_scale].patch[pos].density = atof(Line[9].c_str());
				}
				else if (Line[0] == "wg")
				{
					for (int i = 1; i < Line.size(); i++)
					{
						int k1 = (i - 1) / patch_g[current_scale].size;
						int k2 = (i - 1) % patch_g[current_scale].size;
						patch_g[current_scale].patch[pos].wg[k1][k2] = atoi(Line[i].c_str());
					}
					pos++;
				}
			}
		}

		for (int i = 0; i < scale; i++)
		{
			//add rotate patch
			int pos = patch_g[i].patch.size();
			//cout << pos << endl;
			for (int k = 0; k < pos; k++)
			{
				Patch ptt = patch_g[i].patch[k];
				for (int ii = 0; ii < 3; ii++)
				{
					ptt = patch_g[i].add_rotate_patch(ptt, 0);
					patch_g[i].patch.push_back(ptt);
				}
			}
			//cout << patch_g[i].patch.size() << endl;
			sort(patch_g[i].patch.begin(), patch_g[i].patch.end(), cmp_patch_rotate);
			sort(patch_g[i].patch.begin(), patch_g[i].patch.end(), cmp_patch);
			//give id
			for (int ii = 0; ii < patch_g[i].patch.size(); ii++)
			{
				patch_g[i].patch[ii].id = ii;
			}
		}

		for (int i = 1; i < scale; i++)  //add patch_bound, no scale 1
		{
			vector<Patch> patch1;
			for (int tt = 0; tt < patch_g[i].patch.size(); tt++)
			{
				int flag_ = 0;
				Patch pt = patch_g[i].patch[tt];
				for (int g = 0; g < patch1.size(); g++)
				{
					if (pt.wn == patch1[g].wn&&pt.sn == patch1[g].sn&&pt.nn == patch1[g].nn&&pt.en == patch1[g].en)
					{
						flag_ = 1;
						break;
					}
				}
				if (flag_ == 0)
				{
					patch1.push_back(Patch(pt.M, pt.N, pt.wn, pt.sn, pt.nn, pt.en));
				}
			}
			patch_g[i].patch_bound = patch1;
			cout << " patch_g[i].patch1: " << patch1.size() << endl;
		}
		
	}

	void Multi_Patch::judge_frequency(int scale)
	{
		vector<double> density_ma;
		for (int i = 0; i <= M - scale; i += scale)
		{
			for (int j = 0; j <= N - scale; j += scale)
			{
				density_ma.clear();
				for (int k1 = 0; k1 < scale; k1++)
				{
					for (int k2 = 0; k2 < scale; k2++)
					{
						density_ma.push_back(density_d[i + k1][j + k2]);
					}
				}
				_H_fre[i + scale - 1][j + scale - 1] = measure_high_frequency(density_ma);
				_H_fre[i][j] = measure_trend(density_ma);
				//cout << _H_fre[i][j] << " ";
			}
			//cout << endl;
		}
	}

	void Multi_Patch::Dithering(int x, int y, int size, double weight, double error)
	{
		if (x >= M || y >= N || x < 0 || y < 0)
			return;
		//cout << x << " " << y << endl;
		for (int k1 = 0; k1 <= size; k1++)
		{
			for (int k2 = 0; k2 <= size; k2++)
			{
				//cout << density_d[x - k1][y - k2] << " ";
				density_d[x - k1][y - k2] += error*weight;
				if (density_d[x - k1][y - k2] < 0)
					density_d[x - k1][y - k2] = 0;
				else if (density_d[x - k1][y - k2] > 0.99)
					density_d[x - k1][y - k2] = 0.99;
				//cout << density_d[x - k1][y - k2] << endl;
			}
		}
		return;
	}
	//--------------------------Multi_Patch------------------------------------------
}