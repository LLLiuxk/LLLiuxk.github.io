#define  _CRT_SECURE_NO_WARNINGS
#include "freeBoundary.h"

namespace FreeBound{

	bool cmp_error(pair<int, vector<double> > &x, pair<int, vector<double> > &y)
	{
		return abs(x.second[0] - x.second[1]) < abs(y.second[0] - y.second[1]);
	}

	bool cmp_patch_rotate(Patch &a, Patch &b)
	{
		return a.class_id < b.class_id;
	}

	bool cmp_pre_process(PAIR &a, PAIR &b)
	{
		return a.second > b.second;
	}

	bool cmp_patch(Patch &a, Patch &b)
	{
		return a.density < b.density;
	}

	bool cmp_patch_boundary(Patch &a, Patch &b)
	{
		//return (a.wn + a.nn + a.sn + a.en) < (b.wn + b.nn + b.sn + b.en);
		//return (a.wn*a.wn + a.nn*a.nn + a.sn*a.sn + a.en*a.en) < (b.wn*b.wn + b.nn*b.nn + b.sn*b.sn + b.en*b.en);
		return (pow(a.wn, 3) + pow(a.nn, 3) + pow(a.sn, 3) + pow(a.en, 3)) < (pow(b.wn, 3) + pow(b.nn, 3) + pow(b.sn, 3) + pow(b.en, 3));
	}

	bool cmp_pair(pair<double, int> a, pair<double, int> b)
	{
		if (a.first == b.first)
			return a.second < b.second;
		else
			return a.first < b.first;
	}

	bool cmp_pair_sec(pair<int, int> &x, pair<int, int> &y)
	{
		return x.second > y.second;
	}

	bool cmp_mismatch_b(pair<Point, int> a, pair<Point, int> b)
	{
		return a.second > b.second;
	}

	double cal_patch_error(vector<Tile> total_Tiles, Patch p1, Patch p2, int scale, double local, double global, double gradient)
	{
		vector<double> v1, v2;
		for (int i = 0; i < scale; i++)
		{
			for (int j = 0; j < scale; j++)
			{
				v1.push_back(total_Tiles[p1.wg[i][j]].black_pic*1.0 / pow(tile_edge_length, 2));
				v2.push_back(total_Tiles[p2.wg[i][j]].black_pic*1.0 / pow(tile_edge_length, 2));
			}
		}
		double error = match_error(v1, v2, local, global, gradient);
		return error;
	}

	double match_error(vector<double> image_density, vector<double> patch_density, double local, double global, double gradient)
	{
		double alpha = local, beta = global, gamma = gradient; //alpha: the max error of tile in patch, beta: the average error, gamma: gradient error

		int scale = sqrt(image_density.size());
		double error = 0;
		double max_tile_error = -1;
		double average_error = 0;
		double gradient_error = 0;
		vector<double> gradient_image, gradient_patch;

		for (int i = 0; i < image_density.size(); i++)  //�Ҽ���
		{
			max_tile_error = max(max_tile_error, abs(image_density[i] - patch_density[i]));
			average_error += abs(image_density[i] - patch_density[i]);
			//average_error += pow((image_density[i] - patch_density[i]), 2);
			if ((i + 1) % scale != 0 && i < scale*(scale - 1))
			{
				gradient_image.push_back(sqrt(pow(image_density[i + 1] - image_density[i], 2) + pow(image_density[i + scale] - image_density[i], 2)));
				gradient_patch.push_back(sqrt(pow(patch_density[i + 1] - patch_density[i], 2) + pow(patch_density[i + scale] - patch_density[i], 2)));
			}
		}
		//cout << "ave: " << average_error << "  max: " << max_tile_error;
		average_error = average_error / (scale*scale);//0-1
		int gradient_size = gradient_image.size();
		//cout << "gradient_size: " << gradient_size << endl;
		for (int i = 0; i < gradient_size; i++)
		{
			gradient_error += abs(gradient_image[i] - gradient_patch[i]);
		}
		//cout << "  gradi: " << gradient_error<<endl;
		gradient_error = gradient_error / gradient_size;
		error = alpha*max_tile_error + beta*average_error + gamma*gradient_error;
		//cout << "ave: " << average_error << "  max: " << max_tile_error<<"  gradi: " << gradient_error << "  error: " << error << endl;
		return error;
		//double alpha = local_coef, beta = average_coef, gamma = gradient_coef; //alpha: the max error of tile in patch, beta: the average error, gamma: gradient error

		//int scale = sqrt(image_density.size());
		//double error = 0, local_error = 0, global_error = 0, gradient_error = 0;
		//vector<double> heng_gradient_dis, heng_gradient_img, zong_gradient_dis, zong_gradient_img;
		//double max_tile_error = -1, average_error = 0, a_e_h = 0, a_e_z = 0;
		//for (int i = 0; i < image_density.size(); i++)  //�Ҽ���
		//{
		//	max_tile_error = max(max_tile_error, abs(image_density[i] - patch_density[i]));
		//	average_error += abs(image_density[i] - patch_density[i]);
		//	if (!(i == 0 || i%scale == 0))
		//	{
		//		heng_gradient_dis.push_back(image_density[i] - image_density[i - 1]);
		//		heng_gradient_img.push_back(patch_density[i] - patch_density[i - 1]);
		//	}
		//	if (!(i >= 0 && i < scale))
		//	{
		//		zong_gradient_dis.push_back(image_density[i] - image_density[i - scale]);
		//		zong_gradient_img.push_back(patch_density[i] - patch_density[i - scale]);
		//	}
		//}
		//local_error = max_tile_error;//0-1
		//global_error = average_error / (scale*scale);//0-1
		//for (int i = 0; i < heng_gradient_dis.size(); i++)
		//{
		//	a_e_h += abs(heng_gradient_dis[i] - heng_gradient_img[i]);
		//	a_e_z += abs(zong_gradient_dis[i] - zong_gradient_img[i]);
		//}
		//gradient_error = 0.5*a_e_h / heng_gradient_dis.size() + 0.5*a_e_z / zong_gradient_dis.size();
		//error = alpha*local_error + beta*global_error + gamma*gradient_error;
		//return error;
	}


	int match_tile_bound_constrain(vector<Tile>& allTiles, int & index, int ww, int ee, int nn, int ss, double density) //--lxk,ֻ������߽�Լ��
	{

		vector<pair<int, vector<double> > > chosen;
		double min_error = 100000;
		//int min_index = -1;
		int sizeall = allTiles.size();
		//cout << "all_Tile:" << allTiles.size() << endl;
		for (int i = 0; i < sizeall; i++)
		{
			if (ww != -1)
			{
				if (allTiles[i].Left.edge_colorScheme.id != ww)
					continue;
			}
			if (ee != -1)
			{
				if (allTiles[i].Right.edge_colorScheme.id != ee)
					continue;
			}
			if (ss != -1)
			{
				if (allTiles[i].Top.edge_colorScheme.id != ss)
					continue;
			}
			if (nn != -1)
			{
				if (allTiles[i].Bottom.edge_colorScheme.id != nn)
					continue;
			}

			vector<double>tt;
			tt.push_back(allTiles[i].black_pic / pow(tile_edge_length, 2));
			tt.push_back(density);
			chosen.push_back(make_pair(i, tt));
		}
		//srand((unsigned)time(NULL)+rand());
		sort(chosen.begin(), chosen.end(), cmp_error);
		//int itt = rand() % chosen.size();
		index = chosen[0].first; //ѡ�������С��һ��tile���patch
		if (abs(chosen[0].second[0] - chosen[0].second[1]) > inter_error_threshold) big_error++;
		/*cout << "-----------------------------------------------------------------" << endl << endl;
		cout << "min_error:" << min_error << "   chosen:" << chosen.size() << "   random:" << itt << "   index:" << index << endl << endl;
		cout << "-----------------------------------------------------------------" << endl << endl;*/

		return index;
	}

	void load_para(std::string filename)
	{
		ifstream fin(filename);
		if (fin.fail() == true)
		{
			cout << "Cannot open load_pare file." << endl;
		}
		string param;		
		while (fin >> param)
		{
			if (param == "data_path")
				fin >> data_path;
			else if (param == "Image_name")
				fin >> Image_name;
			else if (param == "dynamic_mt")
				fin >> dynamic_mt;
			else if (param == "scale_nums")
				fin >> scale_nums; 
			else if (param == "iter_num")
				fin >> iter_num;
			else if (param == "Target_max")
				fin >> Target_max;
			else if (param == "Target_min")
				fin >> Target_min;
			else if (param == "local_coef")
				fin >> local_coef;
			else if (param == "average_coef")
				fin >> average_coef;
			else if (param == "gradient_coef")
				fin >> gradient_coef;
			else if (param == "error_diffusion")
			{
				string error_d;
				fin >> error_d;
				if (error_d == "true") error_diffusion = true;
				else error_diffusion = false;
			}
			else if (param == "error_diffusion_11")
			{
				string error_d11;
				fin >> error_d11;
				if (error_d11 == "true") error_diffusion_11 = true;
				else error_diffusion_11 = false;
			}
			else if (param == "box_flags")
			{
				string box_f;
				fin >> box_f;
				if (box_f == "true") box_flags = true;
				else box_flags = false;
			}
		}
		Input_Path = data_path + Image_name;
		cout << "Paramaters Loaded Successfully." << endl<<endl;
	}


}