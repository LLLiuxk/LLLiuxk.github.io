#ifndef TOOL_H
#define TOOL_H

#include <highgui/highgui.hpp>
#include <imgproc/imgproc.hpp>
#include <opencv2/legacy/legacy.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <stack>
#include <ctime>
#include <io.h>
//#include <list>
#include <direct.h>
#include <math.h>
#include<set>
#include <iomanip>

using namespace cv;
using namespace std;

extern int all_num;
extern double max_curvature;
//namespace Tiling_tiles{

#ifndef PI  
#define PI 3.1415926535
#endif
  
#define Array_num 10
#define arc_point_num 40

	//extern vec tor<pair<string, Scalar>> colorbar;

	class Line_Seg{
	public:
		Line_Seg();
		Line_Seg(Point2f a, Point2f b)
		{
			start = a;
			end = b;
		}
		Point2f start;
		Point2f end;
	};


	class color_bar
	{
	public:
		color_bar(){};
		vector<Scalar> color_bar::setColorMode(int type, int num_gradient);
		void DrawColorBar(Mat& image, Point leftTop, Point rightBottom, double v_min, double v_max, int num);

		vector<Scalar> colorbar;

	};

	typedef class Kuhn_Munkres
	{
	public:
		int const MAX = 1000;
		int const inf = 0x3fffffff;
		double w[100][100];
		int link[100];//������ǰ��Y��������Ե�X�����еĵ�
		int visx[100], visy[100];
		double lx[100], ly[100];
		int n, m;//����X��Y��Ԫ�صĸ���

		Kuhn_Munkres(){};
		Kuhn_Munkres(vector<vector<double>> error_map, bool max_sum=true);
		int can(int t);
		double km();

	}KM;

	//all kinds tools
	//draw tool
	//void MyLine(Mat img, Point2f start, Point2f end, string color1);
	//Mat draw_polygen(string win_name, vector<Point2f> contour_s);
	void draw_poly(Mat &drawing_, vector<Point2f> contour_s, Point2f shift = Point2f(0, 0), Scalar color = Scalar(0, 0, 0), double zoom_scale = 1.0); 
	void draw_poly_contour(Mat &drawing_, vector<Point2f> contour_s, Point2f shift = Point2f(0, 0), Scalar color = Scalar(0, 0, 0)); 
	//void draw_allplane(Mat &drawing_, vector<Point2f> contour_, vector<int> vec_, double scale = 1, int type = 0);
	//void draw_result(Mat &drawing_, vector<Point2f> contour_, vector<int> vec_, double scale = 1, int type = 0, Point2f shift = Point2f(0, 0));

	//void draw_two(Mat &drawing_, vector<Point2f> &contour_1, vector<int> vec_1, vector<Point2f> &contour_2, vector<int> vec_2, double scale = 1, int type = 0);//draw connection area


	//math tool
	double length_two_point2f(Point2f &u, Point2f &v);
	double length_v(Point2f &u);
	//�����º����У���10000��������
	double com_derivative(Point2f prev, Point2f back);
	double com_Sec_derivative(Point2f prev, Point2f one, Point2f back);
	double com_curvature(Point2f prev, Point2f one, Point2f back);
	/*
	Point2f center_p(vector<Point2f> contour_);
	double contour_length(vector<Point2f> contour);
	
	double length_two_point_tar(vector<double> &p1, vector<double> &p2);
	void move_con(vector<Point2f> &con, Point2f sh);
	int locate_p(Point2f input, vector<Point2f> contour);

	vector<int> feature_points(vector<Point2f> contour_, double dmin, double dmax, double angle_cos);
*/
	double diff_color(Scalar color1, Scalar color2);
	double diff_deriv_curva(vector<double> one_deriv_curva, vector<double> sec_deriv_curva);
	
	//bounding box
	vector<Point2f> b_box(vector<Point2f> contour);

	//vector<Point2f> sampling(vector<Point2f> &contour_, int points_num);


	
	//point on line or in polygon
	bool point_on_line(Point2f onep, Line_Seg line);
	bool point_in_polygon(Point2f onep, vector<Point2f> &poly);

	//cross points of line and polygon
	int line_intersection(Line_Seg line1, Line_Seg line2, Point2f &cross_p);
	bool line_polygon(Line_Seg line1, vector<Point2f> contour, vector<Point2f>& in_sec); //true=�н���
	bool poly_poly(vector<Point2f> contour, vector<Point2f> contour_, vector<Point2f>& all_in_sec);
	bool poly_group(vector<vector<Point2f>> Contours);
	bool self_intersect(vector<Point2f> &contour_, int &first, int &second);

	//Delaunay triangulation
	bool isGoodTri(Vec3i &v, vector<Vec3i> & tri);
	void TriSubDiv(vector<Point2f> &pts, Rect rc, vector<Vec3i> &tri);

	//vector and cosin/ sin
	Point2f unit_vec(Point2f vec);
	Point2f vertical_vec(Point2f vec);
	//double cos_3edges(double l1, double l2, double l3);
	double cos_two_vector(Point2f &v0, Point2f &v1);
	double sin_two_vector(Point2f &v0, Point2f &v1);
	//double tar_2vector(Point2f &v0, Point2f &v1);
	//vector<double> curvature_com(const vector<Point2f> &contour_sam); //��¼cosֵ
	//vector<double> recover_consin(const vector<double> &former);
	//vector<int> most_convex_p(vector<Point2f> contour_, vector<double> cont_c, int max_cur_num);

	//sort
	template<typename T>
	void sort_bub(vector<T> &target)  //��С����
	{
		int i, j;
		T temp;
		for (i = 0; i < target.size() - 1; i++)
			for (j = 0; j < target.size() - 1 - i; j++)
				if (target[j] > target[j + 1])
				{
					temp = target[j];
					target[j] = target[j + 1];
					target[j + 1] = temp;

				}
	}

	//vector operation
	bool equal_vec(vector<double> vec1, vector<double> vec2);
	//intersect
	template<typename T>
	vector<T> intersect(vector<T> &target1, vector<T> &target2)  //��С�������к�
	{
		vector<T> final_;
		for (int i = 0; i < target1.size(); i++)
		{
			for (int j = 0; j < target2.size(); j++)
			{
				if (target1[i] == target2[j])
				{
					final_.push_back(target1[i]);
					break;
				}
			}
		}
		return final_;
	}

	void append(vector<Point2f>& v1, vector<Point2f>& v2);

	//����һ�����������˵�����
	vector<Point2f> arc_gen(Point2f start, Point2f end, Point2f cent, Point2f tile_c);//Ŀǰ���ǻ�Բ, start, end ����������ʼ�㣬centԲ�ģ��������κ�λ�ã�tileΪ���ĵ�����ȷ��������
	vector<Point2f> arc_gen(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures);//�����������
	vector<Point2f> arc_gen_b(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures);//�����������
	vector<Point2f> arc_gen_h(Point2f start, Point2f end, Point2f cent, Point2f tile_c, vector<double>& curvatures);//�����������
	vector<Point2f> semicir_gen(Point2f start, Point2f end, Point2f cent);

	//b-spline and hermite curves
	double N3(int i, double u);
	vector<Point2f> generate_b_spline(vector<Point2f> ctrlPoints);
	vector<Point2f> generate_hermite(vector<Point2f> ctrlPoints, vector<Point2f>& HermP);
	vector<Point2f> HermiteP(vector<Point2f> ctrlPoints); //���������˵㼰����ȷ��hermite����ϵ��a,b,c,d

	//file cout
	void fileout(string filepath, vector<Point> contour_);
	void fileout_array(string filepath, int contour_[10][10], int row, int col);
	vector<vector<int>> filein_array(string filepath, int col);
	vector<Point2f> readTxt(string filepath);
	void getString(string line, vector<string> &Line);

	void write_text(string name, int scale, vector<pair<double, int> >txt);  //--cr
	void write_obj(string filepath, vector<Point2f> contour, Point2f shift, double height);
	
	void create_svg(string svg_path);
	void save_tile_svg(string svg_path, vector<Point2f> contour, Scalar color, Point2f shift = Point2f(0, 0), double zoom_scale = 1.0);
	void add_word_svg(string svg_path, string word, Scalar color, Point2f shift = Point2f(0, 0));
	void end_svg(string &svg_path);


	//transform
	string d2s_mant(double number, int mantissa = 4);

	vector<Point2f> polyline_gen(Point2f start, Point2f end, Point2f cent, vector<double>& curvatures);
	vector<Point2f> mix_contour(vector<vector<Point2f>> contours);


	double normalize(double x, double y);  //--cr

	//image analyse
	void image_histogram(string image_path, int unit_size, int patch_size);
	Mat draw_histogram(vector<int> data, vector<double> range, string his_name = "histogram", Scalar color = Scalar(0, 0, 0));
	double measure_high_frequency(vector<double> density_ima);
	double measure_high_frequency_sober(vector<double> density_ima);
	int measure_trend(vector<double> ima);

	void txt_histogram(string filepath);

	vector<vector<double>> readError(string txtpath, int col, double &min, double &max);
	void draw_error_map(Mat& source, vector<Scalar> colorbar, Point leftTop, int error_level, int unit_pixels, int num = 1);

	void merge_two_maps(string image1, string error_map, string outpath, int offset=0);
	
	vector<double> rotate(vector<double> A, int c);

	void cal_direction(vector<double> vec, double &x, double &y, double &angle);
	bool is_monotonic(vector<double> vec, int type/*1:hor 2:dia*/);
	bool is_equal_vector(vector<double> a, vector<double> b);


	vector<int> stable_matching(vector<vector<double>> error_map);
	bool cmp_pair(pair<double, int> a, pair<double, int> b);
	vector<int> assign_order(vector<pair<double, int>> order_);
	int locate_in_order(vector<int> order_, int num);
//}

#endif