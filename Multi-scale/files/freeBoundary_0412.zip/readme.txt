para.txt                       controls the input parameters although they are preset initially in the main.cpp
chooseTileSize.exe             controls to set the area to be tiled only using elementary tiles.
3_scale_patch_data_xxx.txt     records the predefined multi-scale tiles which can be regenerated.