#ifndef FREEBOUNDARY_H
#define FREEBOUNDARY_H

#include <highgui/highgui.hpp>
#include <imgproc/imgproc.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <stack>
#include <ctime>
#include <io.h>
#include <list>
#include <direct.h>
#include <math.h>
#include <map>
#include "Tool.h"

#define Edge_pn 100
#define tile_edge_length 75
#define e 2.71828
#define MAXN 10
#define Input_pixel_num 100
//#define data_path "C:/Users/liuxk/OneDrive/Recent/wang tile ppt/data/chosen/"
#define drawp_num_eachRow 20 //num of each row when draw picture 
#define threshold_rotate 0.2//��ת������ֵ  
#define density_gradient 0.05  //analyze density distribution, can be replaced by sparse sample
#define inter_error_threshold 0.1 //error threshold in generating interior tiles of patch
//lena 0.05
#define replace_num_threshold 500
#define density_margin 0.16 //lower than the value will not be tiled 
#define ImageSize 500 //default image size, should be enlarge if image large than 250

#define dynamic_mt_low 0.04
#define range_mapping true
#define sparse_sampling false
#define sample_grad 0.1
#define cluster_steps true
#define tiling_steps true
#define PatchNum 81 
#define SupPatchNum 81
#define patch_gen_type 3 //0: 1 v random 1  1: 1 v all  2:lcr--density first  3: stable matching+ combined optimization
#define new_patch_gen_type 2 //0: ���1��1���, 1: 1��all  2: 18 types 1 vs all
#define discard_nonadjacent false   //true: rest 31  false: total 81
#define discard_rotation true   //true: rest 31  false: total 81
#define replace false 
//#define error_diffusion true
//measure error


//#define Image_Width 100
//#define Image_Height 100
//#define image_pixel_w (Image_Width+10)*tile_edge_length
//#define image_pixel_h (Image_Height+10)*tile_edge_length

//#define density_k 0.6
//#define density_b 0.2

//density = density*k+b;
//����, ������main.cpp
extern double match_threshold;
extern double dynamic_mt;
extern double re_dynamic_mt;
extern int iter_num;
extern int scale_nums;
extern int topNum_clus;
extern double Target_max;
extern double Target_min;
extern double local_coef;
extern double average_coef;
extern double gradient_coef;
extern bool error_diffusion;
extern bool error_diffusion_11;
extern bool box_flags;

extern string Input_Path;
extern string Image_name;
extern string data_path;
extern string result_path;
extern string result_num;
extern vector<int> patch_size;
extern vector<int> patch_boundary_seqnum;
extern vector<int> each_row_num;
extern vector<int> size2scale;
extern map<int, int>rotate_link;
extern map<int, int>rotate_pattern_link;
extern int Image_Width; 
extern int Image_Height; 
extern int image_pixel_w;
extern int image_pixel_h;
extern int big_error;
extern string patch_svg_name;
extern string obj_path;
extern vector<vector<double>> para_group;

extern int thres_over[5];

using namespace cv;
using namespace std;

namespace FreeBound{

	enum tilingType{ RightLeft, BottomTop };
	enum edgeName{ LeftE, BottomE, RightE, TopE, AllE };
	enum Connect_rules{
		sequenceConnect, ltrbConnect,
		tlrbMidS, trlbMidS, //MidS = mid is straight line
		rbltConnect, trblConnect,
		bltrConnect, ltbrMidS,
		lbtrMidS, allSelf, 
		lefttopSelf, leftbottomSelf, 
		righttopSelf, rightbottomSelf, 
		lefttopConnect,	leftbottomConnect,

		//new added straight lines
		sequenceConnect_v,
		ltrbConnect_v, rbltConnect_v,
		trblConnect_v, bltrConnect_v,
		tlrbMidS_v, ltbrMidS_v,
		trlbMidS_v, lbtrMidS_v,
		//quit
		ltArbP, trAblP, blAtrP, rbAltP,
		topVacancy, rightVacancy,
		leftVacancy, bottomVacancy
	}; //ȥ��ֱ����������ʣ��8�����ӷ�ʽ
	extern string Connect_rules_string[];
	typedef pair<vector<double>, int> PAIR;

	typedef class colourScheme
	{
	public:
		double Mu; //the center of G-function
		double Sigma; //the width of G-function
		double truncation; //truncation
		double k_max; //the max value of G-function
		int gary_scale; //constrain the highest value of RGB :[gary_scale,max_s]
		int interval_num;
		int id;//-----cr
		Scalar color;

		vector<double> Points;//x
		vector<double> Values;//y
		vector<Scalar> Colors;
		vector<double> endPoints;//bianjie
		//f(x)=ae^(-(x-b)^2/2c^2)= k_max*e^(-(x-Mu)^2/2*Sigma^2)

		//-------�����-------
		int point_number = 10;//����
		double pro_value[100];//ÿһ�θ���ֵ
		double threshold = 0.3;
		int bd1; //���ϵ������˵�
		int bd2;
		int edge_length;
		//-------------------
	public:

		/*void changeMu(double mu);
		void changeSigma(double si);
		void setColor(Scalar color_);*/

		colourScheme();
		colourScheme(int length);
		colourScheme(double center, double sigma, int gary, Scalar color_ = Scalar(255, 255, 255), double trunc = 0.2, double km = 1.0);
		colourScheme(double center, double sigma, Scalar color_);
		~colourScheme();

		void com_fun();
		void com_fun_mul();
		vector<Scalar> com_fun(double interval); //--cr
		void show_fun(); //�����һ��ɫ�ĺ���
		void show_fun(Mat& pic, int it_num); //�������һ��ɫϵ
		void show_fun(Mat pic, int it_num, vector<double>values); //--cr
		//-------------multi-pro--------------
		double f(double x);//��ʾÿһ�θ��ʵĺ���
		void set_P();
		void set_P(vector<double> data);
		//ȷ��ÿһ�εĸ���ֵ
		bool not_single_Peak();
		void draw_edge(Mat &pic, Point2f shift, int flag);
		//void set_bdPoint(int flag);//ȷ���˵�����
		//double com_error(CS t);
		//-----------multi-pro--------------
	}CS;

	//���ϱ������Ϣ�У��ߵ������˵����꣬����ͼ���������˵㼰�˵㴦������
	class R_Edge
	{
	public:
		Point2f start;
		Point2f end;
		Point2f boundp1; //���ϵ������˵�
		Point2f boundp2;
		vector<double> deriv_curva1; //�洢˳��:����,����
		vector<double> deriv_curva2;
		int interval_num;
		CS edge_colorScheme;
		int id;//-----cr ��¼��ɫ����

		vector<Point2f> edge_points;
		//vector<int> edge_grays;

	public:
		R_Edge();
		R_Edge(Point2f start_, Point2f end_);
		R_Edge(Point2f start_, Point2f end_, CS colorScheme);
		~R_Edge();

		void set_endpoints(Point2f start_, Point2f end_);
		void set_colorScheme(CS colorScheme);
		void set_parameters(Point2f start_, Point2f end_, CS colorScheme);
		void change_endpoints(Point2f start_, Point2f end_);

		void draw_edge(Mat& pic, Point2f shift = Point2f(0, 0));
		void draw_edge(Mat pic, int flag, int d, double ss, double ee); //--cr

		double compare_edge(R_Edge opposite);
		double compare_edge_with(R_Edge opposite);
		double compare_edge_scale(R_Edge opposite, int flag, int edge); //--cr

		void input_curva(Point2f boundp, vector<double> deriv_curvas, bool isFirst); //�ѵ��������ʵ�����������û�е�����Ҫ�ں�������

	};
	struct bou_descriptor
	{
		vector<vector<Point2f> >C;//���������һ���
	};

	class Tile
	{
	public:
		Point2f topLeft;
		Point2f bottomRight;
		Point2f center;
		double width;
		double height;
		R_Edge Left;  //from topLeft counterclockwisely(Contrary to what opencv showing)
		R_Edge Bottom;
		R_Edge Right;
		R_Edge Top;
		vector<vector<Point2f>> content_patterns;
		int content_type;
		vector<bou_descriptor> all_C;//--cr   0zuo1you2shang3xia ������Tileͼ��ʱ�Ͷ�����
		int black_pic = -1;//��¼�ܶ�

	public:
		Tile();
		Tile(Point2f topLeft_, Point2f bottomRight_);
		Tile(Point2f topLeft_, double width_, double height_);
		~Tile();

		//void operator= (Tile& tile);

		void set_edges();
		void set_colors(CS l, CS b, CS r, CS t);
		void change_position(Point2f new_topLeft);
		void draw_tileEdges(Mat& pic, Point2f shift = Point2f(0, 0)); //ֻ����,shift����ͼ������ʱ��ƫ����
		void draw_tileEdges(Mat pic, int flag);//--cr

		void draw_tileConts(Mat& pic, Point2f shift = Point2f(0, 0), double zoom_scale = 1.0); //ֻ������
		void draw_tileConts(Mat& pic, Point2f shift, int color_cho, double zoom_scale);
		void Tile::draw_slot(Mat& pic, Point2f shift, string edge_type, double zoom_scale, int length_scale, int types);
		void draw_Tile(Mat& pic, Point2f shift = Point2f(0, 0)); //�����Լ�����

		void show_Edge_curva();

		vector<Tile> match_tile(vector<Tile>& allTiles, int flag = RightLeft); //��Ϊ��һ��tile��������һ��Ҫƴ�ӵ�tile������ Tile��
		vector<int> match_tile(vector<Tile>& allTiles, double threshold, int flag = RightLeft); //���� Tile���ڼ����е�����
		Tile match_tile(vector<Tile>& allTiles, int & index, int flag = RightLeft);  //���ص��� Tile��index���ظ�tile�ڼ����е�λ��
		Tile match_tile_with_constrain(vector<Tile>& allTiles, int & index, int flag = RightLeft);
		vector<int> match_tile_with_constrain(vector<Tile>& allTiles, double threshold, int flag = RightLeft);
		vector<int> match_tile_with_constrain_vector(vector<Tile>& allTiles, int & index, int flag, int ww, int ee, int nn, int ss, double sig1, double sig2);//--cr
		int match_tile_with_constrain(vector<Tile>& allTiles, int & index, int flag, int ww, int ee, int nn, int ss, double sig1, double sig2, double density);//--cr ����߽�Լ����ѡ��tile	

		//multi scale match
		vector<int> match_tile(vector<Tile>& allTiles, double threshold, int d, int flag, int edge, map<int, int> &m); // --cr

		bool equal_tile(Tile &sec, int type = 0); //�Ƚ�����tile�ı߽��Ƿ�һ��, type�����Ƚ���һ��,0,1,2,3�ֱ�Ϊ�������ң�4Ϊȫ��

		//void matching_rules();
		void content_gen_rules(int flag = allSelf); //������Ҫ��������Ҳ��Ҫ���������ʣ���arc_gen�����м��������˵�����

	};


	class TilingScheme
	{
	public:
		vector<Tile> all_Tile; //���в�ͬ�߽��tile
		vector<vector<Tile>> total_Tiles; //���а������ݵ�tile���߽�����*��������
		double max_curvature;
		double total_error; //��¼���е����

	public:
		TilingScheme();
		TilingScheme(double length_edge);
		~TilingScheme();

		//ֻ�������˱߽�
		vector<Tile> com_all_tiles(vector<double> sigma, vector<double> mu, vector<Scalar> color_rgb);
		vector<Tile> com_all_tiles(vector<CS> Color_); //�������п��ܵ���ɫCS���������еĿ������

		//ֱ�Ӽ�����ڲ�����ͼ����ȫ��tiles
		vector<Tile> com_total_tiles(vector<CS> Color_);

		double tile_edge_l;
	};

	struct Patch//---------cr
	{
		/*const int M = 2;
		const int N = 2;*/
		int M, N;
		int wg[10][10];//��¼tile���
		int wn, sn, nn, en;//��¼��������sq������
		double density = -1;
		int used_time = 0;//��¼��ƽ��ʱ�õ��Ĵ���
		vector<bou_descriptor> all_C;//0zuo1you2shang3xia 
		Patch()
		{

		}
		Patch(int m, int n)
		{
			M = m;
			N = n;
		}
		Patch(int m, int n, int wn, int sn, int nn, int en)
		{
			M = m;
			N = n;
			this->nn = nn;
			this->wn = wn;
			this->sn = sn;
			this->en = en;
		}
		int class_id = -1;//�����ж�patch�Ƿ����ڿ���ת��ͬһ��
		int id;
	};


	class PatchGenerator//--------cr
	{
	public:
		int x_num;//����������
		int y_num;//����������
		int size;//patch���
		vector<vector<int> > sq;//����
		map<vector<int>, int> sq_number;//���ж�Ӧ�����
		vector<Patch> patch;//patch set
		vector<Patch> patch_bound;//patch copy for iteration
		vector<pair<int, double>> patch_error;//patch set error ----lxk
		int tiling_n[20][20];
		vector <vector<int> > choose_sq;//ѡ�е�����
		int used_number = 0;//�õ��Ŀ���
		int total_classes_num;
		set<int> class_id_set;//��¼����ת����
		map<int, int> class_id_time;//��¼ÿ������ת����ֶ��ٴ�
		map<int, int>id_classID;//ID��class ID��ӳ���ϵ

	public:
		PatchGenerator();
		PatchGenerator(int x, int y, int z);
		void set_sequence(int number);//��������
		void add_seq(int scale, vector<int>& a, int number);
		void set_boundary(vector<int> A, vector<CS> Color_, vector<Tile> total_Tiles);
		void set_patch(vector<Tile> total_Tiles, vector<CS> Color_);//����patch
		void set_patch(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density);
		void set_patch_spec_11(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density);
		void find_sameBoun_tile(Patch pt, vector<int>& difpattern, vector<Tile> total_Tiles);
		vector<int> define_tilePattern(vector<int> difpattern, vector<PAIR> sort_density, vector<Tile> total_Tiles);
		void set_patch_spec(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, vector<PAIR> sort_density);//-----lxk
		//void set_unused_patch(vector<Tile> total_Tiles, vector<CS> Color_, vector<PAIR> sort_density);
		vector<pair<Patch, int>> set_unused_patch(vector<Tile> total_Tiles, vector<CS> Color_, vector<PAIR> sort_density);
		//������ѡ����˳���Ժ�����set_Patch()
		void set_patch_density(vector<Tile> total_Tiles, vector<CS> Color_, vector<int> A, int scale);
		int internal_tiling(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<PAIR> sort_density);
		int internal_tiling(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<PAIR> sort_density, vector<int>& used_density); //-----lxk
		int internal_with_density(vector<Patch> & patch_tem, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in); //-----lxk
		int internal_with_density(vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, vector<int>& used_patch, vector<CS> Color_);
		int internal_with_density(vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, vector<int>& used_patch);
		int internal_bound_density(vector<Tile> total_Tiles, vector<double> density_in, Patch pt_in);     //--lxk: fixed bound 
		bool is_redundant(Patch pt, vector<int> used_patch, vector<Tile> total_Tiles);//�жϵ�ǰpatch�Ƿ����Ѵ��ڵ�patch�߽���ͬ�ܶ�����
		//-----lxk
		int matched_degree_p_d(Patch &pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e); //-----lxk
		int matched_degree_p_d(Patch &pt_in, vector<Tile> total_Tiles, vector<double> density_in, double & patch_e, Point2f start = Point2f(0, 0)); //-----lxk

		int match_iter_random(Patch & pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e, vector<CS> Color_, vector<double>& image_density = vector<double>());

		int matched_degree_density_first(Patch & pt_in, vector<Tile> total_Tiles, double sig1, double sig2, vector<double> density_in, double & patch_e, vector<CS> Color_, vector<double>& image_density = vector<double>());

		int defaultNum(Tile tile, int posx, int posy, vector<vector<int>> color_id);
		bool all_edge_match(vector<vector<int> > tile_edge_id, Patch pt, vector<vector<int> > color_id); //--lcr
		bool all_edge_match(vector<Tile> total_Tiles, Patch pt, vector<vector<int>> color_id, vector<pair<Point, int>>& num_mismatch); //--lxk

		void internal_tiling_class(int C, vector<Patch>& all_patch, Patch& pt, vector<Tile> total_Tiles, double sig1, double sig2);
		//patch�ڲ����
		void draw_patch(vector<CS> Color_, vector<Tile> total_Tiles);
		int draw_patch(int choice, int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show, vector<pair<double, int> >&txt);//��߶�patch���ú���
		void show_patch(vector<Patch> patch_show, vector<double> patch_e, vector<CS> Color_, vector<Tile> total_Tiles, string name);
		void show_patch(vector<Patch> patch_show, vector<CS> Color_, vector<Tile> total_Tiles);//����չʾ���������patch
		void draw_patch_initial(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show, Mat &show1, vector<pair<double, int> >&txt);//��߶�patch���ú���
		int draw_patch_order(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show);//��ʹ�ô�������patch set���
		
		void draw_result(vector<CS> Color_, vector<Tile> total_Tiles, int M, int N);
		void cal_descriptor(vector<bou_descriptor> &tile1, vector<bou_descriptor> tile2, int x, int y);//���±߽������ӣ�tile1Ϊ����ƽ��ģ�tile2Ϊtile��
		bool is_insect(vector<Point2f>P1, vector<Point2f>P2, vector<Point2f>&tp, int flag);
		bool Single_connnect(Patch pt1, vector<Tile> total_Tiles);
		int Single_connnect_num(Patch pt1, vector<Tile> total_Tiles);
		void draw_single_patch(Mat &show, Point2f shift, int c, vector<Tile> total_Tiles, vector<CS> Color_);//����û���ڱ߽��patch

		void set_A(int A[], vector<CS> Color_);
		void find_A(vector<int>& A);

		Patch add_rotate_patch(Patch pt1, int c);//add rotate patch
		Patch rotate_patch_boundary(Patch pt1, int degree);//rotate patch boundary
		bool is_adjacent(Patch pt, map<int, int>sq_to_pos);
		void draw_patch_Edge(int x, int y, vector<CS> Color_, vector<Tile> total_Tiles, Mat &show1, vector<Patch>patch_temp); //initial:����+����;

		int find_Patch(int id);//return position from patch id 
		int find_patch_edge(Patch pt);//return position from patch edge
	};

	class Multi_Patch
	{
	public:
		//PatchGenerator patch_g[3];//������ε�patch
		vector<PatchGenerator> patch_g;
		PatchGenerator box_patch;
		int scale = 0;//����
		int M = Image_Height;
		int N = Image_Width;
		double total_error = 0;
		int total_type_num = 0;
		int total_type_times = 0;

		vector<vector<double>> density_d;
		vector<vector<double>> density_d2;
		vector<vector<double>> freq_priority; //---lxk, ��������ͼ��õ���Ƶ�ʸߵ�˳�����Ա��ں���������ƴ��Ƶ����
		//ֻ��4*4, ��������ż���Ӧ�����
		vector<int> four_tiling_index;
		vector<double> four_tiling_error;
		vector<vector<double>> density_situ;
		vector<int> all_distru_index;
		//double density_d[100][100];

		int last_vis[ImageSize][ImageSize];//������ʱɾ��֮ǰ��ƽ�̽��
		int vis[ImageSize][ImageSize];
		int _H[ImageSize][ImageSize];
		int _H_temp[ImageSize][ImageSize];
		int _H_p[ImageSize][ImageSize];
		int _H_class[ImageSize][ImageSize];
		double _H_fre[ImageSize][ImageSize];
		int onetile[ImageSize][ImageSize];
		map<vector<double>, int> pre_density;
		vector<PAIR> sort_density;

	public:
		Multi_Patch();
		Multi_Patch(int scale);
		Multi_Patch(int c, int x, int y, int z);
		Multi_Patch(int scale, int color_num);

		void set_density(string imagepath);  //----lxk
		void set_density_txt(string txtpath);  //----lxk
		void set_Tms(vector<Tile> total_Tiles, vector<CS> Color_);//���ɶ�߶�patch�����ͳһΪͬһ��С
		void set_Tms_scale(int scale_, vector<Tile> total_Tiles, vector<CS> Color_);
		void set_Tms_11(int choice_num, vector<Tile> total_Tiles, vector<CS> Color_);
		void set_Tms_22(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_);
		void set_Tms_33(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_);
		void set_Tms_44(int choice_num, int scale, vector<Tile> total_Tiles, vector<CS> Color_);
		void draw_all_Patch(int choice, vector<Tile> total_Tiles, vector<CS> Color_, string name);
		void draw_used_Patch(int time, int p_scale, vector<Tile> total_Tiles, vector<CS> Color_);
		void draw_each_Patch(vector<Tile> total_Tiles, vector<CS> Color_, string folder_path);

		void tiling(vector<Tile> total_Tiles, vector<CS> Color_);
		void tiling_each_scale(int c, vector<Tile> total_Tiles, vector<CS> Color_);
		void tiling_each_scale_dmt(int c, vector<Tile> total_Tiles, vector<CS> Color_);
		int re_tiling_each_scale(int c, vector<Tile> total_Tiles, vector<CS> Color_, vector<pair<Patch, int>> sup_patch); //---lxk
		int re_tiling_each_scale_waiting(int c, vector<Tile> total_Tiles, vector<CS> Color_, vector<pair<Patch, int>> sup_patch);
		void tiling_each_scale_bidirection(int c, vector<Tile> total_Tiles, vector<CS> Color_, int start_i, int start_y); //---lxk
		void tiling_supp(int c, vector<Tile> total_Tiles, vector<CS> Color_);
		void draw_tiling(vector<Tile> total_Tiles, vector<CS> Color_, int draw_scale, int draw_iter_times = 0);
		void draw_special_tiling(vector<Tile> total_Tiles, vector<CS> Color_, int draw_scale, int draw_iter_times = 0);
		void box_s_patch(int size);
		void pre_process(int p_size);
		void re_pre_process(int p_size, int cho_distribution_num);
		void gathering_sup(int p_size);//�������ƺ��ܶȲ㼶����
		void gathering_two(vector<vector<double>> &diagonal, vector<vector<double>> &horizonal, int size);
		void divide_level(vector<vector<double>> all_sup, vector<vector<double>>& l1, vector<vector<double>>& l2, vector<vector<double>>& l3, vector<vector<double>>& l4, vector<vector<double>>& l5);
		vector<double> average_density(vector<vector<double> >vec);
		void regeneration(vector<Tile> total_Tiles, vector<CS> Color_, int scale);
		void design_reign();//������ƽ������ 
		double tiled_reign();//�ж��ж�������ƽ��

		void set_sort_density(int patch_scale);//---------------lxk
		void test_show(vector<Tile> total_Tiles, vector<CS> Color_, vector<double> dent, vector<Patch> patches);

		void rotate_process(vector<Tile> total_Tiles);
		void post_process(vector<Tile> total_Tiles, vector<CS> Color_, int scale);
		bool is_same_edge(Patch p1, Patch p2);
		double cal_patch_sup_error(vector<Tile> total_Tiles, int x, int y, Patch pt2, int scale);

		void draw_rest(string name);
		void clear_tiling(int scale);
		bool can_tile(Patch pt, vector<Tile> total_tiles, int x, int y, vector<int>& replace_position, int scale);
		void draw_grey(string name, vector<vector<double> >sups, bool show_no_value = true);
		vector<vector<double> > acquire_density(vector <vector<double> > orinal, int num);

		void writePatch(string name);
		void readPatch(string name);

		void judge_frequency(int scale);
		void Dithering(int x, int y, int size, double weight, double error);
	};

	//----Multi_Scale Patch Tools
	bool cmp_error(pair<int, vector<double> > &x, pair<int, vector<double> > &y); //compare two sequence
	bool cmp_patch_rotate(Patch &a, Patch &b);  //compare class_id
	bool cmp_pre_process(PAIR &a, PAIR &b); //re_pre_process: compare clusters times 
	bool cmp_patch(Patch &a, Patch &b); //compare density 
	bool cmp_patch_boundary(Patch &a, Patch &b); //compare boundary width
	bool cmp_pair(pair<double, int> a, pair<double, int> b);
	bool cmp_pair_sec(pair<int, int> &x, pair<int, int> &y); //compare pair second

	bool cmp_mismatch_b(pair<Point, int> a, pair<Point, int> b); //compare boundary mismatch num

	//double match_error(vector<double> image_density, vector<double> patch_density);
	double match_error(vector<double> image_density, vector<double> patch_density, double local = local_coef, double global = average_coef, double gradient = gradient_coef);
	double cal_patch_error(vector<Tile> total_Tiles, Patch p1, Patch p2, int scale, double local = local_coef, double global = average_coef, double gradient = gradient_coef);
	int match_tile_bound_constrain(vector<Tile>& allTiles, int & index, int ww, int ee, int nn, int ss, double density);//--lxk,ֻ������߽�Լ��
	void load_para(std::string filename);

}



#endif 
